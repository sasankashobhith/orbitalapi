package com.bundee.hvs.pojo;

public class BranchResponse {

	private int id;
	private String make;
	private String model;
	private String year;
	private String cityname;
	private String zipcode;
	private String address1;
	private String address2;
	private String address3;
	private String state;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	public BranchResponse(){}
	public BranchResponse(int id, String make, String model, String year, String cityname, String zipcode,
			String address1, String address2, String address3, String state) {
		super();
		this.id = id;
		this.make = make;
		this.model = model;
		this.year = year;
		this.cityname = cityname;
		this.zipcode = zipcode;
		this.address1 = address1;
		this.address2 = address2;
		this.address3 = address3;
		this.state = state;
	}

}
