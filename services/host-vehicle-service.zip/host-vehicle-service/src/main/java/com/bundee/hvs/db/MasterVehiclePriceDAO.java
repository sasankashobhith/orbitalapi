package com.bundee.hvs.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bundee.hvs.pojo.MasterVehicleImageResponse;
import com.bundee.hvs.pojo.MasterVehiclePriceResponse;
import com.bundee.hvs.pojo.VehicleID;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.dbi.DBManager;
import com.bundee.msfw.interfaces.dbi.DBQuery;
import com.bundee.msfw.interfaces.dbi.DBQueryBuilder;
import com.bundee.msfw.interfaces.logi.BLogger;

public class MasterVehiclePriceDAO {
	
	private static final String GET_ALL_PRICE= "select * from master_vehicle_price where isactive=true";
	private static final String GET_ALL_PRICE_BY_ID= "select * from master_vehicle_price where id= ? and isactive=true";
	private static final String GET_ALL_PRICE_BY_USERID= "select * from master_vehicle_price where userid= ? and isactive=true";
	private static final String GET_ALL_PRICE_BY_VEHICLEID= "select * from master_vehicle_price where vehicle_id= ? and isactive=true";
	private static final String INSERT_PRICE_DETAILS= "insert into master_vehicle_price (vehicle_id, price_per_hr, userid,isactive) values (?, ?, ?,true)";
	
	private static final String UPDATE_PRICE_UPDATEDTIME="UPDATE master_vehicle_price SET price_per_hr=?,updtd_ts=? WHERE id=?";
	private static final String UPDATE_PRICE_ISACTIVE_UPDATEDTIME="UPDATE master_vehicle_price SET isactive=?,updtd_ts=? WHERE id=?";
	
	
	
	
	public static VehiclesList geAllMasterVehiclePrice(BLogger logger, DBManager dbm)
			throws DBException {
		VehiclesList vehiclesList = new VehiclesList();
        try {

            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(GET_ALL_PRICE).setBindInputFunction((dbBLogger, ps) -> {
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getVehiclePriceresponse().add(getAllResponse(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            
            
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data retrieved successfully");
            return vehiclesList;

        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving all Vehicle Price  details - " + e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }

    }
	
	
	public static VehiclesList getPriceById(BLogger logger, DBManager dbm,
			VehicleID resObject) throws DBException {
        VehiclesList imagedetaillist = new VehiclesList();
        List<MasterVehiclePriceResponse> priceResponse = new ArrayList<MasterVehiclePriceResponse>();
        if (dbm == null || resObject == null || resObject.getFromvalue() == null ) {
        	imagedetaillist.setErrorCode("1");
        	imagedetaillist.setErrorMessage("Invalid Input Request");
            return imagedetaillist;
        }
        try {
            String queryString = "NA";	 
            if (resObject.getFromvalue().toLowerCase().equals("id")) {
                queryString = GET_ALL_PRICE_BY_ID;
            } else if (resObject.getFromvalue().toLowerCase().equals("userid")) {
                queryString = GET_ALL_PRICE_BY_USERID;
            } else if (resObject.getFromvalue().toLowerCase().equals("vehicleid")) {
                queryString = GET_ALL_PRICE_BY_VEHICLEID;
            } else {
            	imagedetaillist.setErrorCode("1");
            	imagedetaillist.setErrorMessage("Invalid Input Request");
                return imagedetaillist;
            }
            if (queryString.equals("NA")) {
            	imagedetaillist.setErrorCode("1");
            	imagedetaillist.setErrorMessage("Invalid Input Request");
               return imagedetaillist;

            }
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(queryString).setBindInputFunction((dbLogger, ps) -> {
                if (resObject.getFromvalue().toLowerCase().equals("id")){
                	  ps.setInt(1, resObject.getId());
                } 
                else if (resObject.getFromvalue().toLowerCase().equals("vehicleid")) {
                    ps.setInt(1, resObject.getId());
                }
                else if (resObject.getFromvalue().toLowerCase().equals("userid")) {
                    ps.setInt(1, resObject.getId());
                }
            }).setFetchDataFunction((dbFLogger, rs) -> {
            	priceResponse.add(getAllResponse(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            imagedetaillist.setErrorCode("0");
            imagedetaillist.setErrorMessage("Data retrieved Succesfully");
            imagedetaillist.setVehiclePriceresponse(priceResponse);
            return imagedetaillist;
        } catch (Exception e) {
        	imagedetaillist.setErrorCode("1");
        	imagedetaillist.setErrorMessage("Error in Price Request exception" + e.getMessage());
            return imagedetaillist;
        }
    }
	
	
	public static VehiclesList insertPriceDetails(BLogger logger, DBManager dbm, MasterVehiclePriceResponse resobj)
			throws DBException {
		VehiclesList imagedetails = new VehiclesList();
		List<MasterVehiclePriceResponse> priceResponse = new ArrayList<MasterVehiclePriceResponse>();
		try {
			if (dbm == null || resobj == null||resobj.getPricePerHour()==0||resobj.getVehicleid()==0||resobj.getUserid()==0) {
				imagedetails.setErrorCode("1");
				imagedetails.setErrorMessage("Error in Vehicle Price Request");
				return imagedetails;
			} else {
				DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
				DBQuery sq = dbQB.setBatch().setQueryString(INSERT_PRICE_DETAILS)
						.setBindInputFunction((dbLogger, ps) -> {
							
							ps.setInt(1, resobj.getVehicleid());							
							ps.setDouble(2, resobj.getPricePerHour());
							ps.setInt(3, resobj.getUserid());		
							ps.addBatch();

						}).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
							priceResponse.add(getAllResponse(logger, rs));
						}).logQuery(true).build();
				dbm.update(logger, sq);
				imagedetails.setErrorCode("0");
				imagedetails.setErrorMessage("Successfully Price Inserted");
				imagedetails.setVehiclePriceresponse(priceResponse);
				return imagedetails;

			}
		} catch (DBException e) {
			// TODO Auto-generated catch block
			imagedetails.setErrorCode("1");
			imagedetails.setErrorMessage("Error in Reservation " + e.getMessage().toString());
			return imagedetails;
		}
	}
	
	
	public static VehiclesList updateImageDetails(BLogger logger, DBManager dbm, MasterVehiclePriceResponse resobj) {
		
		VehiclesList imagedetails = new VehiclesList();
		List<MasterVehiclePriceResponse> priceResponse = new ArrayList<MasterVehiclePriceResponse>();
		if (dbm == null || resobj == null||resobj.getId()==0) {
			imagedetails.setErrorCode("1");
			imagedetails.setErrorMessage("Error in Update Image Request");
			return imagedetails;
		} else {
			
			Date updateDate = new Date();
			java.sql.Date sqlupdateDate = new java.sql.Date(updateDate.getTime());
			java.sql.Timestamp sqlupdateDateTime = new java.sql.Timestamp(sqlupdateDate.getTime());
			
			try {
				if (resobj.getPricePerHour() != 0 ) {
					
					DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
					DBQuery sq = dbQB.setBatch().setQueryString(UPDATE_PRICE_UPDATEDTIME)
							.setBindInputFunction((dbLogger, ps) -> {

								ps.setDouble(1, resobj.getPricePerHour());
								ps.setTimestamp(2, sqlupdateDateTime);
								ps.setInt(3, resobj.getId());
								ps.addBatch();
								
							}).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
								priceResponse.add(getAllResponse(logger, rs));
							}).logQuery(true).throwOnNoData(false).build();
					dbm.update(logger, sq);
					
					imagedetails.setErrorCode("0");
					imagedetails.setErrorMessage("Successfully UPDATED");
					imagedetails.setVehiclePriceresponse(priceResponse);
					return imagedetails;
					
					}else {														
						DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
						DBQuery sq = dbQB.setBatch().setQueryString(UPDATE_PRICE_ISACTIVE_UPDATEDTIME)
								.setBindInputFunction((dbLogger, ps) -> {

									ps.setBoolean(1, resobj.getIsactive());
									ps.setTimestamp(2, sqlupdateDateTime);
									ps.setInt(3, resobj.getId());
								    ps.addBatch();
									
								}).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
									priceResponse.add(getAllResponse(logger, rs));
									
								}).logQuery(true).throwOnNoData(false).build();
						
						
						dbm.update(logger, sq);
					
				imagedetails.setErrorCode("0");
				imagedetails.setErrorMessage("Successfully UPDATED");
				imagedetails.setVehiclePriceresponse(priceResponse);
					return imagedetails;
					
			} 
			} catch (Exception e) {
				imagedetails.setErrorCode("1");
				imagedetails.setErrorMessage("Invalid Date format " + e.getMessage().toString());
				return imagedetails;
			}

		}

	}
	
	
	
	private static MasterVehiclePriceResponse getAllResponse(BLogger logger, ResultSet rs) throws SQLException {
				MasterVehiclePriceResponse masterVehiclePrice = new MasterVehiclePriceResponse();
				masterVehiclePrice.setId(rs.getInt("id"));
				masterVehiclePrice.setVehicleid(rs.getInt("vehicle_id"));
				masterVehiclePrice.setUserid(rs.getInt("userid"));
				masterVehiclePrice.setPricePerHour(rs.getDouble("price_per_hr"));
				masterVehiclePrice.setCreatedate(rs.getString("crtd_ts"));
				masterVehiclePrice.setUpdatedate(rs.getString("updtd_ts"));
				masterVehiclePrice.setIsactive(rs.getBoolean("isactive"));
			
			return masterVehiclePrice;
		}

}
