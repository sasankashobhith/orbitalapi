package com.bundee.hvs.db;

import com.bundee.hvs.pojo.*;
import com.bundee.msfw.defs.*;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.dbi.DBManager;
import com.bundee.msfw.interfaces.dbi.DBQuery;
import com.bundee.msfw.interfaces.dbi.DBQueryBuilder;
import com.bundee.msfw.interfaces.logi.BLogger;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.*;

public class CustomerActivityDAO {

    private static final String INSERT_CUSTOMER = "insert into customeractivity (userid,vehicleid,startdate,enddate,lattitude,longitude) values (?,?,?,?,?,?)";

    private static final String GET_ALL_CUTOMERACTIVITY = "select * from customeractivity where isactive=true";

    private static final String CUSTOMER_ACTIVUITY_BY_ID = "SELECT * FROM customeractivity WHERE id=? and isactive=true";

    private static final String CUSTOMER_ACTIVITY_BY_USERID = "SELECT * FROM customeractivity WHERE userid=? and isactive=true";

    private static final String CUSTOMER_ACTIVITY_BY_VEHICLEID = "SELECT * FROM customeractivity WHERE vehicleid=? and isactive=true";
    private static final String CUSTOMER_ACTIVITY_BY_VEHICLEID_AND_USERID = "SELECT * FROM customeractivity WHERE vehicleid=? and userid=? and isactive=true";
    private static final String CHECK_CUSTOMER_ACTIVITY_BY_VEHICLEID_AND_USERID = "SELECT * FROM customeractivity WHERE vehicleid=? and userid=?";

    private static final String CUSTOMER_ACTIVITY_SOFT_UPDATE = "UPDATE customeractivity SET isactive = ?,updateddate=? WHERE userid=?";

    private static final String CUSTOMER_ACTIVITY_UPDATE = "UPDATE customeractivity SET lattitude=?, longitude=?, startdate=?, enddate=?,updateddate=?,isactive=true WHERE userid=? and vehicleid=?";

    public static VehiclesList insertCustomerActivity(BLogger logger, DBManager dbm, CustomerActivityResponse customeractivity) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || customeractivity == null || customeractivity.getUserid() == 0 || customeractivity.getVehicleid() == 0 || customeractivity.getStartdate() == null || customeractivity.getEnddate() == null || customeractivity.getLattitude() == null || customeractivity.getLongitude() == null) {
            vehiclesList.setErrorMessage("Error with the details given");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {

            Date starteddate = new SimpleDateFormat("yyyy-MM-dd").parse(customeractivity.getStartdate());
            java.sql.Date sqlstarteddatetime = new java.sql.Date(starteddate.getTime());
            java.sql.Timestamp startdate = new java.sql.Timestamp(sqlstarteddatetime.getTime());

            Date Activeenddate = new SimpleDateFormat("yyyy-MM-dd").parse(customeractivity.getEnddate());
            java.sql.Date sqlenddate = new java.sql.Date(Activeenddate.getTime());
            java.sql.Timestamp enddate = new java.sql.Timestamp(sqlenddate.getTime());
            System.out.println(startdate);
            System.out.println(enddate);
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(INSERT_CUSTOMER).setBindInputFunction((dbBLogger, ps) -> {

                ps.setInt(1, customeractivity.getUserid());
                ps.setInt(2, customeractivity.getVehicleid());
                ps.setTimestamp(3, startdate);
                ps.setTimestamp(4, enddate);
                ps.setString(5, customeractivity.getLattitude());
                ps.setString(6, customeractivity.getLongitude());

            }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getCustomeractivityresponse().add(createcustomerresponse(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.update(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data inserted successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorCode("1");
            vehiclesList.setErrorMessage("Error in Master Request" + e.getMessage());
            return vehiclesList;
        }
    }

    public static VehiclesList geAllCustomerActivity(BLogger logger, DBManager dbm, VehiclesList vehiclesList) throws DBException {
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();

            DBQuery sq = dbQB.setQueryString(GET_ALL_CUTOMERACTIVITY).setBindInputFunction((dbBLogger, ps) -> {
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getCustomeractivityresponse().add(createcustomerresponse(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data retrieved successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving all CustomerActivity details - " + e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }

    private static CustomerActivityResponse createcustomerresponse(BLogger logger, ResultSet rs) throws SQLException {
        CustomerActivityResponse customeractivity = new CustomerActivityResponse();

        customeractivity.setId(rs.getInt("id"));
        customeractivity.setUserid(rs.getInt("userid"));
        customeractivity.setVehicleid(rs.getInt("vehicleid"));
        customeractivity.setCreateddate(rs.getString("createddate"));
        customeractivity.setIsactive(rs.getBoolean("isactive"));
        customeractivity.setStartdate(rs.getString("startdate"));
        customeractivity.setEnddate(rs.getString("enddate"));
        customeractivity.setLattitude(rs.getString("lattitude"));
        customeractivity.setLongitude(rs.getString("longitude"));

        return customeractivity;
    }

    public static VehiclesList getCustomerActivityresponsebyid(BLogger logger, DBManager dbm, CustomerActivityRequest resObject, List<CustomerActivityResponse> activetripresponse) throws DBException {
        VehiclesList bookResponse = new VehiclesList();

        if (dbm == null || resObject == null || resObject.getFromvalue() == null) {
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Invalid Input Request");
            return bookResponse;
        }
        try {

            String queryString = "NA";

            if (resObject.getFromvalue().equalsIgnoreCase("id")) {
                queryString = CUSTOMER_ACTIVUITY_BY_ID;
            } else if (resObject.getFromvalue().equalsIgnoreCase("userid")) {
                queryString = CUSTOMER_ACTIVITY_BY_USERID;
            } else if (resObject.getFromvalue().equalsIgnoreCase("vehicleid")) {
                queryString = CUSTOMER_ACTIVITY_BY_VEHICLEID;

            } else if (resObject.getFromvalue().equalsIgnoreCase("useridnvehicleid")) {
                queryString = CUSTOMER_ACTIVITY_BY_VEHICLEID_AND_USERID;

            } else {
                bookResponse.setErrorCode("1");
                bookResponse.setErrorMessage("Invalid Input Request");
                return bookResponse;
            }

            if (queryString.equals("NA")) {
                bookResponse.setErrorCode("1");
                bookResponse.setErrorMessage("Invalid Input Request");
                return bookResponse;
            }

            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();

            DBQuery sq = dbQB.setQueryString(queryString).setBindInputFunction((dbLogger, ps) -> {

                if (resObject.getFromvalue().equalsIgnoreCase("id")) {
                    ps.setInt(1, resObject.getId());
                } else if (resObject.getFromvalue().equalsIgnoreCase("vehicleid")) {
                    ps.setInt(1, resObject.getId());

                } else if (resObject.getFromvalue().equalsIgnoreCase("userid")) {
                    ps.setInt(1, resObject.getId());

                } else if (resObject.getFromvalue().equalsIgnoreCase("useridnvehicleid")) {
                    ps.setInt(1, resObject.getVehicleid());
                    ps.setInt(2, resObject.getUserid());
                }

            }).setFetchDataFunction((dbFLogger, rs) -> {

                activetripresponse.add(createcustomerresponse(dbFLogger, rs));

            }).logQuery(true).throwOnNoData(false).build();

            dbm.select(logger, sq);
            bookResponse.setErrorCode("0");
            bookResponse.setErrorMessage("Data retrieved Succesfully");
            bookResponse.setCustomeractivityresponse(activetripresponse);
            return bookResponse;

        } catch (Exception e) {
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in Customer Request exception" + e.getMessage());
            return bookResponse;
        }
    }

    public static VehiclesList updateCustomerActivity(BLogger logger, DBManager dbm, CustomerActivityResponse customeractivity) throws DBException, ParseException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || customeractivity == null) {
            vehiclesList.setErrorMessage("Error with the details given");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            List<CustomerActivityResponse> activetripresponse = new ArrayList<CustomerActivityResponse>();
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(CHECK_CUSTOMER_ACTIVITY_BY_VEHICLEID_AND_USERID).setBindInputFunction((dbLogger, ps) -> {
                ps.setInt(1, customeractivity.getVehicleid());
                ps.setInt(2, customeractivity.getUserid());
            }).setFetchDataFunction((dbFLogger, rs) -> {
                activetripresponse.add(createcustomerresponse(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            if (activetripresponse.isEmpty()) {
                vehiclesList = insertCustomerActivity(logger, dbm, customeractivity);
                return vehiclesList;
            }

            if (customeractivity.getLattitude() == null || customeractivity.getLongitude() == null || customeractivity.getStartdate() == null || customeractivity.getEnddate() == null || customeractivity.getUserid() == 0 || customeractivity.getVehicleid() == 0) {
                vehiclesList.setErrorMessage("Error with the details given");
                vehiclesList.setErrorCode("1");
                return vehiclesList;
            }
            Date starteddate = new SimpleDateFormat("yyyy-MM-dd").parse(customeractivity.getStartdate());
            java.sql.Date sqlstarteddatetime = new java.sql.Date(starteddate.getTime());
            java.sql.Timestamp startdate = new java.sql.Timestamp(sqlstarteddatetime.getTime());

            Date Activeenddate = new SimpleDateFormat("yyyy-MM-dd").parse(customeractivity.getEnddate());
            java.sql.Date sqlenddate = new java.sql.Date(Activeenddate.getTime());
            java.sql.Timestamp enddate = new java.sql.Timestamp(sqlenddate.getTime());
            DBQueryBuilder dbQBUpdate = dbm.getDBQueryBuilder();
            Date updateddate = new Date();
            java.sql.Date sqlupdateddate = new java.sql.Date(updateddate.getTime());
            java.sql.Timestamp updateddatets = new java.sql.Timestamp(sqlupdateddate.getTime());
            VehiclesList finalVehiclesList = vehiclesList;
            DBQuery sqUpdate = dbQBUpdate.setQueryString(CUSTOMER_ACTIVITY_UPDATE).setBindInputFunction((dbBLogger, ps) -> {

                ps.setString(1, customeractivity.getLattitude());
                ps.setString(2, customeractivity.getLongitude());
                ps.setTimestamp(3, startdate);
                ps.setTimestamp(4, enddate);
                ps.setTimestamp(5, updateddatets);
                ps.setInt(6, customeractivity.getUserid());
                ps.setInt(7, customeractivity.getVehicleid());
            }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                finalVehiclesList.getCustomeractivityresponse().add(createcustomerresponse(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.update(logger, sqUpdate);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data updated successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorCode("1");
            vehiclesList.setErrorMessage("Error updating data " + e.getMessage());
            return vehiclesList;
        }
    }

    public static VehiclesList softUpdateCustomerActivity(BLogger logger, DBManager dbm, CustomerActivityResponse customeractivity) throws DBException, ParseException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || customeractivity == null || customeractivity.getUserid() == 0) {
            vehiclesList.setErrorMessage("Error with the details given");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            Date updateddate = new Date();
            java.sql.Date sqlupdateddate = new java.sql.Date(updateddate.getTime());
            java.sql.Timestamp updateddatets = new java.sql.Timestamp(sqlupdateddate.getTime());
            VehiclesList finalVehiclesList = vehiclesList;
            DBQuery sq = dbQB.setQueryString(CUSTOMER_ACTIVITY_SOFT_UPDATE).setBindInputFunction((dbBLogger, ps) -> {
                ps.setBoolean(1, customeractivity.getisactive());
                ps.setTimestamp(2, updateddatets);
                ps.setInt(3, customeractivity.getUserid());
            }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                finalVehiclesList.getCustomeractivityresponse().add(createcustomerresponse(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.update(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data updated successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorCode("1");
            vehiclesList.setErrorMessage("Error updating data " + e.getMessage());
            return vehiclesList;
        }

    }
    public static VehiclesList getVehicleDetail(BLogger logger, DBManager dbm,List<Integer> vehicleids)
            throws DBException {
        String Query="select  mastervehicle.id, make, model,year,price_per_hr from mastervehicle left join master_vehicle_price on mastervehicle.id=master_vehicle_price.vehicle_id where mastervehicle.id in (&in) ";
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicleids == null) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            String arrayString = vehicleids.stream()
                    .map(Object::toString)
                    .collect(Collectors.joining(", "));
            // Replace "&in" with the array string
            String replacedString = Query.replace("&in", arrayString);
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(replacedString).setBindInputFunction((dbBLogger, ps) -> {
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getCustomeractivityresponse().add(createVehicle(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorMessage("Inserted Successfully ");
            vehiclesList.setErrorCode("0");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving branch details "+e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }

    }
    private static CustomerActivityResponse createVehicle(BLogger logger, ResultSet rs) throws SQLException {
        CustomerActivityResponse vehicle = new CustomerActivityResponse();
        vehicle.setVehicleid(rs.getInt("id"));
        vehicle.setMake(rs.getString("make"));
        vehicle.setModel(rs.getString("model"));
        vehicle.setYear(rs.getString("year"));
        vehicle.setVehiclePrice(rs.getDouble("price_per_hr"));
        return vehicle;
    }
}
