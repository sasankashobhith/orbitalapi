package com.bundee.hvs.blmodule;

import com.bundee.hvs.db.*;
import com.bundee.hvs.defs.*;
import com.bundee.hvs.pojo.*;
import com.bundee.hvs.utils.*;
import com.bundee.msfw.defs.*;
import com.bundee.msfw.interfaces.blmodi.*;
import com.bundee.msfw.interfaces.dbi.*;
import com.bundee.msfw.interfaces.endpoint.*;
import com.bundee.msfw.interfaces.logi.*;
import com.bundee.msfw.interfaces.reqrespi.*;
import com.bundee.msfw.interfaces.utili.csv.*;

import java.io.*;
import java.util.*;
import java.util.stream.*;

public class VehicleFeatureModule implements BLModule {
    public static VehicleFeature getVehileFeatures(int vehicleId, int userId, String featureName, String featureDescription) {
        VehicleFeature vehicleFeature = new VehicleFeature();
        vehicleFeature.setFeaturename(new UTF8String(featureName));
        vehicleFeature.setVehicleid(vehicleId);
        vehicleFeature.setUserid(userId);
        if (featureDescription == null || featureDescription.isEmpty()) {
            vehicleFeature.setFeaturedescription(new UTF8String("Not Applicable"));
        } else {
            vehicleFeature.setFeaturedescription(new UTF8String(featureDescription));
        }
        vehicleFeature.setActive(true);
        return vehicleFeature;
    }

    public static List<VehicleFeature> getFeatureData(List<Vehicle> vehicles, List<VinFeature> vehiclesFeatures) {

        List<VehicleFeature> vehicleFeaturesValidated = new ArrayList<VehicleFeature>();

        String notApplicable = "Not Applicable";
        for (int i = 0; i < vehiclesFeatures.size(); i++) {


            String vin = vehiclesFeatures.get(i).getVIN().toString();
            int vId = 0, userId = 0;
            List<Vehicle> vehicleData = vehicles.stream()
                    .filter(item -> item.getVIN().toString().equals(vin)).collect(Collectors.toList());
            if (vehicleData.size() > 0) {
                vId = vehicleData.get(0).getID();
                userId = vehicleData.get(0).getHostID();
            }

            //-----------------Make-----------------------
            VehicleFeature vMake = getVehileFeatures(vId, userId, "Make", vehiclesFeatures.get(i).getMAKE().toString());
            //--------------------------MODEL --------------------
            VehicleFeature vModel = getVehileFeatures(vId, userId, "Model", vehiclesFeatures.get(i).getModel().toString());
            //--------------------------MANUFACTURE NAME --------------------
            VehicleFeature vManufacture = getVehileFeatures(vId, userId, "Manufacturer Name", vehiclesFeatures.get(i).getManufacture().toString());
            //--------------------------MODEL YEAR --------------------
            VehicleFeature vModelYear = getVehileFeatures(vId, userId, "Model Year", vehiclesFeatures.get(i).getModelYear().toString());
            //-------------------------- PLANT CITY --------------------
            VehicleFeature vPlantCiy = getVehileFeatures(vId, userId, "Plant City", vehiclesFeatures.get(i).getPlantcity().toString());
            //--------------------------SERIES  --------------------
            VehicleFeature vSeries = getVehileFeatures(vId, userId, "Series", vehiclesFeatures.get(i).getSeries().toString());
            //--------------------------TRIM --------------------
            VehicleFeature vTrim = getVehileFeatures(vId, userId, "Trim", vehiclesFeatures.get(i).getTrim().toString());
            //-------------------------- Vehicle Type --------------------
            VehicleFeature vehicleType = getVehileFeatures(vId, userId, "Vehicle Type", vehiclesFeatures.get(i).getVehicletype().toString());
            //--------------------------Plant Country--------------------
            VehicleFeature vPlantCountry = getVehileFeatures(vId, userId, "Plant Country", vehiclesFeatures.get(i).getPlantcountry().toString());
            //--------------------------NNote--------------------
            VehicleFeature vNote = getVehileFeatures(vId, userId, "Note", vehiclesFeatures.get(i).getNote().toString());
            //--------------------------Body Class --------------------
            VehicleFeature vBodyClass = getVehileFeatures(vId, userId, "Body Class", vehiclesFeatures.get(i).getBodyclass().toString());
            //--------------------------Doors --------------------
            VehicleFeature vDoors = getVehileFeatures(vId, userId, "Doors", String.valueOf(vehiclesFeatures.get(i).getDoors()));
            //--------------------------Gross Vehicle Weight Rating From --------------------
            VehicleFeature vGrossWeightRating = getVehileFeatures(vId, userId, "Gross Vehicle Weight Rating", vehiclesFeatures.get(i).getGrossweightratingtype().toString());
            //--------------------------BedType --------------------
            VehicleFeature vBedType = getVehileFeatures(vId, userId, "Bed Type", vehiclesFeatures.get(i).getBedtype().toString());
            //--------------------------CabType --------------------
            VehicleFeature vCabType = getVehileFeatures(vId, userId, "Cab Type", vehiclesFeatures.get(i).getCabtype().toString());
            //--------------------------Trailer Type Connection --------------------
            VehicleFeature vTrailerTypeConnection = getVehileFeatures(vId, userId, "Trailer Type Connection", vehiclesFeatures.get(i).getTrailertypeconnection().toString());
            //--------------------------Trailer Body Type --------------------
            VehicleFeature vTrailerBodyType = getVehileFeatures(vId, userId, "Trailer Body Type", vehiclesFeatures.get(i).getTrailerbodytype().toString());
            //--------------------------Engine Number of Cylinders --------------------
            VehicleFeature vEngineNumber = getVehileFeatures(vId, userId, "Engine Number of Cylinders",String.valueOf(vehiclesFeatures.get(i).getEnginenumberofcylinders()));
            //--------------------------Displacement (CC) --------------------
            VehicleFeature vDisplacementCC = getVehileFeatures(vId, userId, "Displacement (CC)", vehiclesFeatures.get(i).getDisplacementcc().toString());
            //--------------------------Displacement (CI) --------------------
            VehicleFeature vDisplacementCI = getVehileFeatures(vId, userId, "Displacement (CI)", vehiclesFeatures.get(i).getDisplacementci().toString());
            //--------------------------Displacement (L) --------------------
            VehicleFeature vDisplacementL = getVehileFeatures(vId, userId, "Displacement (L)", vehiclesFeatures.get(i).getDisplacementtl().toString());
            //--------------------------Engine Power (kW) --------------------
            VehicleFeature vEnginePower = getVehileFeatures(vId, userId, "Engine Power (kW)", vehiclesFeatures.get(i).getEnginepower().toString());
            //--------------------------Fuel Type - Primary  --------------------
            VehicleFeature vFuelType  = getVehileFeatures(vId, userId, "Fuel Type - Primary", vehiclesFeatures.get(i).getFueltypeprimary().toString());
            //--------------------------Engine Brake (hp) From --------------------
            VehicleFeature vEngineBrake  = getVehileFeatures(vId, userId, "Engine Brake (hp) From", vehiclesFeatures.get(i).getEnginebreakform().toString());
            //--------------------------Seat Belt Type--------------------
            VehicleFeature vSeatBeltTypeI = getVehileFeatures(vId, userId, "Seat Belt Type", vehiclesFeatures.get(i).getSeatbelttype().toString());
            //--------------------------Other Restraint System Info --------------------
            VehicleFeature otherRestraintSystemInfo = getVehileFeatures(vId, userId, "Other Restraint System Info", vehiclesFeatures.get(i).getOtherrestraintsysteminformation().toString());
            //--------------------------Front Air Bag Locations--------------------
            VehicleFeature frontAirBagLocations = getVehileFeatures(vId, userId, "Front Air Bag Locations", vehiclesFeatures.get(i).getfrontairbaglocations().toString());
            //--------------------------Knee Air Bag Locations--------------------
            VehicleFeature kneeAirBagLocations = getVehileFeatures(vId, userId, "Knee Air Bag Locations", vehiclesFeatures.get(i).getKneeairbaglocations().toString());
            //--------------------------Side Air Bag Locations--------------------
            VehicleFeature sideAirBagLocations = getVehileFeatures(vId, userId, "Side Air Bag Locations", vehiclesFeatures.get(i).getSideairbaglocations().toString());
            //--------------------------Tire Pressure Monitoring System (TPMS) Type--------------------
            VehicleFeature vTirepressuremonitoringsystem = getVehileFeatures(vId, userId, "Tire Pressure Monitoring System (TPMS) Type", vehiclesFeatures.get(i).getTirepressureconfigurationsystem().toString());
            //--------------------------Bus Floor Configuration Type --------------------
            VehicleFeature vBusFloor = getVehileFeatures(vId, userId, "Bus Floor Configuration Type", vehiclesFeatures.get(i).getBusfloorconfigurationsystem().toString());
            //--------------------------Bus Type --------------------
            VehicleFeature vBusTypeI = getVehileFeatures(vId, userId, "Bus Type", vehiclesFeatures.get(i).getBustype().toString());
            //--------------------------Custom Motorcycle Type--------------------
            VehicleFeature vCustomMotorType = getVehileFeatures(vId, userId, "Custom Motorcycle Type", vehiclesFeatures.get(i).getCustommotorcycletype().toString());
            //--------------------------Motorcycle Suspension Type--------------------
            VehicleFeature vMotorcycleSuspensionType = getVehileFeatures(vId, userId, "Motorcycle Suspension Type", vehiclesFeatures.get(i).getMotorcyclesuspensionform().toString());
            //--------------------------Motorcycle Chassis Type--------------------
            VehicleFeature vMotorcycleChassisType = getVehileFeatures(vId, userId, "Motorcycle Chassis Type", vehiclesFeatures.get(i).getMotorcyclechasistype().toString());
            //--------------------------Plant Company Name--------------------
            VehicleFeature vPlantCompanyName = getVehileFeatures(vId, userId, "Plant Company Name", vehiclesFeatures.get(i).getPlantcompanyname().toString());
            //--------------------------Plant State-------------------
            VehicleFeature vPlantState = getVehileFeatures(vId, userId, "Plant State", vehiclesFeatures.get(i).getPlantstate().toString());
            //-------------------------Steering Location--------------------
            VehicleFeature vSteeringLocation = getVehileFeatures(vId, userId, "Steering Location", vehiclesFeatures.get(i).getSteringlocation().toString());
            //--------------------------Drive Type--------------------
            VehicleFeature vDriveType = getVehileFeatures(vId, userId, "Drive Type", vehiclesFeatures.get(i).getDrivetype().toString());
            //--------------------------ElectrificationLevel------------------
            VehicleFeature vElectrificationLevel = getVehileFeatures(vId, userId, "Electrification Level", vehiclesFeatures.get(i).getElecrtrificationtype().toString());
            //--------------------------OtherEngineInfo--------------------
            VehicleFeature vOtherEngineInfo = getVehileFeatures(vId, userId, "Other Engine Info", vehiclesFeatures.get(i).getOtherengineeinformation().toString());
            //--------------------------Turbo--------------------
            VehicleFeature vTurbo = getVehileFeatures(vId, userId, "Turbo", String.valueOf(vehiclesFeatures.get(i).getTurbo()));
            //--------------------------EngineManufacturer--------------------
            VehicleFeature vEngineManufacturer = getVehileFeatures(vId, userId, "Engine Manufacturer",String.valueOf(vehiclesFeatures.get(i).getEngineemanufacture()));
            //--------------------------Series2 --------------------
            VehicleFeature vSeries2 = getVehileFeatures(vId, userId, "Series2", String.valueOf(vehiclesFeatures.get(i).getSeries2()));
            //--------------------------Windows-------------------
            VehicleFeature vWindows = getVehileFeatures(vId, userId, "Windows", String.valueOf(vehiclesFeatures.get(i).getWindows()));
            //-------------------------CurtainAirBagLocations --------------------
            VehicleFeature vCurtainAirBagLocations = getVehileFeatures(vId, userId, "Curtain AirBag Locations", vehiclesFeatures.get(i).getCurrentairbaglocation().toString());
            //--------------------------BasePrice ($)-------------------
            VehicleFeature vBasePrice = getVehileFeatures(vId, userId, "BasePrice", String.valueOf(vehiclesFeatures.get(i).getBaseprice()));
            //-------------------------WheelBase(inches)From--------------------
            VehicleFeature vWheelBase = getVehileFeatures(vId, userId, "WheelBase(inches)", String.valueOf(vehiclesFeatures.get(i).getWheelbaseform()));
            //--------------------------NumberofWheels--------------------
            VehicleFeature vNumberofWheels = getVehileFeatures(vId, userId, "Number of Wheels", String.valueOf(vehiclesFeatures.get(i).getNumberofwheels()));
            //--------------------------WheelSizeFront(inches)-------------------
            VehicleFeature vWheelSizeFront = getVehileFeatures(vId, userId, "Wheel SizeFront(inches)",String.valueOf(vehiclesFeatures.get(i).getWheelsizefront()));
            //--------------------------WheelSizeRear(inches)--------------------
            VehicleFeature vWheelSizeRear= getVehileFeatures(vId, userId, "Wheel SizeRear(inches)",String.valueOf(vehiclesFeatures.get(i).getWheelsizerear()));
            //--------------------------NumberofSeats-----------------
            VehicleFeature vNumberofSeats = getVehileFeatures(vId, userId, "Number of Seats", String.valueOf(vehiclesFeatures.get(i).getNumberofseats()));
            //--------------------------TransmissionStyle------------------
            VehicleFeature vTransmissionStyle = getVehileFeatures(vId, userId, "Transmission Style", vehiclesFeatures.get(i).getTransmissionstyle().toString());
            //--------------------------Axles--------------------
            VehicleFeature vAxles = getVehileFeatures(vId, userId, "Axles", String.valueOf(vehiclesFeatures.get(i).getAxles()));
            //--------------------------AntilockBrakingSystem (ABS)------------------
            VehicleFeature vAntilockBrakingSystem = getVehileFeatures(vId, userId, "AntilockBrakingSystem  (ABS)", vehiclesFeatures.get(i).getAntilockbrakingsystem().toString());
            //--------------------------ElectronicStabilityControl (ESC)------------------
            VehicleFeature ElectronicStabilityControl = getVehileFeatures(vId, userId, "ElectronicStabilityControl (ESC)", vehiclesFeatures.get(i).getElectronicstabilitysystem().toString());
            //-------------------------ActiveSafetySystemNote-------------------
            VehicleFeature ActiveSafetySystemNote = getVehileFeatures(vId, userId, "Active Safety SystemNote", vehiclesFeatures.get(i).getAcivesafteysystemnote().toString());
            //--------------------------BackupCamera-----------------
            VehicleFeature BackupCamera = getVehileFeatures(vId, userId, "BackupCamera", vehiclesFeatures.get(i).getBackupcamer().toString());
            //-------------------------DaytimeRunningLight (DRL)-------------------
            VehicleFeature DaytimeRunningLight = getVehileFeatures(vId, userId, "DaytimeRunningLight (DRL)", vehiclesFeatures.get(i).getDaytimerunninglight().toString());
            //------------------------Pretensioner-----------------
            VehicleFeature Pretensioner = getVehileFeatures(vId, userId, "Pretensioner", vehiclesFeatures.get(i).getPlantstate().toString());
            //-------------------------Brake System Type------------------
            VehicleFeature BrakeSystemType = getVehileFeatures(vId, userId, "Brake System Type", vehiclesFeatures.get(i).getBreaksystemtype().toString());
            //*------------------------EngineConfiguration-----------------
            VehicleFeature EngineConfiguration = getVehileFeatures(vId, userId, "EngineConfiguration", vehiclesFeatures.get(i).getEngineconfiguration().toString());
            //*--------------------------VehicleDescription--------------------
            VehicleFeature vVehicleDescription = getVehileFeatures(vId, userId, "Vehicle Description", vehiclesFeatures.get(i).getVehicleDescription().toString());
            //*--------------------------SeatingCapacity--------------------
            VehicleFeature vSeatingCapacity = getVehileFeatures(vId, userId, "Seating Capacity", vehiclesFeatures.get(i).getSeatingCapacity().toString());
            //*--------------------------InsuranceHeader--------------------
            VehicleFeature vInsuranceHeader = getVehileFeatures(vId, userId, "Insurance Header", vehiclesFeatures.get(i).getInsuranceHeader().toString());
            //*-----------------------------InsuranceHeaderTYPE-----------------
            VehicleFeature vInsuranceHeaderTYPE = getVehileFeatures(vId, userId, "Insurance Header Type", vehiclesFeatures.get(i).getInsuranceHeaderType().toString());
            //*--------------------------INSURANCEDETAILS1--------------------
            VehicleFeature vInsuranceDetails1= getVehileFeatures(vId, userId, "Insurance Details1", vehiclesFeatures.get(i).getInsuranceDetails1().toString());
            //*-------------------------INSURANCEDETAILS2-------------------
            VehicleFeature vInsuranceDetails2 = getVehileFeatures(vId, userId, "Insurance Details2", vehiclesFeatures.get(i).getInsuranceDetails2().toString());
            //*--------------------------INSURANCEDETAILS3--------------------
            VehicleFeature vInsuranceDetails3 = getVehileFeatures(vId, userId, "Insurance Details3", vehiclesFeatures.get(i).getInsuranceDetails3().toString());
            //*--------------------------PARKING DETAILS-------------------
            VehicleFeature vParkingDetails = getVehileFeatures(vId, userId, "Parking Details", vehiclesFeatures.get(i).getParkingDetails().toString());
            //*-------------------------GUIDELINES-------------------
            VehicleFeature vGuidelines = getVehileFeatures(vId, userId, "GuideLines", vehiclesFeatures.get(i).getGuidelines().toString());
            //*-------------------------CANCELLATION POLICYTEXT--------------------
            VehicleFeature vCancelPolicy = getVehileFeatures(vId, userId, "Cancellation Policy Text", vehiclesFeatures.get(i).getCancellationPolicyText().toString());

            vehicleFeaturesValidated.add(vMake);
            vehicleFeaturesValidated.add(vModel);
            vehicleFeaturesValidated.add(vManufacture);
            vehicleFeaturesValidated.add(vModelYear);
            vehicleFeaturesValidated.add(vPlantCiy);
            vehicleFeaturesValidated.add(vSeries);
            vehicleFeaturesValidated.add(vTrim);
            vehicleFeaturesValidated.add(vehicleType);
            vehicleFeaturesValidated.add(vPlantCountry);
            vehicleFeaturesValidated.add(vNote);
            vehicleFeaturesValidated.add(vBodyClass);
            vehicleFeaturesValidated.add(vDoors);
            vehicleFeaturesValidated.add(vGrossWeightRating);
            vehicleFeaturesValidated.add(vBedType);
            vehicleFeaturesValidated.add(vCabType);
            vehicleFeaturesValidated.add(vTrailerTypeConnection);
            vehicleFeaturesValidated.add(vTrailerBodyType);
            vehicleFeaturesValidated.add(vEngineNumber);
            vehicleFeaturesValidated.add(vDisplacementCC);
            vehicleFeaturesValidated.add(vDisplacementCI);
            vehicleFeaturesValidated.add(vDisplacementL);
            vehicleFeaturesValidated.add(vEnginePower);
            vehicleFeaturesValidated.add(vFuelType);
            vehicleFeaturesValidated.add(vEngineBrake);
            vehicleFeaturesValidated.add(vSeatBeltTypeI);
            vehicleFeaturesValidated.add(otherRestraintSystemInfo);
            vehicleFeaturesValidated.add(frontAirBagLocations);
            vehicleFeaturesValidated.add(kneeAirBagLocations);
            vehicleFeaturesValidated.add(sideAirBagLocations);
            vehicleFeaturesValidated.add(vTirepressuremonitoringsystem);
            vehicleFeaturesValidated.add(vBusFloor);
            vehicleFeaturesValidated.add(vBusTypeI);
            vehicleFeaturesValidated.add(vCustomMotorType);
            vehicleFeaturesValidated.add(vMotorcycleSuspensionType);
            vehicleFeaturesValidated.add(vMotorcycleChassisType);
            vehicleFeaturesValidated.add(vPlantCompanyName);
            vehicleFeaturesValidated.add(vPlantState);
            vehicleFeaturesValidated.add(vSteeringLocation);
            vehicleFeaturesValidated.add(vDriveType);
            vehicleFeaturesValidated.add(vElectrificationLevel);
            vehicleFeaturesValidated.add(vOtherEngineInfo);
            vehicleFeaturesValidated.add(vTurbo);
            vehicleFeaturesValidated.add(vEngineManufacturer);
            vehicleFeaturesValidated.add(vSeries2);
            vehicleFeaturesValidated.add(vWindows);
            vehicleFeaturesValidated.add(vCurtainAirBagLocations);
            vehicleFeaturesValidated.add(vBasePrice);
            vehicleFeaturesValidated.add(vWheelBase);
            vehicleFeaturesValidated.add(vNumberofWheels);
            vehicleFeaturesValidated.add(vWheelSizeFront);
            vehicleFeaturesValidated.add(vWheelSizeRear);
            vehicleFeaturesValidated.add(vNumberofSeats);
            vehicleFeaturesValidated.add(vTransmissionStyle);
            vehicleFeaturesValidated.add(vAxles);
            vehicleFeaturesValidated.add(vAntilockBrakingSystem);
            vehicleFeaturesValidated.add(ElectronicStabilityControl);
            vehicleFeaturesValidated.add(ActiveSafetySystemNote);
            vehicleFeaturesValidated.add(BackupCamera);
            vehicleFeaturesValidated.add(DaytimeRunningLight);
            vehicleFeaturesValidated.add(Pretensioner);
            vehicleFeaturesValidated.add(BrakeSystemType);
            vehicleFeaturesValidated.add(EngineConfiguration);
            vehicleFeaturesValidated.add(vVehicleDescription);
            vehicleFeaturesValidated.add(vSeatingCapacity);
            vehicleFeaturesValidated.add(vInsuranceHeader);
            vehicleFeaturesValidated.add(vInsuranceDetails1);
            vehicleFeaturesValidated.add(vInsuranceDetails2);
            vehicleFeaturesValidated.add(vInsuranceDetails3);
            vehicleFeaturesValidated.add(vInsuranceHeaderTYPE);
            vehicleFeaturesValidated.add(vParkingDetails);
            vehicleFeaturesValidated.add(vGuidelines);
            vehicleFeaturesValidated.add(vCancelPolicy);
        }

        return vehicleFeaturesValidated;
    }
    @Override
    public void init(BLogger logger, BLModServices blModServices) throws BExceptions {
    }

    @BEndpoint(uri = HVDefs.Endpoints.GET_FEATURES_BY_VEHICLE_BY_ID, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleFeature.class)
    public BaseResponse listVehicleFeaturesByVehicle(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                                     VehicleFeature requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = VehicleFeatureDAO.listVehiclesByFeatureID(logger, blModServices.getDBManager(), requestObject.getVehicleid(), vList.getVehiclefeatures());
            return vList;
        } catch (DBException e) {
            vList.setErrorMessage("Error with the details given");
            vList.setErrorCode("1");
            return vList;
        }
    }

    @BEndpoint(uri = HVDefs.Endpoints.GET_FEATURES_BY_ID, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleFeature.class)
    public BaseResponse listVehicleFeaturesByID(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                                VehicleFeature requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = VehicleFeatureDAO.listFeaturesByID(logger, blModServices.getDBManager(), requestObject.getVehiclefeatureid(), vList.getVehiclefeatures());
            return vList;
        } catch (DBException e) {
            vList.setErrorMessage("Error with the details given" + e.getMessage());
            vList.setErrorCode("1");
            return vList;
        }
    }

    @BEndpoint(uri = HVDefs.Endpoints.GET_ALL_FEATURES, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleFeature.class)
    public BaseResponse listVehicleFeatures(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                            VehicleFeature requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = VehicleFeatureDAO.listAllFeatures(logger, blModServices.getDBManager(), vList.getVehiclefeatures());
            return vList;
        } catch (DBException e) {
            vList.setErrorMessage("Error with the details given" + e.getMessage());
            vList.setErrorCode("1");
            return vList;
        }
    }

    @BEndpoint(uri = HVDefs.Endpoints.INSERT_FEATURES, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleFeature.class)
    public BaseResponse insertVehicleFeatures(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                              VehicleFeature requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = VehicleFeatureDAO.insertFeatures(logger, blModServices.getDBManager(), requestObject);
            return vList;
        } catch (DBException e) {
            vList.setErrorMessage("Error with the details given" + e.getMessage());
            vList.setErrorCode("1");
            return vList;
        }
    }

    @BEndpoint(uri = HVDefs.Endpoints.UPDATE_FEATURES, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleFeature.class)
    public BaseResponse updateVehicleFeatures(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                              VehicleFeature requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = VehicleFeatureDAO.updateFeatures(logger, blModServices.getDBManager(), requestObject);
            return vList;
        } catch (DBException e) {
            vList.setErrorMessage("Error with the details given" + e.getMessage());
            vList.setErrorCode("1");
            return vList;
        }
    }

    @BEndpoint(uri = HVDefs.Endpoints.GET_FEATURES_BY_VEHICLE_BY_ID_PAGE, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleFeature.class, pageHandlerClass = VehicleFeatureListPageHandler.class)
    public BaseResponse listVehicleFeaturesByVehicle(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                                     VehicleFeature requestObject, VehicleFeatureListPageHandler vehicleFeatureListPageHandler) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
//		vList=VehicleFeatureDAO.listVehiclesByFeatureID(logger, blModServices.getDBManager(), requestObject.getVehicleid());
//		return vList;
            vehicleFeatureListPageHandler.listVehicleFeatureByID(logger, blModServices.getDBManager(), requestObject.getVehicleid());
        } catch (DBException e) {
            vList.setErrorMessage("Error with the details given");
            vList.setErrorCode("1");
            return vList;
        }
        return null;
    }

    @BEndpoint(uri = HVDefs.Endpoints.UPLOAD_VEHICLES_FEATUERS, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = UploadedFile.class)
    public BaseResponse createVehicleFeatures(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                              UploadedFile requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        UploadedFile.validate(requestObject);
        logger.debug(requestObject.getFileName() + " with length " + requestObject.getB64Contents().getUTF8String().length());
        byte[] decBytes = blModServices.getUtilFactory().getNewCryptoService().base64Decode(requestObject.getB64Contents().getUTF8String());
        UTF8String utfStr = new UTF8String(new String(decBytes));
        StringReader sr = new StringReader(utfStr.getUTF8String());
        BCSVReader csvReader = blModServices.getUtilFactory().getNewLargeCSVReader(sr, ',', 1);
        List<VinFeature> vehiclesFeatures = new ArrayList<VinFeature>();
        List<VehicleFeature> vehicleFeaturesValidated = new ArrayList<VehicleFeature>();
        while (true) {
            Row row = csvReader.getNextRow(logger);
            if (row == null) {
                break;
            }
            VinFeature v = Util.createVehicleFeature(row);
            vehiclesFeatures.add(v);
        }
        try {
            List<String> getVehicleList = vehiclesFeatures.stream().map(e -> e.getVIN().toString()).distinct().collect(Collectors.toList());
            VehiclesList vehicleList = VehicleDAO.geAllMasterVehicleVinData(logger, blModServices.getDBManager(), getVehicleList.toString().replace("[", "").replace("]", ""));
            if (vehicleList.getErrorCode().equals("1")) {
                return vehicleList;
            }
            vehicleFeaturesValidated = getFeatureData(vehicleList.getVehicles(), vehiclesFeatures);
            vList = VehicleFeatureDAO.insertVehiclesFeaturesCSV(logger, blModServices.getDBManager(), vehicleFeaturesValidated);
        } catch (DBException e) {
            vList.setErrorMessage("Error while uploading - " + e.getMessage());
            vList.setErrorCode("1");
            throw new BExceptions(e, HVSProcessingCode.DUPLICATE_VEHICLES);
        }
        return vList;
    }


    @BEndpoint(uri = HVDefs.Endpoints.INSERT_ALL_FEATURES, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VinFeature.class)
    public BaseResponse insertAllVehicleFeatures(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                                 VinFeature requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();

        try {
            List<VehicleFeature> vehicleFeaturesValidated = new ArrayList<VehicleFeature>();
            List<VinFeature> vehiclesFeatures = new ArrayList<VinFeature>();
            vehiclesFeatures.add(requestObject);
            List<String> getVehicleList = vehiclesFeatures.stream().map(e -> e.getVIN().toString()).distinct().collect(Collectors.toList());
            VehiclesList vehicleList = VehicleDAO.geAllMasterVehicleVinData(logger, blModServices.getDBManager(), getVehicleList.toString().replace("[", "").replace("]", ""));
            if (vehicleList.getErrorCode().equals("1")) {
                return vehicleList;
            }

            vehicleFeaturesValidated = getFeatureData(vehicleList.getVehicles(), vehiclesFeatures);
            vList = VehicleFeatureDAO.insertVehiclesFeaturesCSV(logger, blModServices.getDBManager(), vehicleFeaturesValidated);

        } catch (DBException e) {
            vList.setErrorMessage("Error while Inserting Vin Feature Data - " + e.getMessage());
            vList.setErrorCode("1");
            throw new BExceptions(e, HVSProcessingCode.DUPLICATE_VEHICLES);
        }
        return vList;
    }
}