package com.bundee.hvs.utils;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.bundee.hvs.defs.*;
import com.bundee.hvs.pojo.*;
import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.UTF8String;
import com.bundee.msfw.interfaces.utili.csv.Column;
import com.bundee.msfw.interfaces.utili.csv.Row;
import com.google.gson.Gson;
import org.json.JSONObject;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

public class Util {
	private static class VehicleColumns {
		public static final int C_VIN = 0;
		public static final int C_MAKE = 1;
		public static final int C_MODEL = 2;		
		public static final int C_DESC = 3;		
		public static final int C_YEAR = 4;		
		public static final int C_VT = 5;
		public static final int C_LOC_ID = 6;		
		public static final int C_VNUM = 7;		
		public static final int C_VCOL = 8;	
		
		public static final int C_LAST_COL_ID = 8;	
	}

	private static class VINColumns {
		public static final int C_VIN = 0;
		public static final int C_PRICE = 1;
		
		public static final int C_LAST_COL_ID = 1;	
	}



	
	public static Vehicle createVehicle(Row row) throws BExceptions {
		Vehicle vehicle = new Vehicle();
		Map<Integer, Column> columns = row.getColumns();
		int maxColumnID = row.getMaxColumnID();
		if(maxColumnID < VehicleColumns.C_LAST_COL_ID) {
			throw new BExceptions(HVSProcessingCode.INVALID_VEHICLE_FILE, row.getRowID() + " has less columns than expected " + maxColumnID);
		}

		Column col = columns.get(VehicleColumns.C_VIN);
		vehicle.setVin(col.getStrValue());
		col = columns.get(VehicleColumns.C_MAKE);
		vehicle.setMake(col.getStrValue());
		col = columns.get(VehicleColumns.C_MODEL);
		vehicle.setModel(col.getStrValue());
		col = columns.get(VehicleColumns.C_DESC);
		vehicle.setDesc(col.getStrValue());
		col = columns.get(VehicleColumns.C_YEAR);
		vehicle.setYear(col.getStrValue());
		col = columns.get(VehicleColumns.C_VT);
		vehicle.setTypeID(1);
		col = columns.get(VehicleColumns.C_VNUM);
		vehicle.setNumber(col.getStrValue());
		col = columns.get(VehicleColumns.C_VCOL);
		vehicle.setColor(col.getStrValue());
		
		return vehicle;
	}

	public static void createVINs(Row row, Map<UTF8String, Double> vinsMap) throws BExceptions {
		Map<Integer, Column> columns = row.getColumns();
		int maxColumnID = row.getMaxColumnID();
		if(maxColumnID < VINColumns.C_LAST_COL_ID) {
			throw new BExceptions(HVSProcessingCode.INVALID_VINS, row.getRowID() + " has less columns than expected " + maxColumnID);
		}

		Column col = columns.get(VINColumns.C_VIN);
		UTF8String vin = col.getStrValue();
		col = columns.get(VINColumns.C_PRICE);
		double price = col.getDoubleValue();
		vinsMap.put(vin, price);
	}
	public static Integer getHostDetails(int userId, List<UserResponse> userResponse) {
		try {
			RestTemplate restTemplate = new RestTemplate();
			String checkBookingUrl = HostVehicleRestURIs.Endpoints.GET_USER_BY_ID;

			JSONObject jsonObject = new JSONObject();
			jsonObject.put("iduser", userId);

			String jsonString = jsonObject.toString();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> entity = new HttpEntity<String>(jsonString, headers);
			ResponseEntity<String> resultBookingList = restTemplate.exchange(checkBookingUrl, HttpMethod.POST,
					entity, String.class);

			String responseBookingBody = resultBookingList.getBody();
			Gson gson = new Gson();
			UserList bookingObjResponse = gson.fromJson(responseBookingBody, UserList.class);

			if (Objects.equals(bookingObjResponse.getErrorCode(), "0")) {
				userResponse.add(bookingObjResponse.getUserResponse());
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			return 0;
		}
	}
	public static VinFeature createVehicleFeature(Row row) throws BExceptions {
		VinFeature vehicle = new VinFeature();
		Map<Integer, Column> columns = row.getColumns();
		int maxColumnID = row.getMaxColumnID();
		if (maxColumnID < VINFeaturesColumns.C_LAST_COL_ID) {
			throw new BExceptions(HVSProcessingCode.INVALID_VEHICLE_FILE, row.getRowID() + " has less columns than expected " + maxColumnID);
		}
		Column col = columns.get(VINFeaturesColumns.C_VIN);
		vehicle.setVIN(col.getStrValue());
		col = columns.get(VINFeaturesColumns.C_MAKE);
		vehicle.setMAKE(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_MANUFACTURE);
		vehicle.setManufacture(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_MODEL);
		vehicle.setModel(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_MODEL_YEAR);
		vehicle.setModelYear(col.getDoubleValue());
		col=columns.get(VINFeaturesColumns.C_PLANT_CITY);
		vehicle.setPlantcity(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_SERIES);
		vehicle.setSeries(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_TRIM);
		vehicle.setTrim(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_VEHICLETYPE);
		vehicle.setVehicletype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_PLANT_COUNTRY);
		vehicle.setPlantcountry(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_NOTE);
		vehicle.setNote(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_BODY_CLASS);
		vehicle.setBodyclass(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_DOORS);
		vehicle.setDoors(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_GROSS_VEHICLE);
		vehicle.setGrossweightratingtype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_BED_TYPE);
		vehicle.setBedtype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_CAB_TYPE);
		vehicle.setCabtype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_TRAILERTYPE);
		vehicle.setTrailertype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_CAB_TYPE);
		vehicle.setCabtype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_TRAILER_TYPE_CONNECTION);
		vehicle.setTrailertype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_TRAILER_BODY_TYPE);
		vehicle.setTrailertype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_ENGINE_NUMBER_OF_CYLINDERS);
		vehicle.setEnginenumberofcylinders(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_DISPLICEMENTCC);
		vehicle.setDisplacementcc(col.getDoubleValue());
		col=columns.get(VINFeaturesColumns.C_DISPLICEMENTCI);
		vehicle.setDisplacementci(col.getDoubleValue());
		col=columns.get(VINFeaturesColumns.C_DISPLICEMENTl);
		vehicle.setDisplacementtl(col.getDoubleValue());
		col=columns.get(VINFeaturesColumns.C_ENGINE_POWER);
		vehicle.setEnginepower(col.getDoubleValue());
		col=columns.get(VINFeaturesColumns.C_FUEL_TYPE_PRIMARY);
		vehicle.setFueltypeprimary(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_ENGINE_BRAKE_FORM);
		vehicle.setEnginebreakform(col.getDoubleValue());
		col=columns.get(VINFeaturesColumns.C_SEAT_BELT_TYPE);
		vehicle.setSeatbelttype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_OTHER_RESTRAINT_SYSTEM_INFO);
		vehicle.setOtherrestraintsysteminformation(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_FRONT_AIR_BAG_LOCATIONS);
		vehicle.setfrontairbaglocations(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_KNEE__AIR_BAG_LOCATIONS);
		vehicle.setKneeairbaglocations(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_SIDE__AIR_BAG_LOCATIONS);
		vehicle.setSideairbaglocations(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_FLOOR_CONFIGURATION_TYPE);
		vehicle.setFloorconfigurationtype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_TIRE_PRESSURE_MONITORING_SYSTEM_);
		vehicle.setTirepressureconfigurationsystem(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_BUS_FLOOR_CONFIGURATION_SYSTEM);
		vehicle.setFloorconfigurationtype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_NUMBER_OF_WHEELS);
		vehicle.setNumberofwheels(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_WHEEL_BASE_FROM);
		vehicle.setWheelbaseform(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_BRAKE_SYSTEM_TYPE);
		vehicle.setBreaksystemtype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_BASE_PRICE);
		vehicle.setBaseprice(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_CURRENT_AIR_BAG_LOCATIONS);
		vehicle.setCurrentairbaglocation(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_CUSTOM_MOTORCYCLE_TYPE);
		vehicle.setCustommotorcycletype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_BUS_FLOOR);
		vehicle.setBusfloor(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_BUS_TYPE);
		vehicle.setBustype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_MOTORCYCLE_SUSPENSION_TYPE);
		vehicle.setCustommotorcycletype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_MOTORCYCLE_CHASSIS_TYPE);
		vehicle.setMotorcyclechasistype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_PLANT_COMPANY_NAME);
		vehicle.setPlantcompanyname(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_ENGINE_CONFIGURATION);
		vehicle.setEngineconfiguration(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_PLANT_STATE);
		vehicle.setPlantstate(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_STERING_LOCATION);
		vehicle.setSteringlocation(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_DRIVETYPE);
		vehicle.setDrivetype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_ELECTRIFICATION_TYPE);
		vehicle.setElecrtrificationtype(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_OTHER_ENGINE_INFO);
		vehicle.setOtherengineeinformation(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_TURBO);
		vehicle.setTurbo(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_ENGINE_MANUFACTURER);
		vehicle.setEngineemanufacture(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_SERIES2);
		vehicle.setSeries2(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_WINDOWS);
		vehicle.setWindows(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_CURTON_AIR_BAG_LOCATION);
		vehicle.setCurrentairbaglocation(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_WHEEL_SIZE_FRONT);
		vehicle.setWheelsizefront(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_WHEEL_SIZE_REAR);
		vehicle.setWheelsizerear(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_NUMBER_OF_SEATS);
		vehicle.setNumberofseats(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_TRANSMISSION_STYLE);
		vehicle.setTransmissionstyle(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_AXLES);
		vehicle.setAxles(col.getIntValue());
		col=columns.get(VINFeaturesColumns.C_ANTI_LOCK_BRAKING_SYSTEM);
		vehicle.setAntilockbrakingsystem(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_ELECTRONIC_STATIBILITY_CONROL);
		vehicle.setElectronicstabilitysystem(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_ACTIVE_SAFTEY_SYSTEM_NOTE);
		vehicle.setAcivesafteysystemnote(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_BACK_UP_CAMER);
		vehicle.setBackupcamer(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_DAY_TIME_RUNNING_LIGHT);
		vehicle.setDaytimerunninglight(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_PRETENSIONER);
		vehicle.setPretensioner(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_VEHICLE_DESCRIPTION);
		vehicle.setVehicleDescription(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_SEATING_CAPACITY);
		vehicle.setSeatingCapacity(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_INSURANCE_HEADER);
		vehicle.setInsuranceHeader(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_INSURANCE_HEADER_TYPE);
		vehicle.setInsuranceHeaderType(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_INSURANCE_DETAILS1);
		vehicle.setInsuranceDetails1(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_INSURANCE_DETAILS2);
		vehicle.setInsuranceDetails2(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_INSURANCE_DETAILS3);
		vehicle.setInsuranceDetails3(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_GUIDELINES);
		vehicle.setGuidelines(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_CANCELLATION_POLICY_TEXT);
		vehicle.setGuidelines(col.getStrValue());
		col=columns.get(VINFeaturesColumns.C_PARKING_DETAILS);
		vehicle.setParkingDetails(col.getStrValue());
		return vehicle;
	}
	public static VinImages createVehicleImages(Row row) throws BExceptions {
		VinImages vehicle = new VinImages();
		Map<Integer, Column> columns = row.getColumns();
		int maxColumnID = row.getMaxColumnID();
		if (maxColumnID < VINFeaturesColumns.C_LAST_COL_ID) {
			throw new BExceptions(HVSProcessingCode.INVALID_VEHICLE_FILE, row.getRowID() + " has less columns than expected " + maxColumnID);
		}
		Column col = columns.get(VINImagesColumns.C_VIN);
		vehicle.setVIN(col.getStrValue());
		col = columns.get(VINImagesColumns.C_VINIMAGEPATH);
		vehicle.setIMAGEPATH(col.getStrValue());


		return vehicle;
	}
	private static class VINImagesColumns {
		public static final int C_VIN = 0;
		public static final int C_VINIMAGEPATH = 1;

		public static final int C_LAST_COL_ID = 1;
	}
	private static class VINFeaturesColumns {
		public static final int C_VIN = 0;
		public static final int C_MAKE = 1;
		public static final int C_MANUFACTURE = 2;
		public static final int C_MODEL = 3;
		public static final int C_MODEL_YEAR = 4;
		public static final int C_PLANT_CITY = 5;
		public static final int C_SERIES = 6;
		public static final int C_TRIM = 7;
		public static final int C_VEHICLETYPE = 8;
		public static final int C_PLANT_COUNTRY = 9;
		public static final int C_NOTE = 10;
		public static final int C_BODY_CLASS = 11;
		public static final int C_DOORS = 12;

		public static final int C_GROSS_VEHICLE = 13;
		public static final int C_BED_TYPE = 14;
		public static final int C_CAB_TYPE = 15;
		public static final int C_TRAILERTYPE = 16;
		public static final int C_TRAILER_TYPE_CONNECTION = 17;
		public static final int C_TRAILER_BODY_TYPE = 18;
		public static final int C_ENGINE_NUMBER_OF_CYLINDERS = 19;
		public static final int C_DISPLICEMENTCC = 20;
		public static final int C_DISPLICEMENTCI = 21;
		public static final int C_DISPLICEMENTl = 22;
		public static final int C_ENGINE_POWER = 23;
		public static final int C_FUEL_TYPE_PRIMARY = 24;
		public static final int C_ENGINE_BRAKE_FORM = 25;
		public static final int C_SEAT_BELT_TYPE = 26;
		public static final int C_OTHER_RESTRAINT_SYSTEM_INFO = 27;
		public static final int C_FRONT_AIR_BAG_LOCATIONS = 28;
		public static final int C_KNEE__AIR_BAG_LOCATIONS  = 29;
		public static final int C_SIDE__AIR_BAG_LOCATIONS  = 30;
		public static final int C_FLOOR_CONFIGURATION_TYPE = 31;
		public static final int C_TIRE_PRESSURE_MONITORING_SYSTEM_ = 32;
		public static final int C_BUS_FLOOR_CONFIGURATION_SYSTEM = 33;



		public static final int C_NUMBER_OF_WHEELS = 34;
		public static final int C_WHEEL_BASE_FROM = 35;
		public static final int C_BRAKE_SYSTEM_TYPE = 36;
		public static final int C_BASE_PRICE = 37;
		public static final int C_CURRENT_AIR_BAG_LOCATIONS =38;
		public static final int C_CUSTOM_MOTORCYCLE_TYPE = 39;
		public static final int C_BUS_FLOOR = 40;
		public static final int C_BUS_TYPE = 41;
		public static final int C_MOTORCYCLE_SUSPENSION_TYPE = 42;
		public static final int C_MOTORCYCLE_CHASSIS_TYPE= 43;
		public static final int C_PLANT_COMPANY_NAME =44;
		public static final int C_ENGINE_CONFIGURATION = 45;
		public static final int C_PLANT_STATE= 46;
		public static final int C_STERING_LOCATION = 47;
		public static final int C_DRIVETYPE = 48;
		public static final int C_ELECTRIFICATION_TYPE = 49;
		public static final int C_OTHER_ENGINE_INFO = 50;
		public static final int C_TURBO = 51;
		public static final int C_ENGINE_MANUFACTURER = 52;
		public static final int C_SERIES2 = 53;
		public static final int C_WINDOWS = 54;

		public static final int C_CURTON_AIR_BAG_LOCATION = 55;
		public static final int C_WHEEL_SIZE_FRONT = 56;
		public static final int C_WHEEL_SIZE_REAR = 57;
		public static final int C_NUMBER_OF_SEATS = 58;
		public static final int C_TRANSMISSION_STYLE = 59;
		public static final int C_AXLES = 60;
		public static final int C_ANTI_LOCK_BRAKING_SYSTEM = 61;
		public static final int C_ELECTRONIC_STATIBILITY_CONROL = 62;
		public static final int C_ACTIVE_SAFTEY_SYSTEM_NOTE = 63;
		public static final int C_BACK_UP_CAMER = 64;
		public static final int C_DAY_TIME_RUNNING_LIGHT = 65;

		public static final int C_PRETENSIONER = 67;
		public static final int C_VEHICLE_DESCRIPTION = 68;
		public static final int C_SEATING_CAPACITY = 69;
		public static final int C_INSURANCE_HEADER = 70;
		public static final int C_INSURANCE_HEADER_TYPE = 71;
		public static final int C_INSURANCE_DETAILS1 = 72;
		public static final int C_INSURANCE_DETAILS2 = 73;
		public static final int C_INSURANCE_DETAILS3 = 74;
		public static final int C_GUIDELINES = 75;
		public static final int C_CANCELLATION_POLICY_TEXT = 76;
		public static final int C_PARKING_DETAILS = 77;
		public static final int C_LAST_COL_ID = 77;
	}
}
