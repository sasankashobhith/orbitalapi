package com.bundee.hvs.pojo;

public class VINDataGenInput {
	public int startVIN;
	public int numVINs;
}
