package com.bundee.hvs.pojo;

import java.util.ArrayList;
import java.util.List;

public class CustomerVehicleResponse {
    List<MasterVehicleImageResponse> imageresponse = new ArrayList<MasterVehicleImageResponse>();
    private int userid;
    private int id;
    private String vin;
    private String make;
    private String model;
    private String description;
    private String year;
    private int vehicle_type_id;
    private int vhost;
    private int branchid;
    private String vnumber;
    private String vcolor;
    private boolean isactive;
    private String crtd_ts;
    private String updtd_ts;
    private String vehiclelattitude;
    private String vehiclelongitude;
    private boolean isfavourite;
    private int vehicleid;
    private double vehiclePrice;

    public double getVehiclePrice() {
        return vehiclePrice;
    }

    public void setVehiclePrice(double vehiclePrice) {
        this.vehiclePrice = vehiclePrice;
    }

    public List<MasterVehicleImageResponse> getImageresponse() {
        return imageresponse;
    }

    public void setImageresponse(List<MasterVehicleImageResponse> imageresponse) {
        this.imageresponse = imageresponse;
    }

    public int getVehicleid() {
        return vehicleid;
    }

    public void setVehicleid(int vehicleid) {
        this.vehicleid = vehicleid;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getVehicle_type_id() {
        return vehicle_type_id;
    }

    public void setVehicle_type_id(int vehicle_type_id) {
        this.vehicle_type_id = vehicle_type_id;
    }

    public int getVhost() {
        return vhost;
    }

    public void setVhost(int vhost) {
        this.vhost = vhost;
    }

    public int getBranchid() {
        return branchid;
    }

    public void setBranchid(int branchid) {
        this.branchid = branchid;
    }

    public String getVnumber() {
        return vnumber;
    }

    public void setVnumber(String vnumber) {
        this.vnumber = vnumber;
    }

    public String getVcolor() {
        return vcolor;
    }

    public void setVcolor(String vcolor) {
        this.vcolor = vcolor;
    }

    public boolean isIsactive() {
        return isactive;
    }

    public void setIsactive(boolean isactive) {
        this.isactive = isactive;
    }

    public String getCrtd_ts() {
        return crtd_ts;
    }

    public void setCrtd_ts(String crtd_ts) {
        this.crtd_ts = crtd_ts;
    }

    public String getUpdtd_ts() {
        return updtd_ts;
    }

    public void setUpdtd_ts(String updtd_ts) {
        this.updtd_ts = updtd_ts;
    }

    public String getVehiclelattitude() {
        return vehiclelattitude;
    }

    public void setVehiclelattitude(String vehiclelattitude) {
        this.vehiclelattitude = vehiclelattitude;
    }

    public String getVehiclelongitude() {
        return vehiclelongitude;
    }

    public void setVehiclelongitude(String vehiclelongitude) {
        this.vehiclelongitude = vehiclelongitude;
    }

    public boolean isIsfavourite() {
        return isfavourite;
    }

    public void setIsfavourite(boolean isfavourite) {
        this.isfavourite = isfavourite;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }
}
