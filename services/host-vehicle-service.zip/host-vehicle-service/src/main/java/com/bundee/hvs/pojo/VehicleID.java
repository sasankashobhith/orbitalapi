package com.bundee.hvs.pojo;

public class VehicleID {
	public Integer vehicleId;
	public String fromvalue;
	public Integer id;
	public Integer idimage;
	public Integer userid;

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public Integer getIdimage() {
		return idimage;
	}

	public void setIdimage(Integer idimage) {
		this.idimage = idimage;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFromvalue() {
		return fromvalue;
	}

	public void setFromvalue(String fromvalue) {
		this.fromvalue = fromvalue;
	}

	public Integer getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Integer vehicleId) {
		this.vehicleId = vehicleId;
	}
}
