package com.bundee.hvs.db;

import com.bundee.hvs.pojo.VehicleFeature;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.msfw.defs.UTF8String;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.dbi.DBManager;
import com.bundee.msfw.interfaces.dbi.DBQuery;
import com.bundee.msfw.interfaces.dbi.DBQueryBuilder;
import com.bundee.msfw.interfaces.logi.BLogger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class VehicleFeatureDAO {
//private static final String LIST_VEHICLEFEATURES ="select * from vehiclefeatures where vehicleid=?";

    private static final String GET_FEATURES_BY_VEHICLE_ID = "select * from vehiclefeatures where vehicleid=? and isactive=true";
    private static final String GET_FEATURES_BY_ID = "select * from vehiclefeatures where vehiclefeatureid=? and isactive=true";
    private static final String GET_ALL_FEATURES = "select * from vehiclefeatures where isactive=true";
    private static final String INSERT_FEATURE = "INSERT INTO vehiclefeatures (vehicleid, featurename, featuredescription, userid) VALUES (?, ?, ?, ?);";
    private static final String UPDATE_FEATURES = "UPDATE vehiclefeatures SET vehicleid=?, featurename=?, featuredescription=?, userid=?, updateddate=? WHERE vehiclefeatureid=?";
    private static final String GET_FEATURES_BY_IDS = "select * from vehiclefeatures where vehiclefeatureid=any(?) and isactive is true";


    public static VehiclesList listVehiclesByFeatureID(BLogger logger, DBManager dbm, int vehicleid, List<VehicleFeature> vehicles) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicleid==0) {
            vehiclesList.setErrorMessage("Error with the details given");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(GET_FEATURES_BY_VEHICLE_ID).setBindInputFunction((dbBLogger, ps) -> {
                ps.setInt(1, vehicleid);
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehicles.add(createvehiclefeatures(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data retrieved successfully");
            vehiclesList.getVehiclefeatures().addAll(vehicles);
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorCode("1");
            vehiclesList.setErrorMessage("Error in Master Request");
            return vehiclesList;
        }
    }

    private static VehicleFeature createvehiclefeatures(BLogger logger, ResultSet rs) throws SQLException {
        VehicleFeature vehicle = new VehicleFeature();
        vehicle.setVehiclefeatureid(rs.getInt("vehiclefeatureid"));
        vehicle.setVehicleid(rs.getInt("vehicleid"));
        vehicle.setFeaturename(new UTF8String(rs.getString("featurename")));
        vehicle.setFeaturedescription(new UTF8String(rs.getString("featuredescription")));
        vehicle.setUserid(rs.getInt("userid"));
        vehicle.setCreateddate(new UTF8String(rs.getString("createddate")));
        vehicle.setUpdateddate(new UTF8String(rs.getString("updateddate")));
        vehicle.setActive(rs.getBoolean("isactive"));
        return vehicle;
    }
    public static VehiclesList listFeaturesByID(BLogger logger, DBManager dbm, int id, List<VehicleFeature> vehicles) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || id==0) {
            vehiclesList.setErrorMessage("Error with the details given");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(GET_FEATURES_BY_ID).setBindInputFunction((dbBLogger, ps) -> {
                ps.setInt(1, id);
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehicles.add(createvehiclefeatures(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data inserted successfully");
            vehiclesList.getVehiclefeatures().addAll(vehicles);
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorCode("1");
            vehiclesList.setErrorMessage("Error in Master Request"+e.getMessage());
            return vehiclesList;
        }
    }
    public static VehiclesList listAllFeatures(BLogger logger, DBManager dbm, List<VehicleFeature> vehicles) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null) {
            vehiclesList.setErrorMessage("Error with the details given");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(GET_ALL_FEATURES).setBindInputFunction((dbBLogger, ps) -> {
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehicles.add(createvehiclefeatures(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data inserted successfully");
            vehiclesList.getVehiclefeatures().addAll(vehicles);
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorCode("1");
            vehiclesList.setErrorMessage("Error in Master Request"+e.getMessage());
            return vehiclesList;
        }
    }
    public static VehiclesList insertFeatures(BLogger logger, DBManager dbm, VehicleFeature vehicleFeature) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicleFeature==null||vehicleFeature.getVehicleid()==0||vehicleFeature.getFeaturename()==null||vehicleFeature.getFeaturedescription()==null||vehicleFeature.getUserid()==0) {
            vehiclesList.setErrorMessage("Error with the details given");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(INSERT_FEATURE).setBindInputFunction((dbBLogger, ps) -> {
                ps.setInt(1, vehicleFeature.getVehicleid());
                ps.setString(2, vehicleFeature.getFeaturename().toString());
                ps.setString(3, vehicleFeature.getFeaturedescription().toString());
                ps.setInt(4, vehicleFeature.getUserid());
            }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getVehiclefeatures().add(createvehiclefeatures(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.update(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data inserted successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorCode("1");
            vehiclesList.setErrorMessage("Error in Master Request"+e.getMessage());
            return vehiclesList;
        }
    }
    public static VehiclesList updateFeatures(BLogger logger, DBManager dbm, VehicleFeature vehicleFeature) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicleFeature==null||vehicleFeature.getVehicleid()==0||vehicleFeature.getFeaturename()==null||vehicleFeature.getFeaturedescription()==null||vehicleFeature.getUserid()==0||vehicleFeature.getVehiclefeatureid()==0) {
            vehiclesList.setErrorMessage("Error with the details given");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            Date date = new Date();
            java.sql.Date sqlDate = new java.sql.Date(date.getTime());
            java.sql.Timestamp updatedTime = new java.sql.Timestamp(sqlDate.getTime());
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(UPDATE_FEATURES).setBindInputFunction((dbBLogger, ps) -> {
                ps.setInt(1, vehicleFeature.getVehicleid());
                ps.setString(2, vehicleFeature.getFeaturename().toString());
                ps.setString(3, vehicleFeature.getFeaturedescription().toString());
                ps.setInt(4, vehicleFeature.getUserid());
                ps.setTimestamp(5,updatedTime);
                ps.setInt(6, vehicleFeature.getVehiclefeatureid());
            }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getVehiclefeatures().add(createvehiclefeatures(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.update(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data updated successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorCode("1");
            vehiclesList.setErrorMessage("Error in updated Request"+e.getMessage());
            return vehiclesList;
        }
    }
    public static void listVehiclesByFeatureIDs(BLogger logger, DBManager dbm, int vehicleid,List<Long> featureIDs) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicleid==0) {
            vehiclesList.setErrorMessage("Error with the details given");
            vehiclesList.setErrorCode("1");
//            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(GET_FEATURES_BY_VEHICLE_ID).setBindInputFunction((dbBLogger, ps) -> {
                ps.setInt(1, vehicleid);
            }).setFetchDataFunction((dbFLogger, rs) -> {
                featureIDs.add((long)rs.getInt("vehiclefeatureid"));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data inserted successfully");
//            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorCode("1");
            vehiclesList.setErrorMessage("Error in Master Request");
//            return vehiclesList;
        }
    }
    public static VehiclesList listFeaturesByIDs(BLogger logger, DBManager dbm, List<Long> ids) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || ids.size()==0) {
            vehiclesList.setErrorMessage("Error with the details given");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(GET_FEATURES_BY_IDS).setBindInputFunction((dbBLogger, ps) -> {
                ps.setArray(1, ps.getConnection().createArrayOf("int", ids.toArray()));
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getVehiclefeatures().add(createvehiclefeatures(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data inserted successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorCode("1");
            vehiclesList.setErrorMessage("Error in Master Request"+e.getMessage());
            return vehiclesList;
        }
    }
    public static VehiclesList insertVehiclesFeaturesCSV(BLogger logger, DBManager dbm, Collection<VehicleFeature> vehiclesFeatures)
            throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehiclesFeatures == null) {
            vehiclesList.setErrorMessage("Error retrieving Vehicle Features details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setBatch().setQueryString(INSERT_FEATURE).setBindInputFunction((dbLogger, ps) -> {
                for (VehicleFeature v : vehiclesFeatures) {

                    ps.setInt(1, v.getVehicleid());
                    ps.setString(2, v.getFeaturename().toString());
                    ps.setString(3, v.getFeaturedescription().toString());
                    ps.setInt(4, v.getUserid());



                    ps.addBatch();
                }
            }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getVehiclefeatures().add(createvehiclefeatures(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();

            dbm.update(logger, sq);

            vehiclesList.setErrorMessage("Inserted Successfully ");
            vehiclesList.setErrorCode("0");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving Vehicle Features details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;

        }
    }
}