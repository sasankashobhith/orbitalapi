package com.bundee.hvs.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.bundee.hvs.pojo.VehicleType;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.hvs.pojo.VinzipcodeResponse;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.dbi.DBManager;
import com.bundee.msfw.interfaces.dbi.DBQuery;
import com.bundee.msfw.interfaces.dbi.DBQueryBuilder;
import com.bundee.msfw.interfaces.logi.BLogger;


public class VehicleZipCodeDAO {

	private static final String INSERT_VINXZIPCODE = "insert into vinxzipcode (vin,vehicleid,zipcode,hostid) values (?,?,?,?)";

	private static final String GET_ALL = "select * from vinxzipcode where isactive=true";

	private static final String VINZIPCODE_BY_ID = "select  * FROM vinxzipcode WHERE id=? and isactive=true";

	private static final String VINZIPCODE_BY_VEHICLEID = "select  * FROM vinxzipcode WHERE vehicleid=? and isactive=true";
	
	private static final String UPDATE_VINZIPCODE = "UPDATE vinxzipcode set zipcode=?,isactive=?,updateddate=? WHERE vehicleid=? and isactive=true";


	public static VehiclesList insertVinZipcode(BLogger logger, DBManager dbm, VinzipcodeResponse vinzipcode)
			throws DBException {
		VehiclesList vehiclesList = new VehiclesList();
		if (dbm == null || vinzipcode == null|| vinzipcode.getVin()==null||vinzipcode.getVehicleid()==0|| vinzipcode.getZipcode()==null||vinzipcode.getHostid()==0) {
			vehiclesList.setErrorMessage("Error with the details given");
			vehiclesList.setErrorCode("1");
			return vehiclesList;
		}
		try {
			DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
			DBQuery sq = dbQB.setQueryString(INSERT_VINXZIPCODE).setBindInputFunction((dbBLogger, ps) -> {
				ps.setString(1, vinzipcode.getVin());
				ps.setInt(2, vinzipcode.getVehicleid());
				ps.setString(3, vinzipcode.getZipcode());
				ps.setInt(4, vinzipcode.getHostid());
			}).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
				vehiclesList.getVinzipcoderesponse().add(createdvinzipcode(dbFLogger, rs));
			}).logQuery(true).throwOnNoData(false).build();
			dbm.update(logger, sq);
			vehiclesList.setErrorCode("0");
			vehiclesList.setErrorMessage("Data inserted successfully");
			return vehiclesList;
		} catch (Exception e) {
			vehiclesList.setErrorCode("1");
			vehiclesList.setErrorMessage("Error in Master Request" + e.getMessage());
			return vehiclesList;
		}
	}

	private static VinzipcodeResponse createdvinzipcode(BLogger logger, ResultSet rs) throws SQLException {
		VinzipcodeResponse VinzipcodeResponse = new VinzipcodeResponse();

		VinzipcodeResponse.setId(rs.getInt("id"));
		VinzipcodeResponse.setVin(rs.getString("vin"));
		VinzipcodeResponse.setVehicleid(rs.getInt("vehicleid"));
		VinzipcodeResponse.setZipcode(rs.getString("zipcode"));
		VinzipcodeResponse.setHostid(rs.getInt("hostid"));
		VinzipcodeResponse.setIsactive(rs.getBoolean("isactive"));
		VinzipcodeResponse.setCreateddate(rs.getString("createddate"));
		VinzipcodeResponse.setUpdateddate(rs.getString("updateddate"));

		return VinzipcodeResponse;
	}

	public static VehiclesList getAllVinZipcode(BLogger logger, DBManager dbm, VehiclesList vehiclesList)

			throws DBException {
		try {
			DBQueryBuilder dbQB = dbm.getDBQueryBuilder();

			DBQuery sq = dbQB.setQueryString(GET_ALL).setBindInputFunction((dbBLogger, ps) -> {
			}).setFetchDataFunction((dbFLogger, rs) -> {
				vehiclesList.getVinzipcoderesponse().add(createdvinzipcode(dbFLogger, rs));
			}).logQuery(true).throwOnNoData(false).build();
			dbm.select(logger, sq);
			vehiclesList.setErrorCode("0");
			vehiclesList.setErrorMessage("Data retrieved successfully");
			return vehiclesList;
		} catch (Exception e) {
			vehiclesList.setErrorMessage("Error retrieving all VehicleZipcode details - " + e.getMessage());
			vehiclesList.setErrorCode("1");
			return vehiclesList;
		}
	}

	public static VehiclesList getVinZipCodebyid(BLogger logger, DBManager dbm, VehicleType resObject,

			List<VinzipcodeResponse> vinzipcoderesponse) throws DBException {
		VehiclesList bookResponse = new VehiclesList();

		if (dbm == null || resObject == null || resObject.getFromvalue() == null || resObject.getId() == 0) {
			bookResponse.setErrorCode("1");
			bookResponse.setErrorMessage("Invalid Input Request");
			return bookResponse;
		}
		try {

			String queryString = "NA";

			if (resObject.getFromvalue().toLowerCase().equals("id")) {
				queryString = VINZIPCODE_BY_ID;

			} else if (resObject.getFromvalue().toLowerCase().equals("vehicleid")) {
				queryString = VINZIPCODE_BY_VEHICLEID;

			} else {
				bookResponse.setErrorCode("1");
				bookResponse.setErrorMessage("Invalid Input Request");
				return bookResponse;
			}

			if (queryString.equals("NA")) {
				bookResponse.setErrorCode("1");
				bookResponse.setErrorMessage("Invalid Input Request");
				return bookResponse;
			}

			DBQueryBuilder dbQB = dbm.getDBQueryBuilder();

			DBQuery sq = dbQB.setQueryString(queryString).setBindInputFunction((dbLogger, ps) -> {

				if (resObject.getFromvalue().toLowerCase().equals("id")) {
					ps.setInt(1, resObject.getId());
				} else if (resObject.getFromvalue().toLowerCase().equals("vehicleid")) {
					ps.setInt(1, resObject.getId());

				}

			}).setFetchDataFunction((dbFLogger, rs) -> {

				vinzipcoderesponse.add(createdvinzipcode(dbFLogger, rs));

			}).logQuery(true).throwOnNoData(false).build();

			dbm.select(logger, sq);
			bookResponse.setErrorCode("0");
			bookResponse.setErrorMessage("Data retrieved Succesfully");
			bookResponse.setVinzipcoderesponse(vinzipcoderesponse);
			return bookResponse;

		} catch (Exception e) {
			bookResponse.setErrorCode("1");
			bookResponse.setErrorMessage("Error in VinZipCode Request exception" + e.getMessage());
			return bookResponse;
		}
	}
	
	
	
	
	
	public static VehiclesList updatevinzipcode(BLogger logger, DBManager dbm,
			VinzipcodeResponse vinzipcoderesponse) throws DBException {
		VehiclesList bookResponse = new VehiclesList();
		if (dbm == null || vinzipcoderesponse == null||vinzipcoderesponse.getZipcode()==null||vinzipcoderesponse.getVehicleid()==0) {
			bookResponse.setErrorCode("1");
			bookResponse.setErrorMessage("Error in PushNotification  Request");
			return bookResponse;
		}

		DBQueryBuilder dbQB = dbm.getDBQueryBuilder();

		try {
			
			

			Date starteddate = new SimpleDateFormat("yyyy-MM-dd").parse(vinzipcoderesponse.getUpdateddate());
			java.sql.Date sqlstarteddatetime = new java.sql.Date(starteddate.getTime());
			java.sql.Timestamp updateddate = new java.sql.Timestamp(sqlstarteddatetime.getTime());
			
			
			DBQuery sq = dbQB.setBatch().setQueryString(UPDATE_VINZIPCODE)
					.setBindInputFunction((dbLogger, ps) -> {
						{

							ps.setString(1, vinzipcoderesponse.getZipcode());
							ps.setBoolean(2, vinzipcoderesponse.getisIsactive());
							ps.setTimestamp(3, updateddate);
							ps.setInt(4, vinzipcoderesponse.getVehicleid());
							

							ps.addBatch();
						}
					}).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
						bookResponse.getVinzipcoderesponse().add(createdvinzipcode(dbFLogger, rs));
					}).logQuery(true).build();

			dbm.update(logger, sq);
			bookResponse.setErrorCode("0");
			bookResponse.setErrorMessage("Data updated Succesfully");

			return bookResponse;
		}

		catch (Exception e) {
			bookResponse.setErrorCode("1");
			bookResponse.setErrorMessage("Error in VinZipCode  Request exception" + e.getMessage());
			return bookResponse;
		}
	}

}
