package com.bundee.hvs.pojo;

import com.bundee.msfw.defs.BaseResponse;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

public class VehiclesList extends BaseResponse {
    String errorCode;
    String errorMessage;


    List<Vehicle> vehicles;
    List<VehicleHostDetail> vehicleHostDetails;
    List<BranchResponse> branchresponse;
    List<MasterBranch> masterBranches;
    List<VehicleFeature> vehiclefeatures;
    List<VehicleUnavailability> vehicleUnavailabilities;
    List<CustomerActivityResponse> customeractivityresponse;

    List<CustomerWishlistResponse> customerwishlist;
    List<Reservation> reserverList;


    List<VinzipcodeResponse> vinzipcoderesponse;

    List<MasterVehicleImageResponse>imageresponse;
    List<MasterVehiclePriceResponse> vehiclePriceresponse;
    List<CustomerVehicleResponse> customervehicleresponse;

    public List<Reservation> getReserverList() {
        return reserverList;
    }

    public void setReserverList(List<Reservation> reserverList) {
        this.reserverList = reserverList;
    }

    public List<CustomerVehicleResponse> getCustomervehicleresponse() {
        return customervehicleresponse;
    }

    public void setCustomervehicleresponse(List<CustomerVehicleResponse> customervehicleresponse) {
        this.customervehicleresponse = customervehicleresponse;
    }

    public List<MasterVehiclePriceResponse> getVehiclePriceresponse() {
        return vehiclePriceresponse;
    }

    public void setVehiclePriceresponse(List<MasterVehiclePriceResponse> vehiclePriceresponse) {
        this.vehiclePriceresponse = vehiclePriceresponse;
    }

    public List<MasterVehicleImageResponse> getImageresponse() {
        return imageresponse;
    }

    public void setImageresponse(List<MasterVehicleImageResponse> imageresponse) {
        this.imageresponse = imageresponse;
    }

    public List<VinzipcodeResponse> getVinzipcoderesponse() {
        return vinzipcoderesponse;
    }

    public void setVinzipcoderesponse(List<VinzipcodeResponse> vinzipcoderesponse) {
        this.vinzipcoderesponse = vinzipcoderesponse;
    }

    public List<CustomerActivityResponse> getCustomeractivityresponse() {
        return customeractivityresponse;
    }

    public void setCustomeractivityresponse(List<CustomerActivityResponse> customeractivityresponse) {
        this.customeractivityresponse = customeractivityresponse;
    }

    public List<CustomerWishlistResponse> getCustomerwishlist() {
        return customerwishlist;
    }

    public void setCustomerwishlist(List<CustomerWishlistResponse> customerwishlist) {
        this.customerwishlist = customerwishlist;
    }

    public List<VehicleUnavailability> getVehicleUnavailabilities() {
        return vehicleUnavailabilities;
    }

    public void setVehicleUnavailabilities(List<VehicleUnavailability> vehicleUnavailabilities) {
        this.vehicleUnavailabilities = vehicleUnavailabilities;
    }

    public List<VehicleFeature> getVehiclefeatures() {
        return vehiclefeatures;
    }

    public void setVehiclefeatures(List<VehicleFeature> vehiclefeatures) {
        this.vehiclefeatures = vehiclefeatures;
    }


    public VehiclesList() {
        vehicles = new ArrayList<Vehicle>();
        vehicleHostDetails = new ArrayList<VehicleHostDetail>();
        branchresponse = new ArrayList<BranchResponse>();
        masterBranches = new ArrayList<MasterBranch>();
        vehiclefeatures=new ArrayList<VehicleFeature>();
        vehicleUnavailabilities=new ArrayList<VehicleUnavailability>();
        customerwishlist=new ArrayList<CustomerWishlistResponse>() ;
        customeractivityresponse=new ArrayList<CustomerActivityResponse>();
        vehiclePriceresponse=new ArrayList<MasterVehiclePriceResponse>();
        imageresponse=new ArrayList<MasterVehicleImageResponse>();
        vinzipcoderesponse=new ArrayList<VinzipcodeResponse>();
        customervehicleresponse=new ArrayList<CustomerVehicleResponse>();
        reserverList=new ArrayList<Reservation>();
    }

    public List<MasterBranch> getMasterBranches() {
        return masterBranches;
    }

    public void setMasterBranches(List<MasterBranch> masterBranches) {
        this.masterBranches = masterBranches;
    }

    public List<BranchResponse> getBrannchresponse() {
        return branchresponse;
    }

    public void setBrannchresponse(List<BranchResponse> brannchresponse) {
        this.branchresponse = brannchresponse;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public List<VehicleHostDetail> getVehicleHostDetails() {
        return vehicleHostDetails;
    }

    public void setVehicleHostDetails(List<VehicleHostDetail> vehicleHostDetails) {
        this.vehicleHostDetails = vehicleHostDetails;
    }

    public List<Vehicle> getVehicles() {
        return vehicles;
    }

    public void setVehicles(List<Vehicle> vehicles) {
        this.vehicles = vehicles;
    }
}
