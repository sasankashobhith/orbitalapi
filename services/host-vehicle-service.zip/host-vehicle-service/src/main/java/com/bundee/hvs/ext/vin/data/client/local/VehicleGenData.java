package com.bundee.hvs.ext.vin.data.client.local;

import java.util.List;

import com.bundee.hvs.defs.HVSProcessingCode;
import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.UTF8String;

public class VehicleGenData {
	class Make {
		UTF8String make;
		List<UTF8String> models;

		@Override
		public String toString() {
			return make.toString() + " :: " + models.toString();
		}

		public UTF8String getMake() {
			return make;
		}

		public List<UTF8String> getModels() {
			return models;
		}
	}

	List<Make> makeList;
	List<UTF8String> descriptions;
	Integer yearsRS;
	Integer yearsRE;
	List<UTF8String> numbers;
	List<UTF8String> colors;

	@Override
	public String toString() {
		return makeList.toString() + " :: " + descriptions.toString() + " :: [" + yearsRS.toString() + ":"
				+ yearsRE.toString() + "] :: " + numbers.toString() + " :: " + colors.toString();
	}

	public List<Make> getMakeList() {
		return makeList;
	}

	public List<UTF8String> getDescriptions() {
		return descriptions;
	}

	public Integer getYearsRS() {
		return yearsRS;
	}

	public Integer getYearsRE() {
		return yearsRE;
	}

	public List<UTF8String> getNumbers() {
		return numbers;
	}

	public List<UTF8String> getColors() {
		return colors;
	}

	public static void validate(VehicleGenData vgd) throws BExceptions {
		BExceptions exceptions = new BExceptions();
		if (vgd == null) {
			exceptions.add(HVSProcessingCode.INVALID_VEHICLE_FILE, "VehicleGenData is null, check file contents!");
		} else {
			chkAndAddException("makeList", vgd.makeList, exceptions);
			chkAndAddException("descriptions", vgd.descriptions, exceptions);
			chkAndAddException("yearsRS", vgd.yearsRS, exceptions);
			chkAndAddException("yearsRE", vgd.yearsRE, exceptions);
			chkAndAddException("numbers", vgd.numbers, exceptions);
			chkAndAddException("colors", vgd.colors, exceptions);
		}
		if (exceptions.hasExceptions())
			throw exceptions;
	}

	private static void chkAndAddException(String ctx, List<?> list, BExceptions ex) {
		if (list == null || list.isEmpty()) {
			ex.add(HVSProcessingCode.INVALID_VEHICLE_FILE, ctx + " is missing!");
		}
	}

	private static void chkAndAddException(String ctx, Object val, BExceptions ex) {
		if (val == null) {
			ex.add(HVSProcessingCode.INVALID_VEHICLE_FILE, ctx + " is missing!");
		}
	}
}
