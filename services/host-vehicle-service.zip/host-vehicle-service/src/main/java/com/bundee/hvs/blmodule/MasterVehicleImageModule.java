package com.bundee.hvs.blmodule;

import com.bundee.hvs.db.*;
import com.bundee.hvs.defs.*;
import com.bundee.hvs.pojo.*;
import com.bundee.hvs.utils.*;
import com.bundee.msfw.defs.*;
import com.bundee.msfw.interfaces.blmodi.BLModServices;
import com.bundee.msfw.interfaces.blmodi.BLModule;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.endpoint.BEndpoint;
import com.bundee.msfw.interfaces.logi.BLogger;
import com.bundee.msfw.interfaces.reqrespi.RequestContext;
import com.bundee.msfw.interfaces.utili.csv.*;

import java.io.*;
import java.util.*;
import java.util.stream.*;

public class MasterVehicleImageModule implements BLModule {
	
	@Override
	public void init(BLogger logger, BLModServices blModServices) throws BExceptions {
		// TODO Auto-generated method stub
		
	}
	
	@BEndpoint(uri = HVDefs.Endpoints.GET_ALL_INVEHICLEIMAGE, httpMethod = UniversalConstants.POST, permission = ""
			, reqDTOClass = VehicleID.class)
    public BaseResponse getAllVehicleImages(BLogger logger, BLModServices blModServices, RequestContext reqCtx
    		,VehicleID requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
           vList = MasterVehicleImageDAO.geAllMasterVehicle(logger, blModServices.getDBManager(),requestObject.getFromvalue());
           return vList;
        } catch (DBException e) {
           vList.setErrorCode("1");
           vList.setErrorMessage("Error in Retriving Image Data");
           return vList;
        }
    }
	
	@BEndpoint(uri = HVDefs.Endpoints.GET_ALL_VEHICLEIMAGE, httpMethod = UniversalConstants.GET, permission = "")
    public BaseResponse getAllCustomerActivity(BLogger logger, BLModServices blModServices, RequestContext reqCtx) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
           vList = MasterVehicleImageDAO.geAllMasterVehicleImage(logger, blModServices.getDBManager(),vList);
           return vList;
        } catch (DBException e) {

           vList.setErrorCode("1");
           vList.setErrorMessage("Error in CustomerActivity Request");
           return vList;
        }
    }

	

	@BEndpoint(uri = HVDefs.Endpoints.GET_ALL_BY_IMAGEID, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleID.class)

    public BaseResponse getAllIma(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
    		VehicleID requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = MasterVehicleImageDAO.getImageById(logger, blModServices.getDBManager()
                    , requestObject);
            return vList;
        } catch (DBException e) {
           
        	vList.setErrorCode("1");
        	vList.setErrorMessage("Error in Image Request");
            return vList;
        }
       
    }
	
	
	@BEndpoint(uri = HVDefs.Endpoints.INSERT_IMAGE_DETAILS, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = MasterVehicleImageResponse.class)

    public BaseResponse insertImage(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
    		MasterVehicleImageResponse requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = MasterVehicleImageDAO.insertImageDetails(logger, blModServices.getDBManager()
                    , requestObject);
            return vList;
        } catch (DBException e) {
           
        	vList.setErrorCode("1");
        	vList.setErrorMessage("Error in Image Request");
            return vList;
        }
       
    }
	
	@BEndpoint(uri = HVDefs.Endpoints.UPDATE_IMAGEDETAILS, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = MasterVehicleImageResponse.class)

    public BaseResponse updateImageDetails(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
    		MasterVehicleImageResponse requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = MasterVehicleImageDAO.updateImageDetails(logger, blModServices.getDBManager()
                    , requestObject);
            return vList;
        } catch (Exception e) {
           
        	vList.setErrorCode("1");
        	vList.setErrorMessage("Error in Image Request");
            return vList;
        }
       
    }
    @BEndpoint(uri = HVDefs.Endpoints.UPLOAD_VEHICLES_IMAGES, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = UploadedFile.class)
    public BaseResponse createVehicleImages(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                            UploadedFile requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();

        UploadedFile.validate(requestObject);

        logger.debug(requestObject.getFileName() + " with length " + requestObject.getB64Contents().getUTF8String().length());

        byte[] decBytes = blModServices.getUtilFactory().getNewCryptoService().base64Decode(requestObject.getB64Contents().getUTF8String());
        UTF8String utfStr = new UTF8String(new String(decBytes));
        StringReader sr = new StringReader(utfStr.getUTF8String());
        BCSVReader csvReader = blModServices.getUtilFactory().getNewLargeCSVReader(sr, ',', 1);
        List<VinImages> vehicleImages = new ArrayList<VinImages>();
        List<MasterVehicleImageResponse> vehicleImagesValidated = new ArrayList<MasterVehicleImageResponse>();
        while (true) {
            Row row = csvReader.getNextRow(logger);
            if (row == null) {
                break;
            }
            VinImages v = Util.createVehicleImages(row);
            vehicleImages.add(v);
        }
        try {
            List<String> getVehicleList = vehicleImages.stream().map(e -> e.getVIN().toString()).distinct().collect(Collectors.toList());
            VehiclesList vehicleList = VehicleDAO.geAllMasterVehicleVinData(logger, blModServices.getDBManager(), getVehicleList.toString().replace("[", "").replace("]", ""));
            if (vehicleList.getErrorCode().equals("1")) {
                return vehicleList;
            }

            vehicleImagesValidated = getImageData(vehicleList.getVehicles(),vehicleImages);

            vList = MasterVehicleImageDAO.insertVehiclesImagesCSV(logger, blModServices.getDBManager(), vehicleImagesValidated);

        } catch (DBException e) {
            vList.setErrorMessage("Error while uploading - " + e.getMessage());
            vList.setErrorCode("1");
            throw new BExceptions(e, HVSProcessingCode.DUPLICATE_VEHICLES);
        }
        return vList;
    }
    public static List<MasterVehicleImageResponse> getImageData(List<Vehicle> vehicles, List<VinImages> vehicleImages) {

        List<MasterVehicleImageResponse> vehicleImagesValidated = new ArrayList<MasterVehicleImageResponse>();

        for (int i = 0; i < vehicleImages.size(); i++) {
            String vin = vehicleImages.get(i).getVIN().toString();
            int vId = 0, userId = 0;
            List<Vehicle> vehicleData = vehicles.stream()
                    .filter(item -> item.getVIN().toString().equals(vin)).collect(Collectors.toList());
            if (vehicleData.size() > 0) {
                vId = vehicleData.get(0).getID();
                userId = vehicleData.get(0).getHostID();
            }
            MasterVehicleImageResponse imageResponse = new MasterVehicleImageResponse();
            imageResponse.setVehicleid(vId);
            imageResponse.setUserid(userId);
            imageResponse.setImagename(vehicleImages.get(i).getIMAGEPATH().toString());
            vehicleImagesValidated.add(imageResponse);
        }

        return vehicleImagesValidated;

    }
}


