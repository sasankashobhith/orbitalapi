package com.bundee.hvs.defs;

import com.bundee.msfw.defs.ProcessingCode;

public class HVSProcessingCode extends ProcessingCode {

	public HVSProcessingCode(int code, String codeKey) {
		super(code, codeKey);
	}

	public static final HVSProcessingCode INVALID_VEHICLE_FILE = new HVSProcessingCode(1000, "INVALID_VEHICLE_FILE"); 
	public static final HVSProcessingCode DUPLICATE_VEHICLES = new HVSProcessingCode(1001, "DUPLICATE_VEHICLES"); 
	public static final HVSProcessingCode VEHICLES_NOT_FOUND = new HVSProcessingCode(1002, "VEHICLES_NOT_FOUND"); 
	public static final HVSProcessingCode INVALID_VINS = new HVSProcessingCode(1003, "INVALID_VINS"); 
}
