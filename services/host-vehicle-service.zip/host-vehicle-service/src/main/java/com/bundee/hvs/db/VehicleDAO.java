package com.bundee.hvs.db;

import com.bundee.hvs.ext.vin.data.client.def.VINVehicleData;
import com.bundee.hvs.pojo.Vehicle;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.hvs.utils.ValidationUtil;
import com.bundee.msfw.defs.UTF8String;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.dbi.DBManager;
import com.bundee.msfw.interfaces.dbi.DBQuery;
import com.bundee.msfw.interfaces.dbi.DBQueryBuilder;
import com.bundee.msfw.interfaces.logi.BLogger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public class VehicleDAO {

    private static final String INSERT_VEHICLES = "insert into mastervehicle (vin, make, model, description, year, vehicle_type_id, vhost, vnumber, vcolor) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String INSERT_VEHICLE = "insert into mastervehicle (vin, make, model, description, year, vehicle_type_id, vhost, vnumber, vcolor,branchid,vehiclelatitude,vehiclelongitude) values ( ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?)";
    private static final String UPDATE_VEHICLE = "UPDATE mastervehicle SET vin=?, make=?, model=?, description=?, year=?, vehicle_type_id=?, vhost=?, branchid=?, vnumber=?, vcolor=?, vehiclelatitude=?, vehiclelongitude=?, updtd_ts=? WHERE id=?";
    private static final String LIST_VEHICLES_BY_HOST = "select * from mastervehicle where vhost=? and isactive=true";
    private static final String LIST_VEHICLES = "select * from mastervehicle where isactive=true";
    private static final String LIST_VEHICLES_BY_ID = "select * from mastervehicle where id=? and isactive is true";
    private static final String LIST_VEHICLE_IDS_BY_HOST = "select id from mastervehicle where vhost=? and isactive=true";
    private static final String LIST_VEHICLES_BY_IDS = "select * from mastervehicle where id=any(?) and isactive is true";

    //	"select mastervehicle.id, mastervehicle.vin, mastervehicle.make, mastervehicle.model, mastervehicle.description, mastervehicle.isactive, mastervehicle.year, mastervehicle.vehicle_type_id, mastervehicle.vhost, mastervehicle.branchid,masterbranch.address1, masterbranch.address2, masterbranch.address3, masterbranch.cityname, mastervehicle.vnumber, mastervehicle.vcolor, mastervehicle.crtd_ts, mastervehicle.updtd_ts from mastervehicle inner join masterbranch on masterbranch.idbranch=mastervehicle.branchid where id=3 and mastervehicle.isactive is true;"
    public static VehiclesList insertVehicles(BLogger logger, DBManager dbm, Collection<VINVehicleData> vehicles) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicles == null) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setBatch().setQueryString(INSERT_VEHICLES).setBindInputFunction((dbLogger, ps) -> {
                for (VINVehicleData v : vehicles) {
                    ps.setString(1, v.getVIN().getUTF8String());
                    ps.setString(2, v.getMake().getUTF8String());
                    ps.setString(3, v.getModel().getUTF8String());
                    ps.setString(4, v.getDesc().getUTF8String());
                    ps.setString(5, v.getYear().getUTF8String());
                    ps.setInt(6, 0);
                    ps.setInt(7, 0);
                    ps.setInt(8, 0);
                    ps.setString(9, v.getNumber().getUTF8String());
                    ps.setString(10, v.getColor().getUTF8String());
                    ps.addBatch();
                }
            }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getVehicles().add(createVehicle(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();

            dbm.update(logger, sq);
            vehiclesList.setErrorMessage("Inserted Successfully ");
            vehiclesList.setErrorCode("0");
            return vehiclesList;
        } catch (Exception e) {

            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;

        }
    }
    public static VehiclesList insertVehiclesCSV(BLogger logger, DBManager dbm, Collection<Vehicle> vehicles)
            throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicles == null) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setBatch().setQueryString(INSERT_VEHICLES).setBindInputFunction((dbLogger, ps) -> {
                for (Vehicle v : vehicles) {
                    ps.setString(1, v.getVIN().getUTF8String());
                    ps.setString(2, v.getMake().getUTF8String());
                    ps.setString(3, v.getModel().getUTF8String());
                    ps.setString(4, v.getDesc().getUTF8String());
                    ps.setString(5, v.getYear().getUTF8String());
                    ps.setInt(6, v.getVehicletypeid());
                    ps.setInt(7, v.getHostID());
                    ps.setString(8, v.getNumber().getUTF8String());
                    ps.setInt(9, v.getBranchID());

                    ps.setString(10, v.getColor().getUTF8String());
                    ps.setString(11, v.getVehicleLatitude().getUTF8String());
                    ps.setString(12, v.getVehicleLongitude().getUTF8String());

                    ps.addBatch();
                }
            }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getVehicles().add(createVehicle(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();

            dbm.update(logger, sq);

            vehiclesList.setErrorMessage("Inserted Successfully ");
            vehiclesList.setErrorCode("0");
            return vehiclesList;
        } catch (Exception e) {

            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;

        }
    }
    public static VehiclesList listVehiclesByHostID(BLogger logger, DBManager dbm, int hostID, List<Vehicle> vehicles) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicles == null) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(LIST_VEHICLES_BY_HOST).setBindInputFunction((dbBLogger, ps) -> {
                ps.setInt(1, hostID);
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehicles.add(createVehicle(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();

            dbm.select(logger, sq);
            vehiclesList.setErrorMessage("Retrieved Successfully ");
            vehiclesList.setErrorCode("0");
            vehiclesList.getVehicles().addAll(vehicles);
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }

    private static Vehicle createVehicle(BLogger logger, ResultSet rs) throws SQLException {
        Vehicle vehicle = new Vehicle();
        vehicle.setID(rs.getInt("id"));
        vehicle.setHostID(rs.getInt("vhost"));
        vehicle.setTypeID(rs.getInt("vehicle_type_id"));
        vehicle.setActive(rs.getBoolean("isactive"));
        vehicle.setVin(new UTF8String(rs.getString("vin")));
        vehicle.setMake(new UTF8String(rs.getString("make")));
        vehicle.setModel(new UTF8String(rs.getString("model")));
        vehicle.setDesc(new UTF8String(rs.getString("description")));
        vehicle.setYear(new UTF8String(rs.getString("year")));
        vehicle.setNumber(new UTF8String(rs.getString("vnumber")));
        vehicle.setColor(new UTF8String(rs.getString("vcolor")));
        vehicle.setBranchID(rs.getInt("branchid"));
        vehicle.setVehicleLatitude(new UTF8String(rs.getString("vehiclelatitude")));
        vehicle.setVehicleLongitude(new UTF8String(rs.getString("vehiclelongitude")));

        Timestamp ts = rs.getTimestamp("crtd_ts");
        long val = (ts != null ? ts.getTime() : 0);
        vehicle.setCreateTS(val);
        ts = rs.getTimestamp("updtd_ts");
        val = (ts != null ? ts.getTime() : 0);
        vehicle.setUpdateTS(val);
        return vehicle;
    }

    public static VehiclesList listVehiclesByID(BLogger logger, DBManager dbm, int vehicleId, List<Vehicle> vehicles) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicleId == 0) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {

            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(LIST_VEHICLES_BY_ID).setBindInputFunction((dbBLogger, ps) -> {
                ps.setInt(1, vehicleId);
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehicles.add(createVehicle(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();

            dbm.select(logger, sq);
            if(vehicles.isEmpty()){
                vehiclesList.setErrorMessage("Error retrieving details- vehicle id does not exist");
                vehiclesList.setErrorCode("1");
                return vehiclesList;
            }
            vehiclesList.setErrorMessage("Retrieved data successfully ");
            vehiclesList.setErrorCode("0");
            vehiclesList.getVehicles().addAll(vehicles);
            return vehiclesList;
        }
        catch (Exception e){
            vehiclesList.setErrorMessage("Error retrieving details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }

    public static VehiclesList insertMasterVehicle(BLogger logger, DBManager dbm, Vehicle vehicle) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicle == null) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
		VehiclesList validationResponse = new ValidationUtil().validateMasterVehicle(vehicle);
		if (validationResponse.getErrorCode().equals("1")) {
			return validationResponse;
		}
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(INSERT_VEHICLE).setBindInputFunction((dbBLogger, ps) -> {
                ps.setString(1, vehicle.getVIN().getUTF8String());
                ps.setString(2, vehicle.getMake().getUTF8String());
                ps.setString(3, vehicle.getModel().getUTF8String());
                ps.setString(4, vehicle.getDesc().getUTF8String());
                ps.setString(5, vehicle.getYear().getUTF8String());
                ps.setInt(6, vehicle.getTypeID());
                ps.setInt(7, vehicle.getHostID());
                ps.setString(8, vehicle.getNumber().getUTF8String());
                ps.setString(9, vehicle.getColor().getUTF8String());
                ps.setInt(10, vehicle.getBranchID());
                ps.setString(11, vehicle.getVehicleLatitude().getUTF8String());
                ps.setString(12, vehicle.getVehicleLongitude().getUTF8String());
            }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getVehicles().add(createVehicle(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.update(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data inserted successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error inserting details - " + e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }
    public static VehiclesList listVehicles(BLogger logger, DBManager dbm,  List<Vehicle> vehicles) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null ) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {

            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(LIST_VEHICLES).setBindInputFunction((dbBLogger, ps) -> {
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehicles.add(createVehicle(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();

            dbm.select(logger, sq);
            if(vehicles.isEmpty()){
                vehiclesList.setErrorMessage("Error retrieving vehicles");
                vehiclesList.setErrorCode("1");
                return vehiclesList;
            }
            vehiclesList.setErrorMessage("Retrieved data successfully ");
            vehiclesList.setErrorCode("0");
            vehiclesList.getVehicles().addAll(vehicles);
            return vehiclesList;
        }
        catch (Exception e){
            vehiclesList.setErrorMessage("Error retrieving details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }
    public static VehiclesList updateVehicle(BLogger logger, DBManager dbm, Vehicle vehicle) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicle == null) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
		VehiclesList validationResponse = new ValidationUtil().validateMasterVehicle(vehicle);
		if (validationResponse.getErrorCode().equals("1")) {
			return validationResponse;
		}
        try {
            Date date = new Date();
            java.sql.Date sqlDate = new java.sql.Date(date.getTime());
            java.sql.Timestamp updatedTime = new java.sql.Timestamp(sqlDate.getTime());
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(UPDATE_VEHICLE).setBindInputFunction((dbBLogger, ps) -> {
                ps.setString(1, vehicle.getVIN().getUTF8String());
                ps.setString(2, vehicle.getMake().getUTF8String());
                ps.setString(3, vehicle.getModel().getUTF8String());
                ps.setString(4, vehicle.getDesc().getUTF8String());
                ps.setString(5, vehicle.getYear().getUTF8String());
                ps.setInt(6, vehicle.getTypeID());
                ps.setInt(7, vehicle.getHostID());
                ps.setInt(8, vehicle.getBranchID());
                ps.setString(9, vehicle.getNumber().getUTF8String());
                ps.setString(10, vehicle.getColor().getUTF8String());
                ps.setString(11, vehicle.getVehicleLatitude().getUTF8String());
                ps.setString(12, vehicle.getVehicleLongitude().getUTF8String());
                ps.setTimestamp(13, updatedTime);
                ps.setInt(14, vehicle.getID());
            }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getVehicles().add(createVehicle(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.update(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data updated successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error updating details - " + e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }
    public static void listVehicleIDsByHostID(BLogger logger, DBManager dbm, int hostID, List<Long> vehicleIDs) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicleIDs == null) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(LIST_VEHICLE_IDS_BY_HOST).setBindInputFunction((dbBLogger, ps) -> {
                ps.setInt(1, hostID);
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehicleIDs.add((long)rs.getInt("id"));
            }).logQuery(true).throwOnNoData(false).build();

            dbm.select(logger, sq);
            vehiclesList.setErrorMessage("Retrieved Successfully ");
            vehiclesList.setErrorCode("0");
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
        }
    }
    public static VehiclesList listVehiclesByIDs(BLogger logger, DBManager dbm, List<Long> ids, List<Vehicle> vehicles) throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        if (dbm == null || vehicles == null) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(LIST_VEHICLES_BY_IDS).setBindInputFunction((dbBLogger, ps) -> {
                ps.setArray(1, ps.getConnection().createArrayOf("int", ids.toArray()));
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehicles.add(createVehicle(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();

            dbm.select(logger, sq);
            vehiclesList.setErrorMessage("Inserted Successfully ");
            vehiclesList.setErrorCode("0");
            vehiclesList.getVehicles().addAll(vehicles);
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }
    private static Vehicle getVehicleId(BLogger logger, ResultSet rs) throws SQLException {
        Vehicle vehicle = new Vehicle();
        vehicle.setID(rs.getInt("id"));
        vehicle.setHostID(rs.getInt("vhost"));
        vehicle.setTypeID(rs.getInt("vehicle_type_id"));
        vehicle.setActive(rs.getBoolean("isactive"));
        vehicle.setVin(new UTF8String(rs.getString("vin")));
        return vehicle;
    }
    public static VehiclesList geAllMasterVehicleVinData(BLogger logger, DBManager dbm,String vinList)

            throws DBException {
        VehiclesList vehiclesList = new VehiclesList();
        try {
            String GET_VehicleALL_BY_AllVIN = "select * from mastervehicle where vin IN (&in)";
            String csvId = vinList.replaceAll("^|$", "'").replaceAll(",", "','").replaceAll("\"", "'");
            String repSearcStr = GET_VehicleALL_BY_AllVIN.replace("&in", csvId);
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(repSearcStr).setBindInputFunction((dbBLogger, ps) -> {
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getVehicles().add(getVehicleId(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data retrieved successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving all CustomerActivity details - " + e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }
}
