package com.bundee.hvs.pojo;

import com.bundee.msfw.defs.UTF8String;

public class VehicleType {
    private int id;
    private UTF8String name;
	private String fromvalue;

	public String getFromvalue() {
		return fromvalue;
	}

	public void setFromvalue(String fromvalue) {
		this.fromvalue = fromvalue;
	}

	public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public UTF8String getName() {
        return name;
    }

    public void setName(UTF8String name) {
        this.name = name;
    }
}
