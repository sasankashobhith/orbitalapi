package com.bundee.hvs.utils;

import com.bundee.hvs.pojo.VinzipcodeResponse;
import com.bundee.msfw.defs.BExceptions;

public class VinZipcodeUtill {

	public static VinzipcodeResponse createSingleZipcode(VinzipcodeResponse row) throws BExceptions {
		VinzipcodeResponse res = new VinzipcodeResponse();

		res.setId(row.getId());
		res.setVin(row.getVin());
		res.setVehicleid(row.getVehicleid());
		res.setZipcode(row.getZipcode());
		res.setHostid(row.getHostid());
		res.setIsactive(row.getisIsactive());
		res.setCreateddate(row.getCreateddate());
		res.setUpdateddate(row.getUpdateddate());

		return res;

	}

}
