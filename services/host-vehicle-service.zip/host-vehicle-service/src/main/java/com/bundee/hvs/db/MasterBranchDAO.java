package com.bundee.hvs.db;

import com.bundee.hvs.pojo.BranchResponse;
import com.bundee.hvs.pojo.MasterBranch;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.hvs.utils.ValidationUtil;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.dbi.DBManager;
import com.bundee.msfw.interfaces.dbi.DBQuery;
import com.bundee.msfw.interfaces.dbi.DBQueryBuilder;
import com.bundee.msfw.interfaces.logi.BLogger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class MasterBranchDAO {

    private static final String GET_ALL_MASTER_BRANCH = "select * from masterbranch where isactive=true";
    private static final String GET_MASTER_BRANCH_BY_ID = "select * from masterbranch where idbranch=? and isactive=true";
    private static final String INSERT_MASTER_BRANCH = "INSERT INTO masterbranch( cityname, zipcode, address1, address2, address3, latitude, longitude, state, userid) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_MASTER_BRANCH = "UPDATE masterbranch SET cityname=?, zipcode=?, address1=?, address2=?, address3=?, latitude=?, longitude=?, state=?, userid=?, updateddate=? WHERE idbranch=?";

    public static VehiclesList getVehicleBranchDetails(BLogger logger, DBManager dbm, String id) throws DBException {
        VehiclesList bookResponse = new VehiclesList();

        if (dbm == null || id == null) {
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in MasterBranch Request Request");
            return bookResponse;
        }
        try {
            String GET_BY_VEHCILEID = "SELECT mastervehicle.id, mastervehicle.make, mastervehicle.model, mastervehicle.year, masterbranch.cityname, masterbranch.zipcode, masterbranch.address1, masterbranch.address2, masterbranch.address3, masterbranch.state FROM mastervehicle inner join masterbranch on mastervehicle.branchid=masterbranch.idbranch where mastervehicle.id IN (&in)";

            String csvId = id.replaceAll("^|$", "'").replaceAll(",", "','").replaceAll("\"", "'");
            String repSearcStr = GET_BY_VEHCILEID.replace("&in", csvId);

            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();

            DBQuery sq = dbQB.setQueryString(repSearcStr).setBindInputFunction((dbBLogger, ps) -> {
            }).setFetchDataFunction((dbFLogger, rs) -> {
                bookResponse.getBrannchresponse().add(MasterBranchDAO.createBranchResponse(dbFLogger,rs));
            }).logQuery(true).throwOnNoData(false).build();

            dbm.select(logger, sq);
            bookResponse.setErrorCode("0");
            bookResponse.setErrorMessage("Data retrived Succesfully");
            return bookResponse;
        } catch (Exception e) {
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in Branch Request exception" + e.getMessage());
            return bookResponse;
        }

    }

    public static VehiclesList getAllMasterBranch(BLogger logger, DBManager dbm, VehiclesList vehiclesList) throws DBException {
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();

            DBQuery sq = dbQB.setQueryString(GET_ALL_MASTER_BRANCH).setBindInputFunction((dbBLogger, ps) -> {
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getMasterBranches().add(createMasterBranch(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data retrieved successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving all branch details - " + e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }

    private static MasterBranch createMasterBranch(BLogger logger, ResultSet rs) throws SQLException {
        MasterBranch masterBranch = new MasterBranch();
        masterBranch.setIdBranch(rs.getInt("idbranch"));
        masterBranch.setCityName(rs.getString("cityname"));
        masterBranch.setZipCode(rs.getString("zipcode"));
        masterBranch.setAddress1(rs.getString("address1"));
        masterBranch.setAddress2(rs.getString("address2"));
        masterBranch.setAddress3(rs.getString("address3"));
        masterBranch.setLatitude(rs.getString("latitude"));
        masterBranch.setLongitude(rs.getString("longitude"));
        masterBranch.setState(rs.getString("state"));
        masterBranch.setUserid(rs.getInt("userid"));
        masterBranch.setActive(rs.getBoolean("isactive"));
        Timestamp ts = rs.getTimestamp("createddate");
        masterBranch.setCreatedDate(ts.toString());
        ts = rs.getTimestamp("updateddate");
        masterBranch.setUpdatedDate(ts.toString());
        return masterBranch;
    }
public static BranchResponse createBranchResponse(BLogger logger,ResultSet rs) throws SQLException {
    BranchResponse branchResponse=new BranchResponse();
    branchResponse.setId(rs.getInt("id"));
    branchResponse.setMake(     rs.getString("make"));
    branchResponse.setModel( rs.getString("model"));
    branchResponse.setYear(rs.getString("year"));
    branchResponse.setCityname(rs.getString("cityname"));
    branchResponse.setZipcode(rs.getString("zipcode"));
    branchResponse.setAddress1(rs.getString("address1"));
    branchResponse.setAddress2(rs.getString("address2"));
    branchResponse.setAddress3( rs.getString("address3"));
    branchResponse.setState(rs.getString("state"));
return branchResponse;
}
    public static VehiclesList getMasterBranchByID(BLogger logger, DBManager dbm, VehiclesList vehiclesList, int id) throws DBException {
        if (dbm == null || id == 0) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(GET_MASTER_BRANCH_BY_ID).setBindInputFunction((dbBLogger, ps) -> {
                ps.setInt(1, id);
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getMasterBranches().add(createMasterBranch(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data retrieved successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving all branch details - " + e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }

    public static VehiclesList insertMasterBranch(BLogger logger, DBManager dbm, VehiclesList vehiclesList, MasterBranch masterBranch) throws DBException {
        if (dbm == null || masterBranch == null) {
            vehiclesList.setErrorMessage("Error retrieving branch details ");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        VehiclesList validationResponse = new ValidationUtil().validateMasterBranch(masterBranch);
        if (validationResponse.getErrorCode().equals("1")) {
            return validationResponse;
        }
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(INSERT_MASTER_BRANCH).setBindInputFunction((dbBLogger, ps) -> {
                ps.setString(1, masterBranch.getCityName());
                ps.setString(2, masterBranch.getZipCode());
                ps.setString(3, masterBranch.getAddress1());
                ps.setString(4, masterBranch.getAddress2());
                ps.setString(5, masterBranch.getAddress3());
                ps.setString(6, masterBranch.getLatitude());
                ps.setString(7, masterBranch.getLongitude());
                ps.setString(8, masterBranch.getState());
                ps.setInt(9, masterBranch.getUserid());
            }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getMasterBranches().add(createMasterBranch(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.update(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data inserted successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error inserting details - " + e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }
    public static VehiclesList updateMasterBranch(BLogger logger, DBManager dbm, VehiclesList vehiclesList, MasterBranch masterBranch) throws DBException {
        if (dbm == null || masterBranch == null||masterBranch.getUserid()==0||masterBranch.getIdBranch()==0) {
            vehiclesList.setErrorMessage("Error with the details given");
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
        VehiclesList validationResponse = new ValidationUtil().validateMasterBranch(masterBranch);
        if (validationResponse.getErrorCode().equals("1")) {
            return validationResponse;
        }
        try {
            Date date = new Date();
            java.sql.Date sqlDate = new java.sql.Date(date.getTime());
            java.sql.Timestamp updatedTime = new java.sql.Timestamp(sqlDate.getTime());
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(UPDATE_MASTER_BRANCH).setBindInputFunction((dbBLogger, ps) -> {
                ps.setString(1, masterBranch.getCityName());
                ps.setString(2, masterBranch.getZipCode());
                ps.setString(3, masterBranch.getAddress1());
                ps.setString(4, masterBranch.getAddress2());
                ps.setString(5, masterBranch.getAddress3());
                ps.setString(6, masterBranch.getLatitude());
                ps.setString(7, masterBranch.getLongitude());
                ps.setString(8, masterBranch.getState());
                ps.setInt(9, masterBranch.getUserid());
                ps.setTimestamp(10, updatedTime);
                ps.setInt(11, masterBranch.getIdBranch());
            }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getMasterBranches().add(createMasterBranch(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.update(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data inserted successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error inserting details - " + e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }
}

