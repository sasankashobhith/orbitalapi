package com.bundee.hvs.pojo;

public class CustomerWishlistResponse {
	
	private int id;
	private int userid;
	private int vehicleid;
	private boolean isfavourite;
	private String createddate;
	private boolean isactive;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getVehicleid() {
		return vehicleid;
	}
	public void setVehicleid(int vehicleid) {
		this.vehicleid = vehicleid;
	}
	public boolean getisIsfavourite() {
		return isfavourite;
	}
	public void setIsfavourite(boolean isfavourite) {
		this.isfavourite = isfavourite;
	}
	public String getCreateddate() {
		return createddate;
	}
	public void setCreateddate(String createddate) {
		this.createddate = createddate;
	}
	public boolean getisIsactive() {
		return isactive;
	}
	public void setIsactive(boolean isactive) {
		this.isactive = isactive;
	}

}
