

package com.bundee.hvs.pojo;

import java.util.ArrayList;
import java.util.List;

import com.bundee.msfw.defs.BaseResponse;

public class VehicleTypeList extends BaseResponse {
	List<VehicleType> vehicles;
	
	public VehicleTypeList() {
		vehicles = new ArrayList<VehicleType>();
	}
	
	public List<VehicleType> getVehicleTypes() {
		return vehicles;
	}
}
