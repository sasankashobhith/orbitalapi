package com.bundee.hvs.pojo;


import java.util.ArrayList;
import java.util.List;

import com.bundee.msfw.defs.BaseResponse;

public class VehicleUnavailabilityList extends BaseResponse{
	List<VehicleUnavailability> vehicles;

	public List<VehicleUnavailability> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<VehicleUnavailability> vehicles) {
		this.vehicles = vehicles;
	}
	
	public VehicleUnavailabilityList()
	{
		vehicles=new ArrayList<VehicleUnavailability>();
		
	}
}
