package com.bundee.hvs.pojo;

import com.bundee.msfw.defs.UTF8String;

public class VehicleFeature {

    private int vehiclefeatureid;
    private int userid;
    private int vehicleid;
    private UTF8String featurename;
    private UTF8String featuredescription;
    private UTF8String createddate;
    private UTF8String updateddate;
    private Boolean isActive;

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }

    public UTF8String getCreateddate() {
        return createddate;
    }

    public void setCreateddate(UTF8String createddate) {
        this.createddate = createddate;
    }

    public UTF8String getUpdateddate() {
        return updateddate;
    }

    public void setUpdateddate(UTF8String updateddate) {
        this.updateddate = updateddate;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getVehiclefeatureid() {
        return vehiclefeatureid;
    }

    public void setVehiclefeatureid(int vehiclefeatureid) {
        this.vehiclefeatureid = vehiclefeatureid;
    }

    public int getVehicleid() {
        return vehicleid;
    }

    public void setVehicleid(int vehicleid) {
        this.vehicleid = vehicleid;
    }

    public UTF8String getFeaturename() {
        return featurename;
    }

    public void setFeaturename(UTF8String featurename) {
        this.featurename = featurename;
    }

    public UTF8String getFeaturedescription() {
        return featuredescription;
    }

    public void setFeaturedescription(UTF8String featuredescription) {
        this.featuredescription = featuredescription;
    }
}
