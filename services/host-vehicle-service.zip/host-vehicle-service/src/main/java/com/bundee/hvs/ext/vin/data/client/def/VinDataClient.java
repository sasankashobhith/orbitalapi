package com.bundee.hvs.ext.vin.data.client.def;

import java.util.Collection;
import java.util.Map;

import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.UTF8String;
import com.bundee.msfw.interfaces.blmodi.BLModServices;
import com.bundee.msfw.interfaces.logi.BLogger;

public interface VinDataClient {
	void init(BLogger logger, BLModServices blModServices) throws BExceptions;
	Map<UTF8String, VINVehicleData> getVINDetails(BLogger logger, Collection<UTF8String> vins) throws BExceptions;
}
