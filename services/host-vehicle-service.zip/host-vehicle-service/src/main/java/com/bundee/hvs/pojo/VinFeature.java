package com.bundee.hvs.pojo;

import com.bundee.msfw.defs.UTF8String;
public class VinFeature {

    private  UTF8String VIN ;
    private UTF8String MAKE ;
    private  UTF8String manufacture;
    private  UTF8String model;
    private  Double modelYear;
    private  UTF8String plantcity;
    private  UTF8String series;
    private  UTF8String trim;
    private  UTF8String vehicletype;
    private UTF8String plantcountry;
    private UTF8String note;

    private  UTF8String bodyclass;
    private  int doors;

    private  UTF8String grossweightratingtype ;
    private  UTF8String bedtype;
    private  UTF8String cabtype;
    private  UTF8String trailertype;
    private  UTF8String trailertypeconnection;
    private  UTF8String trailerbodytype;
    private  int enginenumberofcylinders;
    private  Double displacementcc;
    private  Double displacementci;
    private   Double displacementtl;
    private   Double enginepower;
    private   UTF8String fueltypeprimary;
    private   Double enginebreakform;
    private   UTF8String seatbelttype;
    private   UTF8String otherrestraintsysteminformation;
    private   UTF8String frontairbaglocations;
    private   UTF8String kneeairbaglocations;
    private   UTF8String sideairbaglocations;
    private   UTF8String floorconfigurationtype;
    private   UTF8String tirepressureconfigurationsystem;
    private   UTF8String busfloorconfigurationsystem;



    private   int numberofwheels;
    private   int wheelbaseform;
    private   UTF8String breaksystemtype;
    private   int baseprice;
    private   UTF8String currentairbaglocation;
    private   UTF8String custommotorcycletype;
    private   int busfloor;
    private   UTF8String bustype;
    private   UTF8String motorcyclesuspensionform;
    private   UTF8String motorcyclechasistype;
    private   UTF8String plantcompanyname;

    private   UTF8String plantstate;
    private   UTF8String steringlocation;
    private   UTF8String drivetype;
    private   UTF8String elecrtrificationtype;
    private   UTF8String otherengineeinformation;
    private   int turbo;
    private   int engineemanufacture;
    private   int series2;
    private   int windows;

    private  UTF8String curtonairbaglocation;
    private  int wheelsizefront;
    private  int wheelsizerear;
    private  int numberofseats;
    private  UTF8String transmissionstyle;
    private  int axles;
    private  UTF8String antilockbrakingsystem ;
    private  UTF8String electronicstabilitysystem;
    private  UTF8String acivesafteysystemnote ;
    private  UTF8String backupcamer;
    private  UTF8String daytimerunninglight;
    public  UTF8String pretensioner;

    public  UTF8String engineconfiguration ;

    public  UTF8String vehicleDescription ;
    public  UTF8String seatingCapacity ;
    public  UTF8String insuranceHeader ;
    public  UTF8String insuranceHeaderType;
    public  UTF8String insuranceDetails1 ;
    public  UTF8String insuranceDetails2 ;
    public  UTF8String insuranceDetails3 ;
    public  UTF8String parkingDetails ;
    public  UTF8String guidelines ;
    public  UTF8String cancellationPolicyText ;
    public UTF8String getFrontairbaglocations() {
        return frontairbaglocations;
    }

    public void setFrontairbaglocations(UTF8String frontairbaglocations) {
        this.frontairbaglocations = frontairbaglocations;
    }

    public UTF8String getVehicleDescription() {
        return vehicleDescription;
    }

    public void setVehicleDescription(UTF8String vehicleDescription) {
        this.vehicleDescription = vehicleDescription;
    }

    public UTF8String getSeatingCapacity() {
        return seatingCapacity;
    }

    public void setSeatingCapacity(UTF8String seatingCapacity) {
        this.seatingCapacity = seatingCapacity;
    }

    public UTF8String getInsuranceHeader() {
        return insuranceHeader;
    }

    public void setInsuranceHeader(UTF8String insuranceHeader) {
        this.insuranceHeader = insuranceHeader;
    }

    public UTF8String getInsuranceHeaderType() {
        return insuranceHeaderType;
    }

    public void setInsuranceHeaderType(UTF8String insuranceHeaderType) {
        this.insuranceHeaderType = insuranceHeaderType;
    }

    public UTF8String getInsuranceDetails1() {
        return insuranceDetails1;
    }

    public void setInsuranceDetails1(UTF8String insuranceDetails1) {
        this.insuranceDetails1 = insuranceDetails1;
    }

    public UTF8String getInsuranceDetails2() {
        return insuranceDetails2;
    }

    public void setInsuranceDetails2(UTF8String insuranceDetails2) {
        this.insuranceDetails2 = insuranceDetails2;
    }

    public UTF8String getInsuranceDetails3() {
        return insuranceDetails3;
    }

    public void setInsuranceDetails3(UTF8String insuranceDetails3) {
        this.insuranceDetails3 = insuranceDetails3;
    }

    public UTF8String getParkingDetails() {
        return parkingDetails;
    }

    public void setParkingDetails(UTF8String parkingDetails) {
        this.parkingDetails = parkingDetails;
    }

    public UTF8String getGuidelines() {
        return guidelines;
    }

    public void setGuidelines(UTF8String guidelines) {
        this.guidelines = guidelines;
    }

    public UTF8String getCancellationPolicyText() {
        return cancellationPolicyText;
    }

    public void setCancellationPolicyText(UTF8String cancellationPolicyText) {
        this.cancellationPolicyText = cancellationPolicyText;
    }










    public UTF8String getVIN() {
        return VIN;
    }

    public void setVIN(UTF8String VIN) {
        this.VIN = VIN;
    }

    public UTF8String getMAKE() {
        return MAKE;
    }

    public void setMAKE(UTF8String MAKE) {
        this.MAKE = MAKE;
    }

    public UTF8String getManufacture() {
        return manufacture;
    }

    public void setManufacture(UTF8String manufacture) {
        this.manufacture = manufacture;
    }

    public UTF8String getModel() {
        return model;
    }

    public void setModel(UTF8String model) {
        this.model = model;
    }

    public Double getModelYear() {
        return modelYear;
    }

    public void setModelYear(Double modelYear) {
        this.modelYear = modelYear;
    }

    public UTF8String getPlantcity() {
        return plantcity;
    }

    public void setPlantcity(UTF8String plantcity) {
        this.plantcity = plantcity;
    }

    public UTF8String getSeries() {
        return series;
    }

    public void setSeries(UTF8String series) {
        this.series = series;
    }

    public UTF8String getTrim() {
        return trim;
    }

    public void setTrim(UTF8String trim) {
        this.trim = trim;
    }

    public UTF8String getVehicletype() {
        return vehicletype;
    }

    public void setVehicletype(UTF8String vehicletype) {
        this.vehicletype = vehicletype;
    }

    public UTF8String getPlantcountry() {
        return plantcountry;
    }

    public void setPlantcountry(UTF8String plantcountry) {
        this.plantcountry = plantcountry;
    }

    public UTF8String getNote() {
        return note;
    }

    public void setNote(UTF8String note) {
        this.note = note;
    }

    public UTF8String getBodyclass() {
        return bodyclass;
    }

    public void setBodyclass(UTF8String bodyclass) {
        this.bodyclass = bodyclass;
    }

    public int getDoors() {
        return doors;
    }

    public void setDoors(int doors) {
        this.doors = doors;
    }

    public UTF8String getGrossweightratingtype() {
        return grossweightratingtype;
    }

    public void setGrossweightratingtype(UTF8String grossweightratingtype) {
        this.grossweightratingtype = grossweightratingtype;
    }

    public UTF8String getBedtype() {
        return bedtype;
    }

    public void setBedtype(UTF8String bedtype) {
        this.bedtype = bedtype;
    }

    public UTF8String getCabtype() {
        return cabtype;
    }

    public void setCabtype(UTF8String cabtype) {
        this.cabtype = cabtype;
    }

    public UTF8String getTrailertype() {
        return trailertype;
    }

    public void setTrailertype(UTF8String trailertype) {
        this.trailertype = trailertype;
    }

    public UTF8String getTrailertypeconnection() {
        return trailertypeconnection;
    }

    public void setTrailertypeconnection(UTF8String trailertypeconnection) {
        this.trailertypeconnection = trailertypeconnection;
    }

    public UTF8String getTrailerbodytype() {
        return trailerbodytype;
    }

    public void setTrailerbodytype(UTF8String trailerbodytype) {
        this.trailerbodytype = trailerbodytype;
    }

    public int getEnginenumberofcylinders() {
        return enginenumberofcylinders;
    }

    public void setEnginenumberofcylinders(int enginenumberofcylinders) {
        this.enginenumberofcylinders = enginenumberofcylinders;
    }

    public Double getDisplacementcc() {
        return displacementcc;
    }

    public void setDisplacementcc(Double displacementcc) {
        this.displacementcc = displacementcc;
    }

    public Double getDisplacementci() {
        return displacementci;
    }

    public void setDisplacementci(Double displacementci) {
        this.displacementci = displacementci;
    }

    public Double getDisplacementtl() {
        return displacementtl;
    }

    public void setDisplacementtl(Double displacementtl) {
        this.displacementtl = displacementtl;
    }

    public Double getEnginepower() {
        return enginepower;
    }

    public void setEnginepower(Double enginepower) {
        this.enginepower = enginepower;
    }

    public UTF8String getFueltypeprimary() {
        return fueltypeprimary;
    }

    public void setFueltypeprimary(UTF8String fueltypeprimary) {
        this.fueltypeprimary = fueltypeprimary;
    }

    public Double getEnginebreakform() {
        return enginebreakform;
    }

    public void setEnginebreakform(Double enginebreakform) {
        this.enginebreakform = enginebreakform;
    }

    public UTF8String getSeatbelttype() {
        return seatbelttype;
    }

    public void setSeatbelttype(UTF8String seatbelttype) {
        this.seatbelttype = seatbelttype;
    }

    public UTF8String getOtherrestraintsysteminformation() {
        return otherrestraintsysteminformation;
    }

    public void setOtherrestraintsysteminformation(UTF8String otherrestraintsysteminformation) {
        this.otherrestraintsysteminformation = otherrestraintsysteminformation;
    }

    public UTF8String getfrontairbaglocations() {
        return frontairbaglocations;
    }

    public void setfrontairbaglocations(UTF8String frontairbaglocations) {
        this.frontairbaglocations = frontairbaglocations;
    }

    public UTF8String getKneeairbaglocations() {
        return kneeairbaglocations;
    }

    public void setKneeairbaglocations(UTF8String kneeairbaglocations) {
        this.kneeairbaglocations = kneeairbaglocations;
    }

    public UTF8String getSideairbaglocations() {
        return sideairbaglocations;
    }

    public void setSideairbaglocations(UTF8String sideairbaglocations) {
        this.sideairbaglocations = sideairbaglocations;
    }

    public UTF8String getFloorconfigurationtype() {
        return floorconfigurationtype;
    }

    public void setFloorconfigurationtype(UTF8String floorconfigurationtype) {
        this.floorconfigurationtype = floorconfigurationtype;
    }

    public UTF8String getTirepressureconfigurationsystem() {
        return tirepressureconfigurationsystem;
    }

    public void setTirepressureconfigurationsystem(UTF8String tirepressureconfigurationsystem) {
        this.tirepressureconfigurationsystem = tirepressureconfigurationsystem;
    }

    public UTF8String getBusfloorconfigurationsystem() {
        return busfloorconfigurationsystem;
    }

    public void setBusfloorconfigurationsystem(UTF8String busfloorconfigurationsystem) {
        this.busfloorconfigurationsystem = busfloorconfigurationsystem;
    }

    public int getNumberofwheels() {
        return numberofwheels;
    }

    public void setNumberofwheels(int numberofwheels) {
        this.numberofwheels = numberofwheels;
    }

    public int getWheelbaseform() {
        return wheelbaseform;
    }

    public void setWheelbaseform(int wheelbaseform) {
        this.wheelbaseform = wheelbaseform;
    }

    public UTF8String getBreaksystemtype() {
        return breaksystemtype;
    }

    public void setBreaksystemtype(UTF8String breaksystemtype) {
        this.breaksystemtype = breaksystemtype;
    }

    public int getBaseprice() {
        return baseprice;
    }

    public void setBaseprice(int baseprice) {
        this.baseprice = baseprice;
    }

    public UTF8String getCurrentairbaglocation() {
        return currentairbaglocation;
    }

    public void setCurrentairbaglocation(UTF8String currentairbaglocation) {
        this.currentairbaglocation = currentairbaglocation;
    }

    public UTF8String getCustommotorcycletype() {
        return custommotorcycletype;
    }

    public void setCustommotorcycletype(UTF8String custommotorcycletype) {
        this.custommotorcycletype = custommotorcycletype;
    }

    public int getBusfloor() {
        return busfloor;
    }

    public void setBusfloor(int busfloor) {
        this.busfloor = busfloor;
    }

    public UTF8String getBustype() {
        return bustype;
    }

    public void setBustype(UTF8String bustype) {
        this.bustype = bustype;
    }

    public UTF8String getMotorcyclesuspensionform() {
        return motorcyclesuspensionform;
    }

    public void setMotorcyclesuspensionform(UTF8String motorcyclesuspensionform) {
        this.motorcyclesuspensionform = motorcyclesuspensionform;
    }

    public UTF8String getMotorcyclechasistype() {
        return motorcyclechasistype;
    }

    public void setMotorcyclechasistype(UTF8String motorcyclechasistype) {
        this.motorcyclechasistype = motorcyclechasistype;
    }

    public UTF8String getPlantcompanyname() {
        return plantcompanyname;
    }

    public void setPlantcompanyname(UTF8String plantcompanyname) {
        this.plantcompanyname = plantcompanyname;
    }

    public UTF8String getPlantstate() {
        return plantstate;
    }

    public void setPlantstate(UTF8String plantstate) {
        this.plantstate = plantstate;
    }

    public UTF8String getSteringlocation() {
        return steringlocation;
    }

    public void setSteringlocation(UTF8String steringlocation) {
        this.steringlocation = steringlocation;
    }

    public UTF8String getDrivetype() {
        return drivetype;
    }

    public void setDrivetype(UTF8String drivetype) {
        this.drivetype = drivetype;
    }

    public UTF8String getElecrtrificationtype() {
        return elecrtrificationtype;
    }

    public void setElecrtrificationtype(UTF8String elecrtrificationtype) {
        this.elecrtrificationtype = elecrtrificationtype;
    }

    public UTF8String getOtherengineeinformation() {
        return otherengineeinformation;
    }

    public void setOtherengineeinformation(UTF8String otherengineeinformation) {
        this.otherengineeinformation = otherengineeinformation;
    }

    public int getTurbo() {
        return turbo;
    }

    public void setTurbo(int turbo) {
        this.turbo = turbo;
    }

    public int getEngineemanufacture() {
        return engineemanufacture;
    }

    public void setEngineemanufacture(int engineemanufacture) {
        this.engineemanufacture = engineemanufacture;
    }

    public int getSeries2() {
        return series2;
    }

    public void setSeries2(int series2) {
        this.series2 = series2;
    }

    public int getWindows() {
        return windows;
    }

    public void setWindows(int windows) {
        this.windows = windows;
    }

    public UTF8String getCurtonairbaglocation() {
        return curtonairbaglocation;
    }

    public void setCurtonairbaglocation(UTF8String curtonairbaglocation) {
        this.curtonairbaglocation = curtonairbaglocation;
    }

    public int getWheelsizefront() {
        return wheelsizefront;
    }

    public void setWheelsizefront(int wheelsizefront) {
        this.wheelsizefront = wheelsizefront;
    }

    public int getWheelsizerear() {
        return wheelsizerear;
    }

    public void setWheelsizerear(int wheelsizerear) {
        this.wheelsizerear = wheelsizerear;
    }

    public int getNumberofseats() {
        return numberofseats;
    }

    public void setNumberofseats(int numberofseats) {
        this.numberofseats = numberofseats;
    }

    public UTF8String getTransmissionstyle() {
        return transmissionstyle;
    }

    public void setTransmissionstyle(UTF8String transmissionstyle) {
        this.transmissionstyle = transmissionstyle;
    }

    public int getAxles() {
        return axles;
    }

    public void setAxles(int axles) {
        this.axles = axles;
    }

    public UTF8String getAntilockbrakingsystem() {
        return antilockbrakingsystem;
    }

    public void setAntilockbrakingsystem(UTF8String antilockbrakingsystem) {
        this.antilockbrakingsystem = antilockbrakingsystem;
    }

    public UTF8String getElectronicstabilitysystem() {
        return electronicstabilitysystem;
    }

    public void setElectronicstabilitysystem(UTF8String electronicstabilitysystem) {
        this.electronicstabilitysystem = electronicstabilitysystem;
    }

    public UTF8String getAcivesafteysystemnote() {
        return acivesafteysystemnote;
    }

    public void setAcivesafteysystemnote(UTF8String acivesafteysystemnote) {
        this.acivesafteysystemnote = acivesafteysystemnote;
    }

    public UTF8String getBackupcamer() {
        return backupcamer;
    }

    public void setBackupcamer(UTF8String backupcamer) {
        this.backupcamer = backupcamer;
    }

    public UTF8String getDaytimerunninglight() {
        return daytimerunninglight;
    }

    public void setDaytimerunninglight(UTF8String daytimerunninglight) {
        this.daytimerunninglight = daytimerunninglight;
    }

    public UTF8String getPretensioner() {
        return pretensioner;
    }

    public void setPretensioner(UTF8String pretensioner) {
        this.pretensioner = pretensioner;
    }

    public UTF8String getEngineconfiguration() {
        return engineconfiguration;
    }

    public void setEngineconfiguration(UTF8String engineconfiguration) {
        this.engineconfiguration = engineconfiguration;
    }





}