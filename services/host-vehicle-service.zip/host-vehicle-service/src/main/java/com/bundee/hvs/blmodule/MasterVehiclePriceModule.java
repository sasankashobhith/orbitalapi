package com.bundee.hvs.blmodule;

import com.bundee.hvs.db.MasterVehicleImageDAO;
import com.bundee.hvs.db.MasterVehiclePriceDAO;
import com.bundee.hvs.defs.HVDefs;
import com.bundee.hvs.pojo.MasterVehicleImageResponse;
import com.bundee.hvs.pojo.MasterVehiclePriceResponse;
import com.bundee.hvs.pojo.VehicleID;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.BaseResponse;
import com.bundee.msfw.defs.UniversalConstants;
import com.bundee.msfw.interfaces.blmodi.BLModServices;
import com.bundee.msfw.interfaces.blmodi.BLModule;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.endpoint.BEndpoint;
import com.bundee.msfw.interfaces.logi.BLogger;
import com.bundee.msfw.interfaces.reqrespi.RequestContext;

public class MasterVehiclePriceModule implements BLModule {
	
	
	@Override
	public void init(BLogger logger, BLModServices blModServices) throws BExceptions {
		// TODO Auto-generated method stub
		
	}
	
	@BEndpoint(uri = HVDefs.Endpoints.GET_ALL_VEHICLEPRICE, httpMethod = UniversalConstants.GET, permission = "")
    public BaseResponse getAllVehiclePrice(BLogger logger, BLModServices blModServices, RequestContext reqCtx) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
           vList = MasterVehiclePriceDAO.geAllMasterVehiclePrice(logger, blModServices.getDBManager());
           return vList;
        } catch (DBException e) {

           vList.setErrorCode("1");
           vList.setErrorMessage("Error in CustomerActivity Request");
           return vList;
        }
    }

	

	@BEndpoint(uri = HVDefs.Endpoints.GET_ALL_PRICEBY_ID, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleID.class)

    public BaseResponse getAllPricebyId(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
    		VehicleID requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = MasterVehiclePriceDAO.getPriceById(logger, blModServices.getDBManager()
                    , requestObject);
            return vList;
        } catch (DBException e) {
           
        	vList.setErrorCode("1");
        	vList.setErrorMessage("Error in Image Request");
            return vList;
        }
       
    }
	
	
	@BEndpoint(uri = HVDefs.Endpoints.INSERT_PRICE_DETAILS, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = MasterVehiclePriceResponse.class)

    public BaseResponse insertPrice(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
    		MasterVehiclePriceResponse requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = MasterVehiclePriceDAO.insertPriceDetails(logger, blModServices.getDBManager()
                    , requestObject);
            return vList;
        } catch (DBException e) {
           
        	vList.setErrorCode("1");
        	vList.setErrorMessage("Error in Image Request");
            return vList;
        }
       
    }
	
	@BEndpoint(uri = HVDefs.Endpoints.UPDATE_PRICEDETAILS, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = MasterVehiclePriceResponse.class)

    public BaseResponse updatePriceDetails(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
    		MasterVehiclePriceResponse requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = MasterVehiclePriceDAO.updateImageDetails(logger, blModServices.getDBManager()
                    , requestObject);
            return vList;
        } catch (Exception e) {
           
        	vList.setErrorCode("1");
        	vList.setErrorMessage("Error in Image Request");
            return vList;
        }
       
    }

}
