package com.bundee.hvs.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import com.bundee.hvs.pojo.BranchRequest;
import com.bundee.hvs.pojo.VehicleUnavailability;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.hvs.utils.ValidationUtil;
import com.bundee.msfw.defs.UTF8String;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.dbi.DBManager;
import com.bundee.msfw.interfaces.dbi.DBQuery;
import com.bundee.msfw.interfaces.dbi.DBQueryBuilder;
import com.bundee.msfw.interfaces.logi.BLogger;

public class VehicleUnavailabilityDAO {
	private static final String GET_UNAVAILABILITY_BY_VEHICLE_ID ="select * from vinxunavailability where vehicleid=? and isactive=true";
	private static final String GET_UNAVAILABILITY_BY_HOST_ID ="select * from vinxunavailability where hostid=? and isactive=true";
	private static final String GET_UNAVAILABILITY_BY_UNAVAILABLE_ID ="select * from vinxunavailability where vinunavailableid=? and isactive=true";
	private static final String GET_ALL_UNAVAILABILITY ="select * from vinxunavailability where isactive=true";
	private static final String INSERT_UNAVAILABILITY ="INSERT INTO vinxunavailability( vehicleid, vin, hostid, startdate, enddate, repeat_type, day) VALUES (?, ?, ?, ?, ?, ?, ?)";
	private static final String UPDATE_UNAVAILABILITY ="UPDATE vinxunavailability SET startdate=?, enddate=?, repeat_type=?, day=?, updateddate=? WHERE vinunavailableid=?";

	public static VehiclesList listVehiclesByID(BLogger logger, DBManager dbm, BranchRequest branchRequest)
			throws DBException {
		VehiclesList vehiclesList=new VehiclesList();
		List<VehicleUnavailability> vehicles=new ArrayList<VehicleUnavailability>();
		String queryString=null;
		if(branchRequest.getFromValue().toLowerCase().equals("vinunavailableid")) {

			queryString = GET_UNAVAILABILITY_BY_UNAVAILABLE_ID;

		}else if(branchRequest.getFromValue().toLowerCase().equals("vehicleid")) {

			queryString = GET_UNAVAILABILITY_BY_VEHICLE_ID;

		}else if(branchRequest.getFromValue().toLowerCase().equals("hostid")) {

			queryString = GET_UNAVAILABILITY_BY_HOST_ID;

		}
		if (dbm == null || queryString == null) {
			vehiclesList.setErrorMessage("Error retrieving details - ");
			vehiclesList.setErrorCode("1");
			return vehiclesList;
		}
		try {
			DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
			DBQuery sq = dbQB.setQueryString(queryString).setBindInputFunction((dbBLogger, ps) -> {
				ps.setInt(1, branchRequest.getFromId());
			}).setFetchDataFunction((dbFLogger, rs) -> {
				vehicles.add(createvehicleunavailability(dbFLogger, rs));
			}).logQuery(true).throwOnNoData(false).build();

			dbm.select(logger, sq);
			vehiclesList.setErrorMessage("Successfully retrieved details - ");
			vehiclesList.setErrorCode("0");
			vehiclesList.getVehicleUnavailabilities().addAll(vehicles);
			return vehiclesList;
		}
		catch (Exception e){
			vehiclesList.setErrorMessage("Error retrieving all branch details - " + e.getMessage());
			vehiclesList.setErrorCode("1");
			return vehiclesList;
		}
	}
	private static VehicleUnavailability createvehicleunavailability(BLogger logger, ResultSet rs) throws SQLException {
		VehicleUnavailability vehicle = new VehicleUnavailability();
		vehicle.setVinunavailableid(rs.getInt("vinunavailableid"));
		vehicle.setVehicleid(rs.getInt("vehicleid"));
		vehicle.setVin(new UTF8String(rs.getString("vin")));
		vehicle.setHostid(rs.getInt("hostid"));
		vehicle.setStartdate(new UTF8String(rs.getString("startdate")));
		vehicle.setEnddate(new UTF8String(rs.getString("enddate")));
		vehicle.setRepeattype(rs.getInt("repeat_type"));
		vehicle.setDay(rs.getInt("day"));
		vehicle.setCreateddate(new UTF8String(rs.getString("createddate")));
		vehicle.setUpdateddate(new UTF8String(rs.getString("updateddate")));
		vehicle.setbActive(rs.getBoolean("isactive"));
		return vehicle;
	}
	public static VehiclesList listAllVehicleUnavailability(BLogger logger, DBManager dbm)
			throws DBException {
		VehiclesList vehiclesList=new VehiclesList();
		List<VehicleUnavailability> vehicles=new ArrayList<VehicleUnavailability>();
		if (dbm == null) {
			vehiclesList.setErrorMessage("Error retrieving details - ");
			vehiclesList.setErrorCode("1");
			return vehiclesList;
		}
		try {
			DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
			DBQuery sq = dbQB.setQueryString(GET_ALL_UNAVAILABILITY).setBindInputFunction((dbBLogger, ps) -> {
			}).setFetchDataFunction((dbFLogger, rs) -> {
				vehicles.add(createvehicleunavailability(dbFLogger, rs));
			}).logQuery(true).throwOnNoData(false).build();

			dbm.select(logger, sq);
			vehiclesList.setErrorMessage("Successfully retrieved details - ");
			vehiclesList.setErrorCode("0");
			vehiclesList.getVehicleUnavailabilities().addAll(vehicles);
			return vehiclesList;
		}
		catch (Exception e){
			vehiclesList.setErrorMessage("Error retrieving all branch details - " + e.getMessage());
			vehiclesList.setErrorCode("1");
			return vehiclesList;
		}
	}
	public static VehiclesList insertVehicleUnavailability(BLogger logger, DBManager dbm,VehicleUnavailability vehicleUnavailability)
			throws DBException {
		VehiclesList vehiclesList=new VehiclesList();
		List<VehicleUnavailability> vehicles=new ArrayList<VehicleUnavailability>();
		if (dbm == null||vehicleUnavailability.getVehicleid()==0||vehicleUnavailability.getVin()==null||vehicleUnavailability.getHostid()==0) {
			vehiclesList.setErrorMessage("Error retrieving details - ");
			vehiclesList.setErrorCode("1");
			return vehiclesList;
		}
		VehiclesList validationResponse = new ValidationUtil().validateVehicleUnavailability(vehicleUnavailability);
		if (validationResponse.getErrorCode().equals("1")) {
			return validationResponse;
		}
		try {
			Date startDate = new SimpleDateFormat("yyyy-MM-dd").parse(vehicleUnavailability.getStartdate().toString());
			java.sql.Date sqlStartDate = new java.sql.Date(startDate.getTime());
			java.sql.Timestamp startDateTS = new java.sql.Timestamp(sqlStartDate.getTime());
			Date endDate = new SimpleDateFormat("yyyy-MM-dd").parse(vehicleUnavailability.getEnddate().toString());
			java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime());
			java.sql.Timestamp endDateTS = new java.sql.Timestamp(sqlEndDate.getTime());
			DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
			DBQuery sq = dbQB.setQueryString(INSERT_UNAVAILABILITY).setBindInputFunction((dbBLogger, ps) -> {
				ps.setInt(1,vehicleUnavailability.getVehicleid());
				ps.setString(2,vehicleUnavailability.getVin().toString());
				ps.setInt(3,vehicleUnavailability.getHostid());
				ps.setTimestamp(4,startDateTS);
				ps.setTimestamp(5,endDateTS);
				ps.setInt(6,vehicleUnavailability.getRepeattype());
				ps.setInt(7,vehicleUnavailability.getDay());
			}).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
				vehicles.add(createvehicleunavailability(dbFLogger, rs));
			}).logQuery(true).throwOnNoData(false).build();

			dbm.update(logger, sq);
			vehiclesList.setErrorMessage("Successfully retrieved details - ");
			vehiclesList.setErrorCode("0");
			vehiclesList.getVehicleUnavailabilities().addAll(vehicles);
			return vehiclesList;
		}
		catch (Exception e){
			vehiclesList.setErrorMessage("Error retrieving all branch details - " + e.getMessage());
			vehiclesList.setErrorCode("1");
			return vehiclesList;
		}
	}
	public static VehiclesList updateVehicleUnavailability(BLogger logger, DBManager dbm,VehicleUnavailability vehicleUnavailability)
			throws DBException {
		VehiclesList vehiclesList=new VehiclesList();
		List<VehicleUnavailability> vehicles=new ArrayList<VehicleUnavailability>();
		if (dbm == null||vehicleUnavailability.getVinunavailableid()==0) {
			vehiclesList.setErrorMessage("Error retrieving details - ");
			vehiclesList.setErrorCode("1");
			return vehiclesList;
		}
		VehiclesList validationResponse = new ValidationUtil().validateVehicleUnavailability(vehicleUnavailability);
		if (validationResponse.getErrorCode().equals("1")) {
			return validationResponse;
		}
		try {
			Date startDate = new SimpleDateFormat("yyyy-MM-dd").parse(vehicleUnavailability.getStartdate().toString());
			java.sql.Date sqlStartDate = new java.sql.Date(startDate.getTime());
			java.sql.Timestamp startDateTS = new java.sql.Timestamp(sqlStartDate.getTime());
			Date endDate = new SimpleDateFormat("yyyy-MM-dd").parse(vehicleUnavailability.getEnddate().toString());
			java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime());
			java.sql.Timestamp endDateTS = new java.sql.Timestamp(sqlEndDate.getTime());
			Date updateddate = new Date();
			java.sql.Date sqlUpdateddate = new java.sql.Date(updateddate.getTime());
			java.sql.Timestamp updateddateTS = new java.sql.Timestamp(sqlUpdateddate.getTime());
			DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
			DBQuery sq = dbQB.setQueryString(UPDATE_UNAVAILABILITY).setBindInputFunction((dbBLogger, ps) -> {
				ps.setTimestamp(1,startDateTS);
				ps.setTimestamp(2,endDateTS);
				ps.setInt(3,vehicleUnavailability.getRepeattype());
				ps.setInt(4,vehicleUnavailability.getDay());
				ps.setTimestamp(5,updateddateTS);
				ps.setInt(6,vehicleUnavailability.getVinunavailableid());
			}).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
				vehicles.add(createvehicleunavailability(dbFLogger, rs));
			}).logQuery(true).throwOnNoData(false).build();

			dbm.update(logger, sq);
			vehiclesList.setErrorMessage("Successfully retrieved details - ");
			vehiclesList.setErrorCode("0");
			vehiclesList.getVehicleUnavailabilities().addAll(vehicles);
			return vehiclesList;
		}
		catch (Exception e){
			vehiclesList.setErrorMessage("Error retrieving all branch details - " + e.getMessage());
			vehiclesList.setErrorCode("1");
			return vehiclesList;
		}
	}
}
