package com.bundee.hvs.pojo;

public class Reservation {
    private int tripcount;
    private float rating;
    private String startTime;
    private String endTime;
    private int userId;
    private int vehicleid;

    public Reservation(int tripcount, float rating, int vehicleid) {
        super();
        this.tripcount = tripcount;
        this.rating = rating;
        this.vehicleid = vehicleid;
    }

    public Reservation(int i, float f, int j, Object object, Object object2) {
        super();
    }

    public int getTripcount() {
        return tripcount;
    }

    public void setTripcount(int tripcount) {
        this.tripcount = tripcount;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getVehicleid() {
        return vehicleid;
    }

    public void setVehicleid(int vehicleid) {
        this.vehicleid = vehicleid;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}
