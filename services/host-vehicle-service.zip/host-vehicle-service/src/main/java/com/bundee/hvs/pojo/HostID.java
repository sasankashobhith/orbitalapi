package com.bundee.hvs.pojo;

public class HostID {
	public Integer hostID;
}