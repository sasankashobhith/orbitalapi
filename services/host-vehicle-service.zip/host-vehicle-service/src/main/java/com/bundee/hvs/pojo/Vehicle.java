package com.bundee.hvs.pojo;

import com.bundee.hvs.ext.vin.data.client.def.VINVehicleData;
import com.bundee.msfw.defs.UTF8String;

public class Vehicle implements VINVehicleData {
	private int id;
	private int typeID;
	private int hostID;
	private int branchID;
	private UTF8String vin;
	private UTF8String make;
	private UTF8String model;
	private UTF8String desc;
	private UTF8String year;
	private UTF8String number;
	private UTF8String color;
	private boolean bActive;
	private long createTS;	
	private long updateTS;
	private UTF8String vehicleLatitude;
	private UTF8String vehicleLongitude;
	private int vehicletypeid;

	public int getVehicletypeid() {
		return vehicletypeid;
	}

	public void setVehicletypeid(int vehicletypeid) {
		this.vehicletypeid = vehicletypeid;
	}

	@Override
	public UTF8String getVIN() {
		return vin;
	}

	@Override
	public UTF8String getMake() {
		return make;
	}

	@Override
	public UTF8String getModel() {
		return model;
	}

	@Override
	public UTF8String getDesc() {
		return desc;
	}

	@Override
	public UTF8String getYear() {
		return year;
	}

	@Override
	public UTF8String getNumber() {
		return number;
	}

	@Override
	public UTF8String getColor() {
		return color;
	}
	
	public int getID() {
		return id;
	}

	public UTF8String getVehicleLatitude() {
		return vehicleLatitude;
	}

	public void setVehicleLatitude(UTF8String vehicleLatitude) {
		this.vehicleLatitude = vehicleLatitude;
	}

	public UTF8String getVehicleLongitude() {
		return vehicleLongitude;
	}

	public void setVehicleLongitude(UTF8String vehicleLongitude) {
		this.vehicleLongitude = vehicleLongitude;
	}

	public int getBranchID() {
		return branchID;
	}

	public void setBranchID(int branchID) {
		this.branchID = branchID;
	}

	public int getTypeID() {
		return typeID;
	}
	public int getHostID() {
		return hostID;
	}

	public boolean isActive() {
		return bActive;
	}
	public long getCreateTS() {
		return createTS;
	}
	public long getUpdateTS() {
		return updateTS;
	}

	public void setID(int id) {
		this.id = id;
	}
	public void setTypeID(int typeID) {
		this.typeID = typeID;
	}
	public void setHostID(int hostID) {
		this.hostID = hostID;
	}
	public void setVin(UTF8String vin) {
		this.vin = vin;
	}
	public void setMake(UTF8String make) {
		this.make = make;
	}
	public void setModel(UTF8String model) {
		this.model = model;
	}
	public void setDesc(UTF8String desc) {
		this.desc = desc;
	}
	public void setYear(UTF8String year) {
		this.year = year;
	}
	public void setNumber(UTF8String number) {
		this.number = number;
	}
	public void setColor(UTF8String color) {
		this.color = color;
	}
	public void setActive(boolean isActive) {
		this.bActive = isActive;
	}
	public void setCreateTS(long createTS) {
		this.createTS = createTS;
	}
	public void setUpdateTS(long updateTS) {
		this.updateTS = updateTS;
	}
}
