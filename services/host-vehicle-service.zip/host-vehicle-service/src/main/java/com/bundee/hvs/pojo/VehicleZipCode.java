package com.bundee.hvs.pojo;

import com.bundee.msfw.defs.UTF8String;

public class VehicleZipCode {
private int id;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getVehicleID() {
	return vehicleID;
}
public void setVehicleID(int vehicleID) {
	this.vehicleID = vehicleID;
}
public int getHostID() {
	return hostID;
}
public void setHostID(int hostID) {
	this.hostID = hostID;
}
public UTF8String getVin() {
	return vin;
}
public void setVin(UTF8String vin) {
	this.vin = vin;
}
public UTF8String getZipcode() {
	return zipcode;
}
public void setZipcode(UTF8String zipcode) {
	this.zipcode = zipcode;
}
public boolean isbActive() {
	return bActive;
}
public void setbActive(boolean bActive) {
	this.bActive = bActive;
}


private int vehicleID;
private int hostID;
private UTF8String vin;
private UTF8String zipcode;
private boolean bActive;
private UTF8String createTS;	
public UTF8String getCreateTS() {
	return createTS;
}
public void setCreateTS(UTF8String createTS) {
	this.createTS = createTS;
}
public UTF8String getUpdateTS() {
	return updateTS;
}
public void setUpdateTS(UTF8String updateTS) {
	this.updateTS = updateTS;
}


private UTF8String updateTS;	

}
