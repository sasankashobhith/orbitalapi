package com.bundee.hvs.db;

import com.bundee.hvs.pojo.CustomerActivityRequest;
import com.bundee.hvs.pojo.CustomerVehicleResponse;
import com.bundee.hvs.pojo.CustomerWishlistResponse;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.dbi.DBManager;
import com.bundee.msfw.interfaces.dbi.DBQuery;
import com.bundee.msfw.interfaces.dbi.DBQueryBuilder;
import com.bundee.msfw.interfaces.logi.BLogger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CustomerWishListDAO {

    private static final String INSERT_INTO_CUSTOMER_WISHLIST = "insert into customerwishlist (userid,vehicleid,isfavourite) values (?,?,?)";
    private static final String UPDATE_CUSTOMERWISHLIST = "UPDATE customerwishlist SET updateddate=?,isactive=? WHERE userid=? AND vehicleid=?";
    private static final String SOFT_UPDATE_CUSTOMERWISHLIST = "UPDATE customerwishlist SET  isactive=?, updateddate=? WHERE userid=? ";
    private static final String GET_CUSTOMERWISHLIST_HOSTVEHICLE = "select b.*,a.isfavourite,a.vehicleid,a.userid,a.isactive as favorite from customerwishlist a inner join mastervehicle b on a.vehicleid=b.id where a.userid=?";
    private static final String GET_ALL_CUSTOMERWISHLIST = "select * from customerwishlist where isactive=true";
    private static final String GET_CUSTOMER_WISHLIST_BYID = "SELECT * FROM customerwishlist WHERE id=? and isactive=true";
    private static final String GET_CUSTOMER_WISHLIST_BY_USERID = "SELECT * FROM customerwishlist WHERE userid=? and isactive=true";
    private static final String GET_CUSTOMER_WISHLIST_BY_USERID_VEHICLEID = "SELECT * FROM customerwishlist WHERE userid=? and vehicleid=? and isactive=true";
    private static final String CHECK_CUSTOMER_WISHLIST_BY_USERID_VEHICLEID = "SELECT * FROM customerwishlist WHERE userid=? and vehicleid=? ";
    private static final String GET_CUSTOMER_WISHLIST_BY_VEHICLEID = "SELECT * FROM customerwishlist WHERE vehicleid=? and isactive=true";

    public static VehiclesList insertSingleCustomerWishList(BLogger logger, DBManager dbm, CustomerWishlistResponse customerobj) throws DBException {
        VehiclesList bookResponse = new VehiclesList();
        try {
            if (dbm == null || customerobj == null || customerobj.getUserid() == 0 || customerobj.getVehicleid() == 0) {
                bookResponse.setErrorCode("1");
                bookResponse.setErrorMessage("Error in CustomerWishList  Request");
                return bookResponse;
            } else {
                DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
                DBQuery sq = dbQB.setBatch().setQueryString(INSERT_INTO_CUSTOMER_WISHLIST).setBindInputFunction((dbLogger, ps) -> {
                    ps.setInt(1, customerobj.getUserid());
                    ps.setInt(2, customerobj.getVehicleid());
                    ps.setBoolean(3, customerobj.getisIsfavourite());
                    ps.addBatch();
                }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                    bookResponse.getCustomerwishlist().add(createCustomerWishList(dbFLogger, rs));
                }).logQuery(true).throwOnNoData(false).build();
                dbm.update(logger, sq);
                bookResponse.setErrorCode("0");
                bookResponse.setErrorMessage("Data inserted successfully");
                return bookResponse;
            }
        } catch (DBException e) {
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in CustomerWishList " + e.getMessage());
            return bookResponse;
        }
    }

    public static VehiclesList getAllCustomerWishList(BLogger logger, DBManager dbm, VehiclesList vehiclesList) throws DBException {
        try {
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(GET_ALL_CUSTOMERWISHLIST).setBindInputFunction((dbBLogger, ps) -> {
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getCustomerwishlist().add(createCustomerWishList(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data retrieved successfully");
            return vehiclesList;
        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving all CustomerWishlist details - " + e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }
    }

    private static CustomerWishlistResponse createCustomerWishList(BLogger logger, ResultSet rs) throws SQLException {
        CustomerWishlistResponse customeractivity = new CustomerWishlistResponse();
        customeractivity.setId(rs.getInt("id"));
        customeractivity.setUserid(rs.getInt("userid"));
        customeractivity.setVehicleid(rs.getInt("vehicleid"));
        customeractivity.setIsfavourite(rs.getBoolean("isfavourite"));
        customeractivity.setCreateddate(rs.getString("createddate"));
        customeractivity.setIsactive(rs.getBoolean("isactive"));
        return customeractivity;
    }

    public static VehiclesList getCustomerWishListbyID(BLogger logger, DBManager dbm, CustomerActivityRequest resObject, List<CustomerWishlistResponse> customerwishlistresponse) throws DBException {
        VehiclesList bookResponse = new VehiclesList();
        if (dbm == null || resObject == null || resObject.getFromvalue() == null) {
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Invalid Input Request");
            return bookResponse;
        }
        try {
            String queryString = "NA";
            if (resObject.getFromvalue().equalsIgnoreCase("id")) {
                queryString = GET_CUSTOMER_WISHLIST_BYID;
            } else if (resObject.getFromvalue().equalsIgnoreCase("userid")) {
                queryString = GET_CUSTOMER_WISHLIST_BY_USERID;
            } else if (resObject.getFromvalue().equalsIgnoreCase("vehicleid")) {
                queryString = GET_CUSTOMER_WISHLIST_BY_VEHICLEID;
            } else if (resObject.getFromvalue().equalsIgnoreCase("useridnvehicleid")) {
                queryString = GET_CUSTOMER_WISHLIST_BY_USERID_VEHICLEID;
            } else {
                bookResponse.setErrorCode("1");
                bookResponse.setErrorMessage("Invalid Input Request");
                return bookResponse;
            }
            if (queryString.equals("NA")) {
                bookResponse.setErrorCode("1");
                bookResponse.setErrorMessage("Invalid Input Request");
                return bookResponse;
            }
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(queryString).setBindInputFunction((dbLogger, ps) -> {
                if (resObject.getFromvalue().equalsIgnoreCase("id")) {
                    ps.setInt(1, resObject.getId());
                } else if (resObject.getFromvalue().equalsIgnoreCase("vehicleid")) {
                    ps.setInt(1, resObject.getId());
                } else if (resObject.getFromvalue().equalsIgnoreCase("userid")) {
                    ps.setInt(1, resObject.getId());
                } else if (resObject.getFromvalue().equalsIgnoreCase("useridnvehicleid")) {
                    ps.setInt(1, resObject.getUserid());
                    ps.setInt(2, resObject.getVehicleid());
                }
            }).setFetchDataFunction((dbFLogger, rs) -> {
                customerwishlistresponse.add(createCustomerWishList(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            bookResponse.setErrorCode("0");
            bookResponse.setErrorMessage("Data retrieved Succesfully");
            bookResponse.setCustomerwishlist(customerwishlistresponse);
            return bookResponse;
        } catch (Exception e) {
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in Customer Request exception" + e.getMessage());
            return bookResponse;
        }
    }

    public static VehiclesList updateCustomerWishList(BLogger logger, DBManager dbm, CustomerWishlistResponse customerobj) throws DBException {
        VehiclesList bookResponse = new VehiclesList();
        try {
            if (dbm == null || customerobj == null) {
                bookResponse.setErrorCode("1");
                bookResponse.setErrorMessage("Error in CustomerWishList  Request");
                return bookResponse;
            } else {
                List<CustomerWishlistResponse> customerwishlistresponse = new ArrayList<CustomerWishlistResponse>();
                DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
                DBQuery sq = dbQB.setQueryString(CHECK_CUSTOMER_WISHLIST_BY_USERID_VEHICLEID).setBindInputFunction((dbLogger, ps) -> {
                    ps.setInt(1, customerobj.getUserid());
                    ps.setInt(2, customerobj.getVehicleid());
                }).setFetchDataFunction((dbFLogger, rs) -> {
                    customerwishlistresponse.add(createCustomerWishList(dbFLogger, rs));
                }).logQuery(true).throwOnNoData(false).build();
                dbm.select(logger, sq);
                if (customerwishlistresponse.isEmpty()) {
                    bookResponse = insertSingleCustomerWishList(logger, dbm, customerobj);
                    return bookResponse;
                }
                if (customerobj.getUserid() == 0 || customerobj.getVehicleid() == 0) {
                    bookResponse.setErrorCode("1");
                    bookResponse.setErrorMessage("Error in CustomerWishList  Request");
                    return bookResponse;
                }
                Date updateddate = new Date();
                java.sql.Date sqlupdateddate = new java.sql.Date(updateddate.getTime());
                java.sql.Timestamp updateddatets = new java.sql.Timestamp(sqlupdateddate.getTime());
                DBQueryBuilder dbQBUpdate = dbm.getDBQueryBuilder();
                VehiclesList finalBookResponse = bookResponse;
                DBQuery sqUpdate = dbQBUpdate.setBatch().setQueryString(UPDATE_CUSTOMERWISHLIST).setBindInputFunction((dbLogger, ps) -> {
                    ps.setTimestamp(1, updateddatets);
                    ps.setBoolean(2, customerobj.getisIsfavourite());
                    ps.setInt(3, customerobj.getUserid());
                    ps.setInt(4, customerobj.getVehicleid());
                    ps.addBatch();
                }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                    finalBookResponse.getCustomerwishlist().add(createCustomerWishList(dbFLogger, rs));
                }).logQuery(true).throwOnNoData(false).build();
                dbm.update(logger, sqUpdate);
                bookResponse.setErrorCode("0");
                bookResponse.setErrorMessage("Data updated successfully");
                return bookResponse;
            }
        } catch (DBException e) {
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in CustomerWishList " + e.getMessage());
            return bookResponse;
        }
    }

    public static VehiclesList softUpdateCustomerWishList(BLogger logger, DBManager dbm, CustomerWishlistResponse customerobj) throws DBException {
        VehiclesList bookResponse = new VehiclesList();
        try {
            if (dbm == null || customerobj == null || customerobj.getUserid() == 0) {
                bookResponse.setErrorCode("1");
                bookResponse.setErrorMessage("Error in CustomerWishList  Request");
                return bookResponse;
            } else {
                Date updateddate = new Date();
                java.sql.Date sqlupdateddate = new java.sql.Date(updateddate.getTime());
                java.sql.Timestamp updateddatets = new java.sql.Timestamp(sqlupdateddate.getTime());
                DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
                DBQuery sq = dbQB.setBatch().setQueryString(SOFT_UPDATE_CUSTOMERWISHLIST).setBindInputFunction((dbLogger, ps) -> {
                    ps.setBoolean(1, customerobj.getisIsactive());
                    ps.setTimestamp(2, updateddatets);
                    ps.setInt(3, customerobj.getUserid());
                    ps.addBatch();
                }).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
                    bookResponse.getCustomerwishlist().add(createCustomerWishList(dbFLogger, rs));
                }).logQuery(true).throwOnNoData(false).build();
                dbm.update(logger, sq);
                bookResponse.setErrorCode("0");
                bookResponse.setErrorMessage("Data inserted successfully");
                return bookResponse;
            }
        } catch (DBException e) {
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in CustomerWishList " + e.getMessage());
            return bookResponse;
        }
    }

    public static VehiclesList getCustomerWishlistandvehicle(BLogger logger, DBManager dbm,
                                                             int userid) throws DBException {
        VehiclesList bookResponse = new VehiclesList();
        try {
            if (dbm == null || userid == 0) {
                bookResponse.setErrorCode("1");
                bookResponse.setErrorMessage("Error in CustomerWishList  Request");
                return bookResponse;
            } else {
                DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
                DBQuery sq = dbQB.setBatch().setQueryString(GET_CUSTOMERWISHLIST_HOSTVEHICLE)
                        .setBindInputFunction((dbLogger, ps) -> {
                            ps.setInt(1, userid);
                            ps.addBatch();
                        }).setFetchDataFunction((dbFLogger, rs) -> {
                            bookResponse.getCustomervehicleresponse().add(createcustomerWishlistVehicle(dbFLogger, rs));
                        }).logQuery(true).throwOnNoData(false).build();
                dbm.select(logger, sq);
                bookResponse.setErrorCode("0");
                bookResponse.setErrorMessage("Data retrieved successfully");
                return bookResponse;
            }
        } catch (DBException e) {
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in CustomerWishList " + e.getMessage());
            return bookResponse;
        }
    }

    private static CustomerVehicleResponse createcustomerWishlistVehicle(BLogger logger, ResultSet rs)
            throws SQLException {
        CustomerVehicleResponse customeractivity = new CustomerVehicleResponse();
        customeractivity.setId(rs.getInt("id"));
        customeractivity.setUserid(rs.getInt("userid"));
        customeractivity.setVehicleid(rs.getInt("vehicleid"));
        customeractivity.setVin(rs.getString("vin"));
        customeractivity.setMake(rs.getString("make"));
        customeractivity.setModel(rs.getString("model"));
        customeractivity.setDescription(rs.getString("description"));
        customeractivity.setYear(rs.getString("year"));
        customeractivity.setVehicle_type_id(rs.getInt("vehicle_type_id"));
        customeractivity.setVhost(rs.getInt("vhost"));
        customeractivity.setBranchid(rs.getInt("branchid"));
        customeractivity.setVnumber(rs.getString("vnumber"));
        customeractivity.setVcolor(rs.getString("vcolor"));
        customeractivity.setIsactive(rs.getBoolean("favorite"));
        customeractivity.setCrtd_ts(rs.getString("crtd_ts"));
        customeractivity.setIsfavourite(rs.getBoolean("isfavourite"));
        return customeractivity;
    }
}
