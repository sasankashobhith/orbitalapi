package com.bundee.hvs.pojo;

import com.bundee.msfw.defs.UTF8String;

public class VehicleUnavailability {

    private int vinunavailableid;
    private int day;
    private UTF8String vin;
    private boolean bActive;
    private UTF8String createddate;
    private int vehicleid;
    private int hostid;
    private int repeattype;
    private UTF8String updateddate;
    private UTF8String startdate;
    private UTF8String enddate;

    public int getVinunavailableid() {
        return vinunavailableid;
    }

    public void setVinunavailableid(int vinunavailableid) {
        this.vinunavailableid = vinunavailableid;
    }

    public int getVehicleid() {
        return vehicleid;
    }

    public void setVehicleid(int vehicleid) {
        this.vehicleid = vehicleid;
    }

    public int getHostid() {
        return hostid;
    }

    public void setHostid(int hostid) {
        this.hostid = hostid;
    }

    public UTF8String getVin() {
        return vin;
    }

    public void setVin(UTF8String vin) {
        this.vin = vin;
    }

    public boolean isbActive() {
        return bActive;
    }

    public void setbActive(boolean bActive) {
        this.bActive = bActive;
    }

    public int getRepeattype() {
        return repeattype;
    }

    public void setRepeattype(int repeattype) {
        this.repeattype = repeattype;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public UTF8String getCreateddate() {
        return createddate;
    }

    public void setCreateddate(UTF8String createddate) {
        this.createddate = createddate;
    }

    public UTF8String getUpdateddate() {
        return updateddate;
    }

    public void setUpdateddate(UTF8String updateddate) {
        this.updateddate = updateddate;
    }

    public UTF8String getStartdate() {
        return startdate;
    }

    public void setStartdate(UTF8String startdate) {
        this.startdate = startdate;
    }

    public UTF8String getEnddate() {
        return enddate;
    }

    public void setEnddate(UTF8String enddate) {
        this.enddate = enddate;
    }


}
