package com.bundee.hvs.blmodule;


import com.bundee.hvs.db.VehicleTypeDAO;
import com.bundee.hvs.defs.HVDefs;
import com.bundee.hvs.defs.HVSProcessingCode;

import com.bundee.hvs.pojo.VehicleID;
import com.bundee.hvs.pojo.VehicleTypeList;
import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.BaseResponse;
import com.bundee.msfw.defs.UniversalConstants;
import com.bundee.msfw.interfaces.blmodi.BLModServices;
import com.bundee.msfw.interfaces.blmodi.BLModule;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.endpoint.BEndpoint;
import com.bundee.msfw.interfaces.logi.BLogger;
import com.bundee.msfw.interfaces.reqrespi.RequestContext;

public class VehicleTypeModule implements BLModule {
	@Override
	public void init(BLogger logger, BLModServices blModServices) throws BExceptions {
		
	}
	 
	@BEndpoint(uri = HVDefs.Endpoints.GET_TYPE, httpMethod = UniversalConstants.GET, permission = "", reqDTOClass = VehicleID.class)
	public BaseResponse listVehicleFeatures(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
			VehicleID requestObject) throws BExceptions {
		VehicleTypeList vList = new VehicleTypeList(); 

		try {
			VehicleTypeDAO.listVehiclesByType(logger, blModServices.getDBManager(), requestObject.vehicleId, vList.getVehicleTypes());
		} catch (DBException e) {
			throw new BExceptions(e, HVSProcessingCode.VEHICLES_NOT_FOUND);
		}
				
		return vList;
	}
}
