package com.bundee.hvs.blmodule;

import com.bundee.hvs.db.VehicleZipCodeDAO;
import com.bundee.hvs.defs.HVDefs;
import com.bundee.hvs.defs.HVSProcessingCode;
import com.bundee.hvs.pojo.VehicleType;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.hvs.pojo.VinzipcodeResponse;
import com.bundee.hvs.utils.VinZipcodeUtill;
import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.BaseResponse;
import com.bundee.msfw.defs.UniversalConstants;
import com.bundee.msfw.interfaces.blmodi.BLModServices;
import com.bundee.msfw.interfaces.blmodi.BLModule;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.endpoint.BEndpoint;
import com.bundee.msfw.interfaces.logi.BLogger;
import com.bundee.msfw.interfaces.reqrespi.RequestContext;

public class VehicleZipCodeModule implements BLModule {
	@Override
	public void init(BLogger logger, BLModServices blModServices) throws BExceptions {

	}

	@BEndpoint(uri = HVDefs.Endpoints.INSERT_VINZIPCODE, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VinzipcodeResponse.class)
	public BaseResponse insertvinzip(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
			VinzipcodeResponse requestObject) throws BExceptions {
		VinzipcodeResponse reservationCreateObj = VinZipcodeUtill.createSingleZipcode(requestObject);
		VehiclesList vList = new VehiclesList();
		try {
			vList = VehicleZipCodeDAO.insertVinZipcode(logger, blModServices.getDBManager(), reservationCreateObj);
		} catch (DBException e) {
			throw new BExceptions(e, HVSProcessingCode.VEHICLES_NOT_FOUND);
		}

		return vList;
	}

	@BEndpoint(uri = HVDefs.Endpoints.GET_ALL_VINZIPCODE, httpMethod = UniversalConstants.GET, permission = "")
	public BaseResponse getAllVinZipcode(BLogger logger, BLModServices blModServices, RequestContext reqCtx)
			throws BExceptions {
		VehiclesList vList = new VehiclesList();
		try {
			vList = VehicleZipCodeDAO.getAllVinZipcode(logger, blModServices.getDBManager(), vList);
			return vList;
		} catch (DBException e) {
			vList.setErrorCode("1");
			vList.setErrorMessage("Error in VinZipcode Request");
			return vList;
		}

	}

	@BEndpoint(uri = HVDefs.Endpoints.GET_ALL_VINZIPCODE_BY_ID, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleType.class)
	public BaseResponse getAllVinZipbyid(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
			VehicleType requestObject) throws BExceptions {
		VehiclesList vList = new VehiclesList();

		try {
			vList = VehicleZipCodeDAO.getVinZipCodebyid(logger, blModServices.getDBManager(), requestObject,
					vList.getVinzipcoderesponse());
		} catch (DBException e) {
			VehiclesList bookResponse = new VehiclesList();
			bookResponse.setErrorCode("1");
			bookResponse.setErrorMessage("Error in Vinzipcode Request");
			return bookResponse;
		}

		return vList;
	}

	@BEndpoint(uri = HVDefs.Endpoints.UPDATE_VINZIPCODE, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VinzipcodeResponse.class)
	public BaseResponse updateVinZipcode(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
			VinzipcodeResponse featureObject) throws BExceptions {

		try {
			VehiclesList genericresponse = VehicleZipCodeDAO.updatevinzipcode(logger, blModServices.getDBManager(),
					featureObject);
			return genericresponse;
		} catch (DBException e) {
			VehiclesList bookResponse = new VehiclesList();
			bookResponse.setErrorCode("1");
			bookResponse.setErrorMessage("Error in VinZipcode Update Request");
			return bookResponse;
		}

	}
}
