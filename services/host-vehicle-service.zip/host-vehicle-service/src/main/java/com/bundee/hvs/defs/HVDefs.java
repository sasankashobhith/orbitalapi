package com.bundee.hvs.defs;

public class HVDefs {

    public class Endpoints {
        public static final String UPLOAD_VEHICLES = "api/v1/vehicle/createVehiclesByCsv";
        public static final String UPLOAD_VINS = "api/v1/vehicle/createVehiclesByVinCsv";
        public static final String LIST_VEHICLES_BY_HOST = "api/v1/vehicle/getVehiclesByHostId";
        public static final String GEN_VINS = "api/v1/vehicle/createVehiclesByVin";
        public static final String GET_FEATURES_BY_VEHICLE_BY_ID = "api/v1/vehicle/getVehicleFeatureByVehicleId";
        public static final String GET_FEATURES_BY_VEHICLE_BY_ID_PAGE = "api/v1/vehicle/getVehicleFeatureByVehicleIdWithPagination";
        public static final String GET_FEATURES_BY_ID = "api/v1/vehicle/getVehicleFeatureById";
        public static final String GET_ALL_FEATURES = "api/v1/vehicle/getAllVehicleFeatureList";
        public static final String INSERT_FEATURES = "api/v1/vehicle/insertVehicleFeature";
        public static final String INSERT_ALL_FEATURES = "api/v1/vehicle/insertVehicleFeatures";
        public static final String UPDATE_FEATURES = "api/v1/vehicle/updateVehicleFeature";
        public static final String GET_ZIP = "api/v1/vehicle/list/{vehicleID}";
        public static final String GET_TYPE = "api/v1/vehicle/getVehicleType/{ID}";
        public static final String GET_UNAVAILABILITY = "api/v1/vehicle/getVehicleUnavailabilityByIds";
        public static final String GET_ALL_UNAVAILABILITY = "api/v1/vehicle/getAllVehicleUnavailability";
        public static final String INSERT_UNAVAILABILITY = "api/v1/vehicle/insertVehicleUnavailability";
        public static final String UPDATE_UNAVAILABILITY = "api/v1/vehicle/updateVehicleUnavailability";
        public static final String GET_ALL_CUSTOMERWISHLIST_BY_USERID = "api/v1/vehicle/getWishListByUserId";
        public static final String VEHICLE_DETAIL_BY_ID = "api/v1/vehicle/getVehicleById";
        public static final String GET_ALL_VEHICLES = "api/v1/vehicle/getAllVehicleList";
        public static final String UPDATE_VEHICLE = "api/v1/vehicle/updateVehicle";
        public static final String VEHICLE_BY_ID = "api/v1/vehicle/getVehicleDById";
        public static final String GET_VEHICLE_MASTER_BY_ID = "api/v1/vehicle/getVehicleBranchDetailsById";
        public static final String GET_ALL_MASTER_BRANCH = "api/v1/vehicle/getAllBranches";
        public static final String GET_MASTER_BRANCH_BY_ID = "api/v1/vehicle/getBranchById";
        public static final String INSERT_MASTER_BRANCH = "api/v1/vehicle/insertBranch";
        public static final String UPDATE_MASTER_BRANCH = "api/v1/vehicle/updateBranch";
        public static final String INSERT_MASTER_VEHICLE = "api/v1/vehicle/insertVehicle";
        public static final String INSERT_CUTOMERACTIVITY = "api/v1/vehicle/insertCustomerActivity";
        public static final String SOFT_UPDATE_CUTOMERACTIVITY = "api/v1/vehicle/softUpdateCustomerActivity";
        public static final String UPDATE_CUTOMERACTIVITY = "api/v1/vehicle/updateCustomerActivity";
        public static final String GET_ALL_CUSTOMERACTIVITY = "api/v1/vehicle/getAllCustomerActivity";
        public static final String GET_ALL_CUSTOMERACTIVITY_BY = "api/v1/vehicle/getCustomerActivityById";
        public static final String UPDATE_CUSTOMERWISHLIST = "api/v1/vehicle/updateCustomerWishList";
        public static final String SOFTUPDATE_CUSTOMERWISHLIST = "api/v1/vehicle/softUpdateCustomerWishList";
        public static final String INSERT_CUSTOMERWISHLIST = "api/v1/vehicle/insertCustomerWishList";
        public static final String GET_ALL_CUSTOMERWISHLIST = "api/v1/vehicle/getAllCustomerwishList";
        public static final String GET_ALL_CUSTOMERWISHLIST_BYID = "api/v1/vehicle/getCustomertWishListById";
        public static final String INSERT_VINZIPCODE = "api/v1/vehicle/insertVinxZipCode";
        public static final String GET_ALL_VINZIPCODE = "api/v1/vehicle/getAllVinZipCode";
        public static final String GET_ALL_VINZIPCODE_BY_ID = "api/v1/vehicle/getVinZipCodeById";
        public static final String UPDATE_VINZIPCODE = "api/v1/vehicle/updateVinZipCode";
        public static final String GET_ALL_VEHICLEIMAGE = "api/v1/vehicle/getAllVehicleImage";
        public static final String GET_ALL_INVEHICLEIMAGE = "api/v1/vehicle/getVehicleImageById";
        public static final String GET_ALL_BY_IMAGEID = "api/v1/vehicle/vehicle/getImageByID";
        public static final String INSERT_IMAGE_DETAILS = "api/v1/vehicle/vehicle/insertImageDetails";
        public static final String UPDATE_IMAGEDETAILS = "api/v1/vehicle/vehicle/updateImageDetails";
        public static final String GET_ALL_VEHICLEPRICE = "api/v1/vehicle/vehicle/getAllVehiclePrice";
        public static final String GET_ALL_PRICEBY_ID = "api/v1/vehicle/vehicle/getVehiclePriceByID";
        public static final String INSERT_PRICE_DETAILS = "api/v1/vehicle/vehicle/insertVehiclePriceDetails";
        public static final String UPDATE_PRICEDETAILS = "api/v1/vehicle/vehicle/updateVehiclePriceDetails";
        public static final String UPLOAD_VEHICLES_FEATUERS = "api/v1/vehicle/uploadVehicleFeatures";
        public static final String UPLOAD_VEHICLES_IMAGES = "api/v1/vehicle/uploadVehicleImages";

    }
}
