package com.bundee.hvs.blmodule;

import com.bundee.hvs.db.CustomerWishListDAO;
import com.bundee.hvs.db.MasterVehicleImageDAO;
import com.bundee.hvs.defs.HVDefs;
import com.bundee.hvs.pojo.CustomerActivityRequest;
import com.bundee.hvs.pojo.CustomerWishlistResponse;
import com.bundee.hvs.pojo.MasterVehicleImageResponse;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.hvs.utils.CustomerWishListUtil;
import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.BaseResponse;
import com.bundee.msfw.defs.UniversalConstants;
import com.bundee.msfw.interfaces.blmodi.BLModServices;
import com.bundee.msfw.interfaces.blmodi.BLModule;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.endpoint.BEndpoint;
import com.bundee.msfw.interfaces.logi.BLogger;
import com.bundee.msfw.interfaces.reqrespi.RequestContext;

import java.util.List;
import java.util.stream.Collectors;

public class CustomerWishListModule implements BLModule {

    @Override
    public void init(BLogger logger, BLModServices blModServices) throws BExceptions {
    }

    @BEndpoint(uri = HVDefs.Endpoints.INSERT_CUSTOMERWISHLIST, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = CustomerWishlistResponse.class)
    public BaseResponse createCustomerWishList(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                               CustomerWishlistResponse resObject) throws BExceptions {
        CustomerWishlistResponse reservationCreateObj = CustomerWishListUtil.createSingleCustomerWishListResponse(resObject);
        VehiclesList bookResponse = new VehiclesList();
        try {
            bookResponse = CustomerWishListDAO.insertSingleCustomerWishList(logger, blModServices.getDBManager(),
                    reservationCreateObj);
        } catch (DBException e) {
            e.printStackTrace();
        } catch (BExceptions e) {
            e.printStackTrace();
        }
        return bookResponse;
    }

    @BEndpoint(uri = HVDefs.Endpoints.GET_ALL_CUSTOMERWISHLIST, httpMethod = UniversalConstants.GET, permission = "")
    public BaseResponse getAllCustomerWishList(BLogger logger, BLModServices blModServices, RequestContext reqCtx) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = CustomerWishListDAO.getAllCustomerWishList(logger, blModServices.getDBManager(), vList);
            return vList;
        } catch (DBException e) {
            vList.setErrorCode("1");
            vList.setErrorMessage("Error in CustomerActivity Request");
            return vList;
        }
    }

    @BEndpoint(uri = HVDefs.Endpoints.GET_ALL_CUSTOMERWISHLIST_BYID, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = CustomerActivityRequest.class)
    public BaseResponse getAllCustomerWishListbyID(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                                   CustomerActivityRequest requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = CustomerWishListDAO.getCustomerWishListbyID(logger, blModServices.getDBManager()
                    , requestObject, vList.getCustomerwishlist());
        } catch (DBException e) {
            VehiclesList bookResponse = new VehiclesList();
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in Customer Request");
            return bookResponse;
        }
        return vList;
    }

    @BEndpoint(uri = HVDefs.Endpoints.UPDATE_CUSTOMERWISHLIST, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = CustomerWishlistResponse.class)
    public BaseResponse updateCustomerWishList(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                               CustomerWishlistResponse resObject) throws BExceptions {
        CustomerWishlistResponse reservationCreateObj = CustomerWishListUtil.createSingleCustomerWishListResponse(resObject);
        VehiclesList bookResponse = new VehiclesList();
        try {
            bookResponse = CustomerWishListDAO.updateCustomerWishList(logger, blModServices.getDBManager(),
                    reservationCreateObj);
        } catch (Exception e) {
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in Customer Request");
            return bookResponse;
        }
        return bookResponse;
    }

    @BEndpoint(uri = HVDefs.Endpoints.SOFTUPDATE_CUSTOMERWISHLIST, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = CustomerWishlistResponse.class)
    public BaseResponse softUpdateCustomerWishList(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                                   CustomerWishlistResponse resObject) throws BExceptions {
        CustomerWishlistResponse reservationCreateObj = CustomerWishListUtil.createSingleCustomerWishListResponse(resObject);
        VehiclesList bookResponse = new VehiclesList();
        try {
            bookResponse = CustomerWishListDAO.softUpdateCustomerWishList(logger, blModServices.getDBManager(),
                    reservationCreateObj);
        } catch (Exception e) {
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in Customer Request");
            return bookResponse;
        }
        return bookResponse;
    }

    @BEndpoint(uri = HVDefs.Endpoints.GET_ALL_CUSTOMERWISHLIST_BY_USERID, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = CustomerActivityRequest.class)
    public BaseResponse getAllCustomerWishlistbyuserid(BLogger logger, BLModServices blModServices,
                                                       RequestContext reqCtx, CustomerActivityRequest requestObject) throws BExceptions {
        try {
            VehiclesList vListWishList = CustomerWishListDAO.getCustomerWishlistandvehicle(logger,
                    blModServices.getDBManager(), requestObject.getUserid());
            if (vListWishList.getErrorCode().equals("0")) {
                if (vListWishList.getCustomervehicleresponse().size() > 0) {
                    List<Integer> getVehicleList = vListWishList.getCustomervehicleresponse().stream()
                            .map(e -> e.getVehicleid()).distinct().collect(Collectors.toList());
                    VehiclesList vListimage = MasterVehicleImageDAO.geAllMasterVehicle(logger,
                            blModServices.getDBManager(), getVehicleList.toString().replace("[", "").replace("]", ""));
                    for (int i = 0; i < vListWishList.getCustomervehicleresponse().size(); i++) {
                        int vehicleId = vListWishList.getCustomervehicleresponse().get(i).getVehicleid();
                        List<MasterVehicleImageResponse> vehicleImageData = vListimage.getImageresponse().stream()
                                .filter(item -> item.getVehicleid() == vehicleId).collect(Collectors.toList());
                        vListWishList.getCustomervehicleresponse().get(i).setImageresponse(vehicleImageData);
                    }
                }
                return vListWishList;
            } else {
                return vListWishList;
            }
        } catch (DBException e) {
            VehiclesList bookResponse = new VehiclesList();
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in Customer Request");
            return bookResponse;
        }
    }
}
