package com.bundee.hvs.utils;

import com.bundee.hvs.pojo.CustomerWishlistResponse;
import com.bundee.msfw.defs.BExceptions;

public class CustomerWishListUtil {
	
	public static CustomerWishlistResponse createSingleCustomerWishListResponse(CustomerWishlistResponse row) throws BExceptions {
		CustomerWishlistResponse res = new CustomerWishlistResponse();

		res.setId(row.getId());
		res.setUserid(row.getUserid());
		res.setVehicleid(row.getVehicleid());
		res.setIsfavourite(row.getisIsfavourite());
		res.setCreateddate(row.getCreateddate());
		res.setIsactive(row.getisIsactive());
		
		return res;

	}

}
	
	


