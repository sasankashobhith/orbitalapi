package com.bundee.hvs.pojo;
import java.util.ArrayList;
import java.util.List;

import com.bundee.msfw.defs.BaseResponse;

public class VehicleZipCodeList extends BaseResponse {
	List<VehicleZipCode> vehicles;
	
	public VehicleZipCodeList() {
		vehicles = new ArrayList<VehicleZipCode>();
	}
	
	public List<VehicleZipCode> getVehicles() {
		return vehicles;
	}
}
