package com.bundee.hvs.utils;

import com.bundee.hvs.db.VehicleFeatureDAO;
import com.bundee.hvs.defs.HVSProcessingCode;
import com.bundee.hvs.pojo.Vehicle;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.BaseResponse;
import com.bundee.msfw.interfaces.blmodi.BLModServices;
import com.bundee.msfw.interfaces.blmodi.PageHandler;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.dbi.DBManager;
import com.bundee.msfw.interfaces.logi.BLogger;

import java.util.ArrayList;
import java.util.List;

public class VehicleFeatureListPageHandler implements PageHandler {

	List<Long> featureIDs = new ArrayList<Long>();
	
	@Override
	public int getPageSize() {
		return 10;
	}

	@Override
	public List<Long> getFullDataIDs(BLogger logger) {
		return featureIDs;
	}

	@Override
	public BaseResponse getDataFromIDs(BLogger logger, BLModServices blModServices, List<Long> ids4Page)
			throws BExceptions {
		List<Vehicle> vehicles = new ArrayList<Vehicle>();
		VehiclesList vList = new VehiclesList();
		try {
			vList = VehicleFeatureDAO.listFeaturesByIDs(logger, blModServices.getDBManager(), ids4Page);
		} catch (DBException e) {
			throw new BExceptions(e, HVSProcessingCode.VEHICLES_NOT_FOUND);
		}
		return vList;
	}

	public void listVehicleFeatureByID(BLogger logger, DBManager dbm, int vehicleId) throws DBException {
		VehicleFeatureDAO.listVehiclesByFeatureIDs(logger, dbm,vehicleId,featureIDs);
//		VehicleDAO.listVehicleIDsByHostID(logger, dbm, hostID, vehicleIDs);
	}
}
