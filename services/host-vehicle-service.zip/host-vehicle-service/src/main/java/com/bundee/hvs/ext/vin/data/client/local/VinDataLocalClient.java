package com.bundee.hvs.ext.vin.data.client.local;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

import com.bundee.hvs.defs.HVSProcessingCode;
import com.bundee.hvs.ext.vin.data.client.def.VINVehicleData;
import com.bundee.hvs.ext.vin.data.client.def.VinDataClient;
import com.bundee.hvs.ext.vin.data.client.local.VehicleGenData.Make;
import com.bundee.hvs.pojo.Vehicle;
import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.UTF8String;
import com.bundee.msfw.interfaces.blmodi.BLModServices;
import com.bundee.msfw.interfaces.logi.BLogger;

public class VinDataLocalClient implements VinDataClient {
	private static final String LOCAL_VIND_FILE = "test_data" + File.separator + "vin_data.json"; 
	private VehicleGenData vehicleGenData;
	private Random rand;
	
	@Override
	public void init(BLogger logger, BLModServices blModServices) throws BExceptions {
		String vindFilePath = blModServices.getFileCfgHandler().getApplication().makeAbsolutePathFromRoot(LOCAL_VIND_FILE);
		try {
			UTF8String vindContents = new UTF8String(Files.readString(Path.of(vindFilePath)));
			vehicleGenData = (VehicleGenData)blModServices.getUtilFactory().getObjectFromJSON(logger, vindContents.getUTF8String(), VehicleGenData.class);
			VehicleGenData.validate(vehicleGenData);
			logger.debug(vehicleGenData.toString());
			rand = new Random();
			rand.setSeed(System.currentTimeMillis());			
		} catch (IOException e) {
			logger.error(e);
		}
	}

	@Override
	public Map<UTF8String, VINVehicleData> getVINDetails(BLogger logger, Collection<UTF8String> vins) throws BExceptions {
		if(vins == null || vins.isEmpty()) {
			throw new BExceptions(HVSProcessingCode.INVALID_VINS, "VINs are empty!");
		}
		
		Map<UTF8String, VINVehicleData> vinDataMap = new HashMap<UTF8String, VINVehicleData>();
		for(UTF8String vin : vins) {
			VINVehicleData vinVD = createVINVehicleData(vin);
			vinDataMap.put(vin, vinVD);
		}
		return vinDataMap;
	}

	private VINVehicleData createVINVehicleData(UTF8String vin) throws BExceptions {
		Vehicle vinVD = new Vehicle();
		vinVD.setVin(vin);
		Make make = getMakeValue(vehicleGenData.getMakeList());
		vinVD.setMake(make.make);
		vinVD.setModel(getStrValue(make.getModels()));
		vinVD.setDesc(getStrValue(vehicleGenData.getDescriptions()));		
		vinVD.setYear( new UTF8String(String.format("%d", generateRandom(vehicleGenData.getYearsRS(), vehicleGenData.getYearsRE()))) );
		vinVD.setColor(getStrValue(vehicleGenData.getColors()));
		UTF8String number = getStrValue(vehicleGenData.getNumbers());
		String str = number.getUTF8String();
		str = String.format(str, generateRandom(1000, 9999));		
		vinVD.setNumber(new UTF8String(str));
		return vinVD;
	}
	
	private Make getMakeValue(List<Make> makeList) throws BExceptions {		
		return (Make) getValue(makeList);
	}

	private UTF8String getStrValue(List<UTF8String> strList) throws BExceptions {		
		return (UTF8String) getValue(strList);
	}
	
	private Object getValue(List<?> list) throws BExceptions {
		int idx = generateRandom(0, list.size());
		Object val = list.get(idx);
		if(val == null) {
			throw new BExceptions(HVSProcessingCode.INVALID_VINS, "Index generation failed or data incorrect!");
		}
		
		return val;
	}
	
	private int generateRandom(int rs, int re) {
		IntStream is = rand.ints(1, rs, re);
		return is.findFirst().getAsInt();
	}
}
