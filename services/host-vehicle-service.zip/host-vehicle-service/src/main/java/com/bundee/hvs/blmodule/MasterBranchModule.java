package com.bundee.hvs.blmodule;

import com.bundee.hvs.db.MasterBranchDAO;
import com.bundee.hvs.defs.HVDefs;
import com.bundee.hvs.pojo.BranchRequest;
import com.bundee.hvs.pojo.MasterBranch;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.BaseResponse;
import com.bundee.msfw.defs.UniversalConstants;
import com.bundee.msfw.interfaces.blmodi.BLModServices;
import com.bundee.msfw.interfaces.blmodi.BLModule;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.endpoint.BEndpoint;
import com.bundee.msfw.interfaces.logi.BLogger;
import com.bundee.msfw.interfaces.reqrespi.RequestContext;

public class MasterBranchModule implements BLModule {

	@Override
	public void init(BLogger logger, BLModServices blModServices) throws BExceptions {

	}

	// Abhishek getAllfrom masterbranch and vehicle by id

	@BEndpoint(uri = HVDefs.Endpoints.GET_VEHICLE_MASTER_BY_ID, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = BranchRequest.class)
	public BaseResponse getVehicleBranchDetails(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
			BranchRequest branchrequest) throws BExceptions {
		VehiclesList vList = new VehiclesList();

		try {
			vList = MasterBranchDAO.getVehicleBranchDetails(logger, blModServices.getDBManager(), branchrequest.getId());
		} catch (DBException e) {
			VehiclesList bookResponse = new VehiclesList();
			bookResponse.setErrorCode("1");
			bookResponse.setErrorMessage("Error in Master Request");
			return bookResponse;
		}

		return vList;
	}
	@BEndpoint(uri = HVDefs.Endpoints.GET_ALL_MASTER_BRANCH, httpMethod = UniversalConstants.GET, permission = "")
	public BaseResponse getAllMasterBranch(BLogger logger, BLModServices blModServices, RequestContext reqCtx) throws BExceptions {
		VehiclesList vList = new VehiclesList();
		try {
			vList = MasterBranchDAO.getAllMasterBranch(logger, blModServices.getDBManager(),vList);
			return vList;
		} catch (DBException e) {
			vList.setErrorCode("1");
			vList.setErrorMessage("Error in Master Request");
			return vList;
		}

	}
	@BEndpoint(uri = HVDefs.Endpoints.GET_MASTER_BRANCH_BY_ID,  httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = MasterBranch.class)
	public BaseResponse getMasterBranchByID(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
											MasterBranch branchrequest) throws BExceptions {
		VehiclesList vList = new VehiclesList();
		try {
			vList = MasterBranchDAO.getMasterBranchByID(logger, blModServices.getDBManager(),vList,branchrequest.getIdBranch());
			return vList;
		} catch (DBException e) {
			vList.setErrorCode("1");
			vList.setErrorMessage("Error in Master Request");
			return vList;
		}

	}
	@BEndpoint(uri = HVDefs.Endpoints.INSERT_MASTER_BRANCH,  httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = MasterBranch.class)
	public BaseResponse insertIntoMasterBranch(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
											   MasterBranch branchrequest) throws BExceptions {
		VehiclesList vList = new VehiclesList();
		try {
			vList = MasterBranchDAO.insertMasterBranch(logger, blModServices.getDBManager(),vList,branchrequest);
			return vList;
		} catch (DBException e) {
			vList.setErrorCode("1");
			vList.setErrorMessage("Error in Master Request");
			return vList;
		}

	}
	@BEndpoint(uri = HVDefs.Endpoints.UPDATE_MASTER_BRANCH,  httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = MasterBranch.class)
	public BaseResponse updateMasterBranch(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
											   MasterBranch branchrequest) throws BExceptions {
		VehiclesList vList = new VehiclesList();
		try {
			vList = MasterBranchDAO.updateMasterBranch(logger, blModServices.getDBManager(),vList,branchrequest);
			return vList;
		} catch (DBException e) {
			vList.setErrorCode("1");
			vList.setErrorMessage("Error in Master Request");
			return vList;
		}

	}
}
