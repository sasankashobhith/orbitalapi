package com.bundee.hvs.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;


import com.bundee.hvs.pojo.VehicleType;
import com.bundee.msfw.defs.UTF8String;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.dbi.DBManager;
import com.bundee.msfw.interfaces.dbi.DBQuery;
import com.bundee.msfw.interfaces.dbi.DBQueryBuilder;
import com.bundee.msfw.interfaces.logi.BLogger;

public class VehicleTypeDAO {
	private static final String GET_TYPE="select * from master_vehicle_type where id=? and isactive=true";
	public static void listVehiclesByType(BLogger logger, DBManager dbm, int vehicleid, List<VehicleType> vehicles)
			throws DBException {
		if (dbm == null || vehicles == null)
			return;

		DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
		DBQuery sq = dbQB.setQueryString(GET_TYPE).setBindInputFunction((dbBLogger, ps) -> {
			ps.setInt(1, vehicleid);
		}).setFetchDataFunction((dbFLogger, rs) -> {
			vehicles.add(createvehiclefeatures(dbFLogger, rs));
		}).logQuery(true).throwOnNoData(false).build();

		dbm.select(logger, sq);
	}
	private static VehicleType createvehiclefeatures(BLogger logger, ResultSet rs) throws SQLException {
		VehicleType vtype = new VehicleType();
		vtype.setId(rs.getInt("id"));
		vtype.setName(new UTF8String(rs.getString("name")));
		
		return vtype;
	}
}
