package com.bundee.hvs.blmodule;

import com.bundee.hvs.db.*;
import com.bundee.hvs.defs.*;
import com.bundee.hvs.pojo.*;
import com.bundee.hvs.utils.*;
import com.bundee.msfw.defs.*;
import com.bundee.msfw.interfaces.blmodi.*;
import com.bundee.msfw.interfaces.dbi.*;
import com.bundee.msfw.interfaces.endpoint.*;
import com.bundee.msfw.interfaces.logi.*;
import com.bundee.msfw.interfaces.reqrespi.*;

import java.util.*;
import java.util.stream.*;

public class CustomerActivityModule implements BLModule {

    @Override
    public void init(BLogger logger, BLModServices blModServices) throws BExceptions {
    }

    @BEndpoint(uri = HVDefs.Endpoints.INSERT_CUTOMERACTIVITY, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = CustomerActivityResponse.class)
    public BaseResponse createCustomerActivity(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                               CustomerActivityResponse resObject) throws BExceptions {
        CustomerActivityResponse reservationCreateObj = CutomerActiveUtil.createSingleCustomer(resObject);
        VehiclesList bookResponse = new VehiclesList();
        try {
            bookResponse = CustomerActivityDAO.insertCustomerActivity(logger, blModServices.getDBManager(),
                    reservationCreateObj);
        } catch (DBException e) {
            e.printStackTrace();
        } catch (BExceptions e) {
            e.printStackTrace();
        }
        return bookResponse;
    }

    @BEndpoint(uri = HVDefs.Endpoints.GET_ALL_CUSTOMERACTIVITY, httpMethod = UniversalConstants.GET, permission = "")
    public BaseResponse getAllCustomerActivity(BLogger logger, BLModServices blModServices, RequestContext reqCtx) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = CustomerActivityDAO.geAllCustomerActivity(logger, blModServices.getDBManager(), vList);
            if (vList.getErrorCode().equals("0")) {
                if (vList.getCustomeractivityresponse().size() > 0) {
                    List<Integer> getVehicleList = vList.getCustomeractivityresponse().stream().map(e -> e.getVehicleid()).distinct().collect(Collectors.toList());
                    if (getVehicleList.size() > 0) {
                        VehiclesList vehicleimage = MasterVehicleImageDAO.geAllMasterVehicle(logger, blModServices.getDBManager(), getVehicleList.toString().replace("[", "").replace("]", ""));
                        for (int i = 0; i < vList.getCustomeractivityresponse().size(); i++) {
                            int vehicleId = vList.getCustomeractivityresponse().get(i).getVehicleid();
                            List<MasterVehicleImageResponse> vehicleImageData = vehicleimage.getImageresponse().stream().filter(item -> item.getVehicleid() == vehicleId)
                                    .collect(Collectors.toList());
                            vList.getCustomeractivityresponse().get(i).setImageresponse(vehicleImageData);
                        }
                    }
                }
            }
            return vList;
        } catch (DBException e) {
            vList.setErrorCode("1");
            vList.setErrorMessage("Error in CustomerActivity Request");
            return vList;
        }
    }

    @BEndpoint(uri = HVDefs.Endpoints.GET_ALL_CUSTOMERACTIVITY_BY, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = CustomerActivityRequest.class)
    public BaseResponse get(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                            CustomerActivityRequest requestObject) throws BExceptions {
        VehiclesList vList = new VehiclesList();
        try {
            vList = CustomerActivityDAO.getCustomerActivityresponsebyid(logger, blModServices.getDBManager()
                    , requestObject, vList.getCustomeractivityresponse());
            if (vList.getErrorCode().equals("0")) {
                if (vList.getCustomeractivityresponse().size() > 0) {
                    List<Integer> getVehicleList = vList.getCustomeractivityresponse().stream().map(e -> e.getVehicleid()).distinct().collect(Collectors.toList());
                    if (getVehicleList.size() > 0) {
                        VehiclesList vehicleimage = MasterVehicleImageDAO.geAllMasterVehicle(logger, blModServices.getDBManager(), getVehicleList.toString().replace("[", "").replace("]", ""));
                        VehiclesList vehicleDetails = CustomerActivityDAO.getVehicleDetail(logger, blModServices.getDBManager(), getVehicleList);
                        VehiclesList reviewDetails = CutomerActiveUtil.getVehicleDetails( getVehicleList.stream().map(Object::toString).collect(Collectors.joining(", ")));
                        for (int i = 0; i < vList.getCustomeractivityresponse().size(); i++) {
                            int vehicleId = vList.getCustomeractivityresponse().get(i).getVehicleid();
                            List<MasterVehicleImageResponse> vehicleImageData = vehicleimage.getImageresponse().stream().filter(item -> item.getVehicleid() == vehicleId)
                                    .collect(Collectors.toList());
                            List<CustomerActivityResponse> vehicleDetail = vehicleDetails.getCustomeractivityresponse().stream().filter(item -> item.getVehicleid() == vehicleId)
                                    .toList();
                            List<Reservation> reviewDetail = reviewDetails.getReserverList().stream().filter(item -> item.getVehicleid() == vehicleId)
                                    .toList();
                            vList.getCustomeractivityresponse().get(i).setImageresponse(vehicleImageData);
                            vList.getCustomeractivityresponse().get(i).setMake(vehicleDetail.get(0).getMake());
                            vList.getCustomeractivityresponse().get(i).setModel(vehicleDetail.get(0).getModel());
                            vList.getCustomeractivityresponse().get(i).setVehiclePrice(vehicleDetail.get(0).getVehiclePrice());
                            vList.getCustomeractivityresponse().get(i).setYear(vehicleDetail.get(0).getYear());
                            if(!reviewDetail.isEmpty()) {
                                vList.getCustomeractivityresponse().get(i).setReview(reviewDetail.get(0).getRating());
                                vList.getCustomeractivityresponse().get(i).setTripCount(reviewDetail.get(0).getTripcount());
                            }
                        }
                    }
                }
            }
        } catch (DBException e) {
            VehiclesList bookResponse = new VehiclesList();
            bookResponse.setErrorCode("1");
            bookResponse.setErrorMessage("Error in Customer Request");
            return bookResponse;
        }
        return vList;
    }

    @BEndpoint(uri = HVDefs.Endpoints.UPDATE_CUTOMERACTIVITY, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = CustomerActivityResponse.class)
    public BaseResponse updateCustomerActivity(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                               CustomerActivityResponse resObject) throws BExceptions {
        CustomerActivityResponse reservationCreateObj = CutomerActiveUtil.createSingleCustomer(resObject);
        VehiclesList bookResponse = new VehiclesList();
        try {
            bookResponse = CustomerActivityDAO.updateCustomerActivity(logger, blModServices.getDBManager(),
                    reservationCreateObj);
        } catch (Exception e) {
            bookResponse.setErrorMessage("Error with the details given-" + e.getMessage());
            bookResponse.setErrorCode("1");
            return bookResponse;
        }
        return bookResponse;
    }

    @BEndpoint(uri = HVDefs.Endpoints.SOFT_UPDATE_CUTOMERACTIVITY, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = CustomerActivityResponse.class)
    public BaseResponse softUpdateCustomerActivity(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
                                                   CustomerActivityResponse resObject) throws BExceptions {
        VehiclesList bookResponse = new VehiclesList();
        try {
            bookResponse = CustomerActivityDAO.softUpdateCustomerActivity(logger, blModServices.getDBManager(),
                    resObject);
        } catch (Exception e) {
            bookResponse.setErrorMessage("Error with the details given-" + e.getMessage());
            bookResponse.setErrorCode("1");
            return bookResponse;
        }
        return bookResponse;
    }
}
