package com.bundee.hvs.pojo;

import com.bundee.msfw.defs.UTF8String;

import java.sql.Timestamp;

public class VehicleHostDetail {
    private int id;
    private int typeID;
    private int hostID;
    private String firstname;
    private String middlename;
    private String lastname;
    private UTF8String vin;
    private UTF8String make;
    private UTF8String model;
    private UTF8String desc;
    private UTF8String year;
    private UTF8String number;
    private UTF8String color;
    private boolean bActive;
    private long createTS;
    private long updateTS;
    String createddate;

    public String getCreateddate() {
        return createddate;
    }

    public void setCreateddate(String createddate) {
        this.createddate = createddate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTypeID() {
        return typeID;
    }

    public void setTypeID(int typeID) {
        this.typeID = typeID;
    }

    public int getHostID() {
        return hostID;
    }

    public void setHostID(int hostID) {
        this.hostID = hostID;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getMiddlename() {
        return middlename;
    }

    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public UTF8String getVin() {
        return vin;
    }

    public void setVin(UTF8String vin) {
        this.vin = vin;
    }

    public UTF8String getMake() {
        return make;
    }

    public void setMake(UTF8String make) {
        this.make = make;
    }

    public UTF8String getModel() {
        return model;
    }

    public void setModel(UTF8String model) {
        this.model = model;
    }

    public UTF8String getDesc() {
        return desc;
    }

    public void setDesc(UTF8String desc) {
        this.desc = desc;
    }

    public UTF8String getYear() {
        return year;
    }

    public void setYear(UTF8String year) {
        this.year = year;
    }

    public UTF8String getNumber() {
        return number;
    }

    public void setNumber(UTF8String number) {
        this.number = number;
    }

    public UTF8String getColor() {
        return color;
    }

    public void setColor(UTF8String color) {
        this.color = color;
    }

    public boolean isbActive() {
        return bActive;
    }

    public void setbActive(boolean bActive) {
        this.bActive = bActive;
    }

    public long getCreateTS() {
        return createTS;
    }

    public void setCreateTS(long createTS) {
        this.createTS = createTS;
    }

    public long getUpdateTS() {
        return updateTS;
    }

    public void setUpdateTS(long updateTS) {
        this.updateTS = updateTS;
    }

    public VehicleHostDetail(Vehicle vehicle, UserResponse userResponse) {
        this.id = vehicle.getID();
        this.typeID = vehicle.getTypeID();
        this.hostID = vehicle.getHostID();
        this.firstname = userResponse.getFirstname();
        this.middlename = userResponse.getMiddlename();
        this.lastname = userResponse.getLastname();
        this.createddate=userResponse.getCreateddate();
        this.vin = vehicle.getVIN();
        this.make = vehicle.getMake();
        this.model = vehicle.getModel();
        this.desc = vehicle.getDesc();
        this.year = vehicle.getYear();
        this.number = vehicle.getNumber();
        this.color = vehicle.getColor();
        this.bActive = vehicle.isActive();
        this.createTS = vehicle.getCreateTS();
        this.updateTS = vehicle.getUpdateTS();
    }
}
