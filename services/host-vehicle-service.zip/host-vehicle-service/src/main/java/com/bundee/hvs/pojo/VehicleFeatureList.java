package com.bundee.hvs.pojo;

import java.util.ArrayList;
import java.util.List;

import com.bundee.msfw.defs.BaseResponse;

public class VehicleFeatureList extends BaseResponse{
	List<VehicleFeature> vehiclefeatures;

	public List<VehicleFeature> getVehiclefeatures() {
		return vehiclefeatures;
	}

	public void setVehiclefeatures(List<VehicleFeature> vehiclefeatures) {
		this.vehiclefeatures = vehiclefeatures;
	}
	
	public VehicleFeatureList()
	{
		vehiclefeatures=new ArrayList<VehicleFeature>();
		
	}
	
	
	}
	