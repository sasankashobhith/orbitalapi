package com.bundee.hvs.pojo;

import com.bundee.msfw.defs.*;

public class VinImages {

    private UTF8String VIN ;
    private UTF8String IMAGEPATH ;

    public UTF8String getVIN() {
        return VIN;
    }

    public void setVIN(UTF8String VIN) {
        this.VIN = VIN;
    }

    public UTF8String getIMAGEPATH() {
        return IMAGEPATH;
    }

    public void setIMAGEPATH(UTF8String IMAGEPATH) {
        this.IMAGEPATH = IMAGEPATH;
    }
}