package com.bundee.hvs.blmodule;


import com.bundee.hvs.db.VehicleUnavailabilityDAO;
import com.bundee.hvs.defs.HVDefs;
import com.bundee.hvs.defs.HVSProcessingCode;

import com.bundee.hvs.pojo.*;
import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.BaseResponse;
import com.bundee.msfw.defs.UniversalConstants;
import com.bundee.msfw.interfaces.blmodi.BLModServices;
import com.bundee.msfw.interfaces.blmodi.BLModule;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.endpoint.BEndpoint;
import com.bundee.msfw.interfaces.logi.BLogger;
import com.bundee.msfw.interfaces.reqrespi.RequestContext;

public class VehicleUnavailabilityModule implements BLModule {
	
	@Override
	public void init(BLogger logger, BLModServices blModServices) throws BExceptions {
		
	}
	 
	@BEndpoint(uri = HVDefs.Endpoints.GET_UNAVAILABILITY, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = BranchRequest.class)
	public BaseResponse listVehiclesByID(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
			BranchRequest requestObject) throws BExceptions {
		VehiclesList vList = new VehiclesList();

		try {
			vList=VehicleUnavailabilityDAO.listVehiclesByID(logger, blModServices.getDBManager(), requestObject);
		} catch (DBException e) {
			vList.setErrorMessage("Error retrieving details - "+e.getMessage());
			vList.setErrorCode("1");
			return vList;
		}
				
		return vList;
	}
	@BEndpoint(uri = HVDefs.Endpoints.GET_ALL_UNAVAILABILITY, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleID.class)
	public BaseResponse listAllUnavailability(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
										 VehicleID requestObject) throws BExceptions {
		VehiclesList vList = new VehiclesList();

		try {
			vList=VehicleUnavailabilityDAO.listAllVehicleUnavailability(logger, blModServices.getDBManager());
		} catch (DBException e) {
			vList.setErrorMessage("Error retrieving details - "+e.getMessage());
			vList.setErrorCode("1");
			return vList;
		}

		return vList;
	}
	@BEndpoint(uri = HVDefs.Endpoints.INSERT_UNAVAILABILITY, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleUnavailability.class)
	public BaseResponse insertUnavailability(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
										 VehicleUnavailability requestObject) throws BExceptions {
		VehiclesList vList = new VehiclesList();

		try {
			vList=VehicleUnavailabilityDAO.insertVehicleUnavailability(logger, blModServices.getDBManager(), requestObject);
		} catch (DBException e) {
			vList.setErrorMessage("Error inserting details - "+e.getMessage());
			vList.setErrorCode("1");
			return vList;
		}

		return vList;
	}
	@BEndpoint(uri = HVDefs.Endpoints.UPDATE_UNAVAILABILITY, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleUnavailability.class)
	public BaseResponse updateUnavailability(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
											 VehicleUnavailability requestObject) throws BExceptions {
		VehiclesList vList = new VehiclesList();

		try {
			vList=VehicleUnavailabilityDAO.updateVehicleUnavailability(logger, blModServices.getDBManager(), requestObject);
		} catch (DBException e) {
			vList.setErrorMessage("Error updating details - "+e.getMessage());
			vList.setErrorCode("1");
			return vList;
		}

		return vList;
	}
}
