package com.bundee.hvs.utils;

import com.bundee.hvs.defs.*;
import com.bundee.hvs.pojo.*;
import com.bundee.msfw.defs.BExceptions;
import com.google.gson.*;
import org.json.*;
import org.springframework.http.*;
import org.springframework.web.client.*;

import java.util.*;

public class CutomerActiveUtil {

	public static CustomerActivityResponse createSingleCustomer(CustomerActivityResponse row) throws BExceptions {
		CustomerActivityResponse res = new CustomerActivityResponse();

		res.setId(row.getId());
		res.setUserid(row.getUserid());
		res.setVehicleid(row.getVehicleid());
		res.setIsactive(row.getisactive());
		res.setStartdate(row.getStartdate());
		res.setEnddate(row.getEnddate());
		res.setLattitude(row.getLattitude());
		res.setLongitude(row.getLongitude());

		return res;

	}
	public static VehiclesList getVehicleDetails(String userId) {
		VehiclesList bookingObjResponse=new VehiclesList();
		try {
			RestTemplate restTemplate = new RestTemplate();
			String checkBookingUrl = HostVehicleRestURIs.Endpoints.GET_VEHICLE_REVIEW;

			JSONObject jsonObject = new JSONObject();
			jsonObject.put("fromValue", userId);

			String jsonString = jsonObject.toString();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> entity = new HttpEntity<String>(jsonString, headers);
			ResponseEntity<String> resultBookingList = restTemplate.exchange(checkBookingUrl, HttpMethod.POST,
					entity, String.class);

			String responseBookingBody = resultBookingList.getBody();
			Gson gson = new Gson();
			 bookingObjResponse = gson.fromJson(responseBookingBody, VehiclesList.class);
			return bookingObjResponse;
		} catch (Exception e) {
			bookingObjResponse.setErrorCode("1");
			bookingObjResponse.setErrorMessage("Not able to retrieve detail");
			return bookingObjResponse;
		}
	}
}
