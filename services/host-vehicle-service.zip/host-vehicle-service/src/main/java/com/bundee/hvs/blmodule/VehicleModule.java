package com.bundee.hvs.blmodule;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bundee.hvs.db.VehicleDAO;
import com.bundee.hvs.defs.HVDefs;
import com.bundee.hvs.defs.HVSProcessingCode;
import com.bundee.hvs.ext.vin.data.client.def.VINVehicleData;
import com.bundee.hvs.ext.vin.data.client.local.VinDataLocalClient;
import com.bundee.hvs.pojo.*;
import com.bundee.hvs.utils.Util;
import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.BaseResponse;
import com.bundee.msfw.defs.UTF8String;
import com.bundee.msfw.defs.UniversalConstants;
import com.bundee.msfw.interfaces.blmodi.BLModServices;
import com.bundee.msfw.interfaces.blmodi.BLModule;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.endpoint.BEndpoint;
import com.bundee.msfw.interfaces.logi.BLogger;
import com.bundee.msfw.interfaces.reqrespi.RequestContext;
import com.bundee.msfw.interfaces.utili.csv.BCSVReader;
import com.bundee.msfw.interfaces.utili.csv.Row;

public class VehicleModule implements BLModule {
	VinDataLocalClient vindClient = null;
	
	@Override
	public void init(BLogger logger, BLModServices blModServices) throws BExceptions {
		vindClient = new VinDataLocalClient();
		vindClient.init(logger, blModServices);
	}

	@BEndpoint(uri = HVDefs.Endpoints.UPLOAD_VEHICLES, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = UploadedFile.class)
	public BaseResponse createVehicles(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
			UploadedFile requestObject) throws BExceptions {
		VehiclesList vList = new VehiclesList();

		UploadedFile.validate(requestObject);
		
		logger.debug(requestObject.getFileName() + " with length " + requestObject.getB64Contents().getUTF8String().length());
		
		byte[] decBytes = blModServices.getUtilFactory().getNewCryptoService().base64Decode(requestObject.getB64Contents().getUTF8String());
		UTF8String utfStr = new UTF8String(new String(decBytes));
		StringReader sr = new StringReader(utfStr.getUTF8String()); 
		BCSVReader csvReader = blModServices.getUtilFactory().getNewLargeCSVReader(sr, ',', 1);
		List<Vehicle> vehicles = new ArrayList<Vehicle>();
		
		while(true) {
			Row row = csvReader.getNextRow(logger);
			if(row == null) {
				break;
			}
			Vehicle v = Util.createVehicle(row);
			vehicles.add(v);
		}
		
		try {
			vList=VehicleDAO.insertVehiclesCSV(logger, blModServices.getDBManager(), vehicles);
		} catch (DBException e) {
			throw new BExceptions(e, HVSProcessingCode.DUPLICATE_VEHICLES);
		}
		return vList;
	}
	
	@BEndpoint(uri = HVDefs.Endpoints.LIST_VEHICLES_BY_HOST, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleDetailID.class)
	public BaseResponse listVehicles(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
									 VehicleDetailID requestObject) throws BExceptions {
		VehiclesList vList = new VehiclesList(); 

		try {
			vList=VehicleDAO.listVehiclesByHostID(logger, blModServices.getDBManager(), requestObject.getId(), vList.getVehicles());
		} catch (DBException e) {
			throw new BExceptions(e, HVSProcessingCode.VEHICLES_NOT_FOUND);
		}

		return vList;
	}

	@BEndpoint(uri = HVDefs.Endpoints.UPLOAD_VINS, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = UploadedFile.class)
	public BaseResponse createVINs(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
			UploadedFile requestObject) throws BExceptions {
		UploadedFile.validate(requestObject);
		
		logger.debug(requestObject.getFileName() + " with length " + requestObject.getB64Contents().getUTF8String().length());
		
		byte[] decBytes = blModServices.getUtilFactory().getNewCryptoService().base64Decode(requestObject.getB64Contents().getUTF8String());
		UTF8String utfStr = new UTF8String(new String(decBytes));
		StringReader sr = new StringReader(utfStr.getUTF8String()); 
		BCSVReader csvReader = blModServices.getUtilFactory().getNewLargeCSVReader(sr, ',', 1);
		Map<UTF8String, Double> vinsMap = new HashMap<UTF8String, Double>();
		
		while(true) {
			Row row = csvReader.getNextRow(logger);
			if(row == null) {
				break;
			}
			Util.createVINs(row, vinsMap);
		}
		
		getAndInsertVINData(logger, blModServices, vinsMap);
		return null;
	}
	
	@BEndpoint(uri = HVDefs.Endpoints.GEN_VINS, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VINDataGenInput.class)
	public BaseResponse generateVINs(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
			VINDataGenInput requestObject) throws BExceptions {
		Map<UTF8String, Double> vinsMap = new HashMap<UTF8String, Double>();
		
		for(int idx = 0; idx < requestObject.numVINs; idx++) {
			int vindx = requestObject.startVIN + idx;
			UTF8String vin = new UTF8String(String.format("VIN-%06d", vindx));
			vinsMap.put(vin, 2.3);
		}
		getAndInsertVINData(logger, blModServices, vinsMap);
		return null;
	}
	
	private void getAndInsertVINData(BLogger logger, BLModServices blModServices, Map<UTF8String, Double> vinsMap) throws BExceptions {
		Map<UTF8String, VINVehicleData> vehicleMap = vindClient.getVINDetails(logger, vinsMap.keySet());
		try {
			VehicleDAO.insertVehicles(logger, blModServices.getDBManager(), vehicleMap.values());
		} catch (DBException e) {
			throw new BExceptions(e, HVSProcessingCode.DUPLICATE_VEHICLES);
		}

	}
	@BEndpoint(uri = HVDefs.Endpoints.VEHICLE_DETAIL_BY_ID, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleDetailID.class)
	public BaseResponse listVehicleById(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
										VehicleDetailID requestObject) throws BExceptions {
		VehiclesList vList = new VehiclesList();
		List<Vehicle> vehicles = new ArrayList<Vehicle>();

		try {
			vList=VehicleDAO.listVehiclesByID(logger, blModServices.getDBManager(), requestObject.getId(), vehicles);
		} catch (DBException e) {
			vList.setErrorCode("1");
			vList.setErrorMessage("Error in catch block" + e.getMessage().toString());
			return vList;
		}
		List<UserResponse> hosts=new ArrayList<UserResponse>();
		try {
			if(vList.getErrorCode().equals("1")){
				return vList;
			}else{
				Integer result = Util.getHostDetails(vehicles.get(0).getHostID(),hosts);
			if(result== 0){
				vList.setErrorCode("1");
				vList.setErrorMessage("Error in retriving Host Data");
				return vList;
			}else{
				vList.setErrorCode("0");
				vList.setErrorMessage("Data Retreived Successfully...");
				vList.getVehicleHostDetails().add(new VehicleHostDetail(vehicles.get(0),hosts.get(0)));
				vList.setVehicles(null);
				return vList;
			}

			}

		}
		catch (Exception e) {
			vList.setErrorCode("1");
			vList.setErrorMessage("Error in catch block" + e.getMessage().toString());
			return vList;
		}

	}
	@BEndpoint(uri = HVDefs.Endpoints.VEHICLE_BY_ID, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleDetailID.class)
	public BaseResponse vehicleById(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
										VehicleDetailID requestObject) throws BExceptions {
		VehiclesList vList = new VehiclesList();
		List<Vehicle> vehicles = new ArrayList<Vehicle>();

		try {
			vList=VehicleDAO.listVehiclesByID(logger, blModServices.getDBManager(), requestObject.getId(), vehicles);
			return vList;
		} catch (DBException e) {
			vList.setErrorCode("1");
			vList.setErrorMessage("Error in catch block" + e.getMessage().toString());
			return vList;
		}
	}
	@BEndpoint(uri = HVDefs.Endpoints.INSERT_MASTER_VEHICLE, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = Vehicle.class)
	public BaseResponse insertVehicle(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
									Vehicle requestObject) throws BExceptions {
		VehiclesList vList = new VehiclesList();
		try {
			vList=VehicleDAO.insertMasterVehicle(logger, blModServices.getDBManager(), requestObject);
			return vList;
		} catch (DBException e) {
			vList.setErrorCode("1");
			vList.setErrorMessage("Error in catch block" + e.getMessage().toString());
			return vList;
		}
	}
	@BEndpoint(uri = HVDefs.Endpoints.GET_ALL_VEHICLES, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = VehicleDetailID.class)
	public BaseResponse getAllVehicles(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
									VehicleDetailID requestObject) throws BExceptions {
		VehiclesList vList = new VehiclesList();
		List<Vehicle> vehicles = new ArrayList<Vehicle>();

		try {
			vList=VehicleDAO.listVehicles(logger, blModServices.getDBManager(), vehicles);
			return vList;
		} catch (DBException e) {
			vList.setErrorCode("1");
			vList.setErrorMessage("Error in catch block" + e.getMessage().toString());
			return vList;
		}
	}
	@BEndpoint(uri = HVDefs.Endpoints.UPDATE_VEHICLE, httpMethod = UniversalConstants.POST, permission = "", reqDTOClass = Vehicle.class)
	public BaseResponse updateVehicle(BLogger logger, BLModServices blModServices, RequestContext reqCtx,
									  Vehicle requestObject) throws BExceptions {
		VehiclesList vList = new VehiclesList();
		try {
			vList=VehicleDAO.updateVehicle(logger, blModServices.getDBManager(), requestObject);
			return vList;
		} catch (DBException e) {
			vList.setErrorCode("1");
			vList.setErrorMessage("Error in catch block" + e.getMessage().toString());
			return vList;
		}
	}
}
