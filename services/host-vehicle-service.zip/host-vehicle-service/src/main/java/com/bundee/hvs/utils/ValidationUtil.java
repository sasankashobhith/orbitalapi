package com.bundee.hvs.utils;

import com.bundee.hvs.pojo.MasterBranch;
import com.bundee.hvs.pojo.Vehicle;
import com.bundee.hvs.pojo.VehicleUnavailability;
import com.bundee.hvs.pojo.VehiclesList;

public class ValidationUtil {
    public VehiclesList validateMasterBranch(MasterBranch masterBranch){
        VehiclesList vehiclesList=new VehiclesList();
        if(masterBranch.getCityName()==null||masterBranch.getZipCode()==null||masterBranch.getAddress1()==null||masterBranch.getState()==null||masterBranch.getLatitude()==null||masterBranch.getLongitude()==null||masterBranch.getUserid()==0) {
            vehiclesList.setErrorMessage("Error one of the details is missing ");
            vehiclesList.setErrorCode("1");
        }
        else {
            vehiclesList.setErrorMessage("Validation Successful");
            vehiclesList.setErrorCode("0");
        }
        return vehiclesList;
    }
    public VehiclesList validateMasterVehicle(Vehicle vehicle){
        VehiclesList vehiclesList=new VehiclesList();
        if(vehicle.getTypeID()==0||vehicle.getHostID()==0||vehicle.getBranchID()==0||vehicle.getVIN()==null||vehicle.getMake()==null||vehicle.getModel()==null||vehicle.getDesc()==null||vehicle.getYear()==null||vehicle.getNumber()==null||vehicle.getColor()==null||vehicle.getVehicleLatitude()==null||vehicle.getVehicleLongitude()==null) {
            vehiclesList.setErrorMessage("Error one of the details is missing ");
            vehiclesList.setErrorCode("1");
        }
        else {
            vehiclesList.setErrorMessage("Validation Successful");
            vehiclesList.setErrorCode("0");
        }
        return vehiclesList;
    }
    public VehiclesList validateVehicleUnavailability(VehicleUnavailability vehicle){
        VehiclesList vehiclesList=new VehiclesList();
        if(vehicle.getStartdate()==null||vehicle.getEnddate()==null)
        {
            vehiclesList.setErrorMessage("Error one of the details is missing ");
            vehiclesList.setErrorCode("1");
        }
        else {
            vehiclesList.setErrorMessage("Validation Successful");
            vehiclesList.setErrorCode("0");
        }
        return vehiclesList;
    }
}
