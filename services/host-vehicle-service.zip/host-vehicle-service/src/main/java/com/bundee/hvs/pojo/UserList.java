package com.bundee.hvs.pojo;

import com.bundee.msfw.defs.BaseResponse;

import java.util.ArrayList;
import java.util.List;

public class UserList extends BaseResponse {
    private String errorCode;
    private String errorMessage;
    UserResponse userResponse;
    List<User> userdetail;
    private int count;


    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public int getCount() {
        return count;
    }
    public UserResponse getUserResponse() {
        return userResponse;
    }

    public void setUserResponse(UserResponse userResponse) {
        this.userResponse = userResponse;
    }


    public void setCount(int count) {
        this.count = count;
    }

    public UserList() {
        userdetail = new ArrayList<User>();
    }

    public List<User> getUserdetail() {
        return userdetail;
    }

    public void setUserdetail(List<User> userdetail) {
        this.userdetail = userdetail;
    }


}
