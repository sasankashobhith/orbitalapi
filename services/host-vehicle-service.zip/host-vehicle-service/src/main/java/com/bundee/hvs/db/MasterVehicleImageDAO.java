package com.bundee.hvs.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.bundee.hvs.pojo.MasterVehicleImageResponse;
import com.bundee.hvs.pojo.VehicleFeature;
import com.bundee.hvs.pojo.VehicleID;
import com.bundee.hvs.pojo.VehiclesList;
import com.bundee.msfw.defs.UTF8String;
import com.bundee.msfw.interfaces.dbi.DBException;
import com.bundee.msfw.interfaces.dbi.DBManager;
import com.bundee.msfw.interfaces.dbi.DBQuery;
import com.bundee.msfw.interfaces.dbi.DBQueryBuilder;
import com.bundee.msfw.interfaces.logi.BLogger;

public class MasterVehicleImageDAO {
	
	private static final String GET_ALL= "select * from mastervehicleimage where isactive=true";
	
	private static final String GET_ALL_BY_IMAGEID="select * from mastervehicleimage where idimage=? and isactive=true";
	private static final String GET_ALL_BY_VEHICLEID="select * from mastervehicleimage where vehicleid=? and isactive=true";
	private static final String GET_ALL_BY_USERID="select * from mastervehicleimage where userid=? and isactive=true";
	
	private static final String INSERT_IAMGE_DETAILS="insert into mastervehicleimage (vehicleid, imagename, userid,isactive) values (?, ?, ?,true)";
	
	private static final String UPDATE_IMAGE_IMAGENAME_UPDATEDTIME="UPDATE mastervehicleimage SET imagename=?,updateddate=? WHERE idimage=?";
	private static final String UPDATE_IMAGE_ISACTIVE_UPDATEDTIME="UPDATE mastervehicleimage SET isactive=?,updateddate=? WHERE idimage=?";
	
	
	
	public static VehiclesList geAllMasterVehicle(BLogger logger, DBManager dbm,String vehicleids)

            throws DBException {
		VehiclesList vehiclesList = new VehiclesList();
        try {

         String GET_ALL_BY_AllVEHICLEID="select * from mastervehicleimage where vehicleid IN (&in)";
        	
        	String csvId = vehicleids.replaceAll("^|$", "'").replaceAll(",", "','").replaceAll("\"", "'");
   		 String repSearcStr = GET_ALL_BY_AllVEHICLEID.replace("&in", csvId);
   		 
   		 
            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(repSearcStr).setBindInputFunction((dbBLogger, ps) -> {
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getImageresponse().add(getAllResponse(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data retrieved successfully");
            return vehiclesList;

        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving all CustomerActivity details - " + e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }

    }
	
	
	public static VehiclesList geAllMasterVehicleImage(BLogger logger, DBManager dbm, VehiclesList vehiclesList)

            throws DBException {

        try {

            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
            DBQuery sq = dbQB.setQueryString(GET_ALL).setBindInputFunction((dbBLogger, ps) -> {
            }).setFetchDataFunction((dbFLogger, rs) -> {
                vehiclesList.getImageresponse().add(getAllResponse(dbFLogger, rs));
            }).logQuery(true).throwOnNoData(false).build();
            dbm.select(logger, sq);
            vehiclesList.setErrorCode("0");
            vehiclesList.setErrorMessage("Data retrieved successfully");
            return vehiclesList;

        } catch (Exception e) {
            vehiclesList.setErrorMessage("Error retrieving all CustomerActivity details - " + e.getMessage());
            vehiclesList.setErrorCode("1");
            return vehiclesList;
        }

    }

			
			public static VehiclesList getImageById(BLogger logger, DBManager dbm,
					VehicleID resObject) throws DBException {
		        VehiclesList imagedetaillist = new VehiclesList();
		        List<MasterVehicleImageResponse> imageresponse = new ArrayList<MasterVehicleImageResponse>();
		        if (dbm == null || resObject == null || resObject.getFromvalue() == null || resObject.getId() == 0) {
		        	imagedetaillist.setErrorCode("1");
		        	imagedetaillist.setErrorMessage("Invalid Input Request");
		            return imagedetaillist;
		        }
		        try {
		            String queryString = "NA";	 
		            if (resObject.getFromvalue().toLowerCase().equals("idimage")) {
		                queryString = GET_ALL_BY_IMAGEID;
		            } else if (resObject.getFromvalue().toLowerCase().equals("userid")) {
		                queryString = GET_ALL_BY_USERID;
		            } else if (resObject.getFromvalue().toLowerCase().equals("vehicleid")) {
		                queryString = GET_ALL_BY_VEHICLEID;
		            } else {
		            	imagedetaillist.setErrorCode("1");
		            	imagedetaillist.setErrorMessage("Invalid Input Request");
		                return imagedetaillist;
		            }
		            if (queryString.equals("NA")) {
		            	imagedetaillist.setErrorCode("1");
		            	imagedetaillist.setErrorMessage("Invalid Input Request");
		               return imagedetaillist;

		            }
		            DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
		            DBQuery sq = dbQB.setQueryString(queryString).setBindInputFunction((dbLogger, ps) -> {
		                if (resObject.getFromvalue().toLowerCase().equals("idimage")){
		                	  ps.setInt(1, resObject.getId());
		                } 
		                else if (resObject.getFromvalue().toLowerCase().equals("vehicleid")) {
		                    ps.setInt(1, resObject.getId());
		                }
		                else if (resObject.getFromvalue().toLowerCase().equals("userid")) {
		                    ps.setInt(1, resObject.getId());
		                }
		            }).setFetchDataFunction((dbFLogger, rs) -> {
		            	imageresponse.add(getAllResponse(dbFLogger, rs));
		            }).logQuery(true).throwOnNoData(false).build();
		            dbm.select(logger, sq);
		            imagedetaillist.setErrorCode("0");
		            imagedetaillist.setErrorMessage("Data retrieved Succesfully");
		            imagedetaillist.setImageresponse(imageresponse);
		            return imagedetaillist;
		        } catch (Exception e) {
		        	imagedetaillist.setErrorCode("1");
		        	imagedetaillist.setErrorMessage("Error in Image Request exception" + e.getMessage());
		            return imagedetaillist;
		        }
		    }
			
			
			public static VehiclesList insertImageDetails(BLogger logger, DBManager dbm, MasterVehicleImageResponse resobj)
					throws DBException {
				VehiclesList imagedetails = new VehiclesList();
				List<MasterVehicleImageResponse> imageresponse = new ArrayList<MasterVehicleImageResponse>();
				try {
					if (dbm == null || resobj == null||resobj.getVehicleid()==0||resobj.getImagename()==null||resobj.getUserid()==0) {
						imagedetails.setErrorCode("1");
						imagedetails.setErrorMessage("Error in Reservaton Request");
						return imagedetails;
					} else {
						DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
						DBQuery sq = dbQB.setBatch().setQueryString(INSERT_IAMGE_DETAILS)
								.setBindInputFunction((dbLogger, ps) -> {
									
									ps.setInt(1, resobj.getVehicleid());							
									ps.setString(2, resobj.getImagename());
									ps.setInt(3, resobj.getUserid());		
								
									ps.addBatch();

								}).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
									imagedetails.getImageresponse().add(MasterVehicleImageDAO.getAllResponse(dbFLogger,rs));
								}).logQuery(true).build();
						dbm.update(logger, sq);
						imagedetails.setErrorCode("0");
						imagedetails.setErrorMessage("Successfully Reservation Completed");
						return imagedetails;

					}
				} catch (DBException e) {
					// TODO Auto-generated catch block
					imagedetails.setErrorCode("1");
					imagedetails.setErrorMessage("Error in Reservation " + e.getMessage().toString());
					return imagedetails;
				}
			}
			
			public static VehiclesList updateImageDetails(BLogger logger, DBManager dbm, MasterVehicleImageResponse resobj) {
				
				VehiclesList imagedetails = new VehiclesList();
				List<MasterVehicleImageResponse> imageresponse = new ArrayList<MasterVehicleImageResponse>();
				if (dbm == null || resobj == null||resobj.getIdimage()==0) {
					imagedetails.setErrorCode("1");
					imagedetails.setErrorMessage("Error in Update Image Request");
					return imagedetails;
				} else {
					
					Date updateDate = new Date();
					java.sql.Date sqlupdateDate = new java.sql.Date(updateDate.getTime());
					java.sql.Timestamp sqlupdateDateTime = new java.sql.Timestamp(sqlupdateDate.getTime());
					
					try {
						if (resobj.getImagename() != null ) {
							
							DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
							DBQuery sq = dbQB.setBatch().setQueryString(UPDATE_IMAGE_IMAGENAME_UPDATEDTIME)
									.setBindInputFunction((dbLogger, ps) -> {

										ps.setString(1, resobj.getImagename());
										ps.setTimestamp(2, sqlupdateDateTime);
										ps.setInt(3, resobj.getIdimage());
										ps.addBatch();
										
									}).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
										imagedetails.getImageresponse().add(MasterVehicleImageDAO.getAllResponse(dbFLogger,rs));
									}).logQuery(true).throwOnNoData(false).build();
							dbm.update(logger, sq);
							
							imagedetails.setErrorCode("0");
							imagedetails.setErrorMessage("Successfully UPDATED");
							return imagedetails;
							
							}else {														
								DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
								DBQuery sq = dbQB.setBatch().setQueryString(UPDATE_IMAGE_ISACTIVE_UPDATEDTIME)
										.setBindInputFunction((dbLogger, ps) -> {

											ps.setBoolean(1, resobj.getIsactive());
											ps.setTimestamp(2, sqlupdateDateTime);
											ps.setInt(3, resobj.getIdimage());
										    ps.addBatch();
											
										}).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
											imagedetails.getImageresponse().add(MasterVehicleImageDAO.getAllResponse(dbFLogger,rs));
										}).logQuery(true).throwOnNoData(false).build();
								
								
								dbm.update(logger, sq);
							
						imagedetails.setErrorCode("0");
						imagedetails.setErrorMessage("Successfully UPDATED");
							return imagedetails;
							
					} 
					} catch (Exception e) {
						imagedetails.setErrorCode("1");
						imagedetails.setErrorMessage("Invalid Date format " + e.getMessage().toString());
						return imagedetails;
					}

				}

			}

	private static MasterVehicleImageResponse getAllResponse(BLogger logger, ResultSet rs) throws SQLException {
		MasterVehicleImageResponse masterImageResponse = new MasterVehicleImageResponse();
		masterImageResponse.setIdimage(rs.getInt("idimage"));
		masterImageResponse.setVehicleid(rs.getInt("vehicleid"));
		masterImageResponse.setUserid(rs.getInt("userid"));
		masterImageResponse.setImagename(rs.getString("imagename"));
		masterImageResponse.setCreatedate(rs.getString("createddate"));
		masterImageResponse.setUpdatedate(rs.getString("updateddate"));
		masterImageResponse.setIsactive(rs.getBoolean("isactive"));

		return masterImageResponse;


	}
	public static VehiclesList insertVehiclesImagesCSV(BLogger logger, DBManager dbm, Collection<MasterVehicleImageResponse> vehiclesImages)
			throws DBException {
		VehiclesList vehiclesList = new VehiclesList();
		if (dbm == null || vehiclesImages == null) {
			vehiclesList.setErrorMessage("Error retrieving Vehicle Features details ");
			vehiclesList.setErrorCode("1");
			return vehiclesList;
		}
		try {
			DBQueryBuilder dbQB = dbm.getDBQueryBuilder();
			DBQuery sq = dbQB.setBatch().setQueryString(INSERT_IAMGE_DETAILS).setBindInputFunction((dbLogger, ps) -> {
				for (MasterVehicleImageResponse v : vehiclesImages) {


					ps.setInt(1, v.getVehicleid());
					ps.setString(2, v.getImagename());
					ps.setInt(3, v.getUserid());


					ps.addBatch();
				}
			}).setReturnKeys().setFetchDataFunction((dbFLogger, rs) -> {
				vehiclesList.getImageresponse().add(MasterVehicleImageDAO.getAllResponse(dbFLogger,rs));
			}).logQuery(true).throwOnNoData(false).build();

			dbm.update(logger, sq);

			vehiclesList.setErrorMessage("Inserted Successfully ");
			vehiclesList.setErrorCode("0");
			return vehiclesList;
		} catch (Exception e) {
			vehiclesList.setErrorMessage("Error retrieving Vehicle Images details ");
			vehiclesList.setErrorCode("1");
			return vehiclesList;

		}
	}
}
