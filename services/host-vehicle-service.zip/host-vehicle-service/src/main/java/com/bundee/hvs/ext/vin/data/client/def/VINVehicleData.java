package com.bundee.hvs.ext.vin.data.client.def;

import com.bundee.msfw.defs.UTF8String;

public interface VINVehicleData {
	UTF8String getVIN();
	UTF8String getMake();
	UTF8String getModel();
	UTF8String getDesc();
	UTF8String getYear();
	UTF8String getNumber();
	UTF8String getColor();
}
