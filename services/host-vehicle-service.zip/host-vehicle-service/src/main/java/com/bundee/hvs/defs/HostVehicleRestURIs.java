package com.bundee.hvs.defs;

public class HostVehicleRestURIs {
	
	public class Endpoints {
		public static final String GET_VEHICLE_REVIEW = "http://4.240.86.202:8002/api/v1/booking/getvehiclereviewdetail";

		public static final String GET_USER_BY_ID = "http://4.240.86.202:8080/api/v1/user/getUserById";











	}
	
	

}
