package com.bundee.hvs.pojo;

import com.bundee.hvs.defs.HVSProcessingCode;
import com.bundee.msfw.defs.BExceptions;
import com.bundee.msfw.defs.UTF8String;
import com.bundee.msfw.defs.Utils;

public class UploadedFile {
	UTF8String fileName;
	UTF8String b64Contents;

	public UTF8String getFileName() {
		return fileName;
	}

	public UTF8String getB64Contents() {
		return b64Contents;
	}

	public static void validate(UploadedFile uf) throws BExceptions {
		BExceptions exceptions = new BExceptions();
		if (uf == null) {
			exceptions.add(HVSProcessingCode.INVALID_VEHICLE_FILE, "UploadedFile is null!");
		} else {
			if (Utils.isNullOrEmptyOrBlank(uf.fileName)) {
				exceptions.add(HVSProcessingCode.INVALID_VEHICLE_FILE, "FileName is null!");
			}
			if (Utils.isNullOrEmptyOrBlank(uf.b64Contents)) {
				exceptions.add(HVSProcessingCode.INVALID_VEHICLE_FILE, "File contents are null!");
			}
		}
		if (exceptions.hasExceptions()) {
			throw exceptions;
		}
	}
}
