drop table if exists  master_vehicle_type;
drop table if exists  master_vehicle;
drop table if exists  master_vehicle_price;
drop table if exists  master_vehicle_image;

-- we will create indices for each table soon
-- the columns are deliberately arrranged to reduce padding
create table master_vehicle_type (
    id smallint primary key,
    name text not null
);

create table master_vehicle (
	crtd_ts timestamptz not null default current_timestamp,
	updtd_ts timestamptz,
    price_per_hr real not null,
	
    id serial primary key,
	vhost int not null,
    location_id int not null,
	vehicle_type_id smallint not null,
    isactive boolean default true,
    
    vin text not null unique,
    make text not null,
    model text not null,
    description text not null,
    year text not null,
    vnumber text not null,
    vcolor text not null
);

create table master_vehicle_image (
    vehicle_id int not null,
    image_id int not null
);
